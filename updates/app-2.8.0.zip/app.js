const _0x19b0c2=_0x46d1;(function(_0x3a24b3,_0x1d4080){const _0x3678d8=_0x46d1,_0x2891f8=_0x3a24b3();while(!![]){try{const _0x23872f=-parseInt(_0x3678d8(0xea))/(-0xcb*0x1+-0x1b6b+-0xe9*-0x1f)*(-parseInt(_0x3678d8(0x30f))/(0x72f*0x1+-0x1*-0xf95+0x1*-0x16c2))+-parseInt(_0x3678d8(0x399))/(-0x1*-0x23ad+-0xf*0x217+0xd*-0x55)+-parseInt(_0x3678d8(0x2c8))/(0xb98+0x1c35+-0x27c9)+parseInt(_0x3678d8(0x1e1))/(-0x3*-0x895+0x2*0x713+-0x27e0)*(parseInt(_0x3678d8(0x3d1))/(0x2c1+0x4*-0x7a6+0x1bdd))+parseInt(_0x3678d8(0x3fb))/(0x246e*0x1+-0xb*0x82+0x7*-0x467)+parseInt(_0x3678d8(0x266))/(0x539+-0x2*0x269+-0x5f)*(parseInt(_0x3678d8(0x228))/(0x19*0xca+0x4a7*-0x7+0xce0))+-parseInt(_0x3678d8(0x39a))/(-0x1627+-0x19ec+0x301d)*(parseInt(_0x3678d8(0x251))/(-0x8*0x2b6+-0x1efa+0x34b5));if(_0x23872f===_0x1d4080)break;else _0x2891f8['push'](_0x2891f8['shift']());}catch(_0x5b74b7){_0x2891f8['push'](_0x2891f8['shift']());}}}(_0x522d,0x1*-0xe69+0x5a4b3+-0x317*0xd7));const $=_0x508409=>document[_0x19b0c2(0x2b6)+_0x19b0c2(0x1eb)](_0x508409),A=(..._0x43990c)=>window[_0x19b0c2(0x21a)][_0x19b0c2(0x3f0)](..._0x43990c);function _0x46d1(_0x576843,_0x3ba942){_0x576843=_0x576843-(0x5*0x1a5+-0x134a+0xbbf);const _0x4e6b71=_0x522d();let _0x2cf881=_0x4e6b71[_0x576843];if(_0x46d1['TXzKjj']===undefined){var _0x3c5130=function(_0x413ea5){const _0x55b3a1='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+/=';let _0x5abfdd='',_0x17c961='';for(let _0x1f98e7=-0x1926+-0x1217+0x1*0x2b3d,_0x44853c,_0x420c2e,_0x3b5bfb=-0x321+-0x72e+0xa4f*0x1;_0x420c2e=_0x413ea5['charAt'](_0x3b5bfb++);~_0x420c2e&&(_0x44853c=_0x1f98e7%(0xb*-0x135+-0x81d+0x1568)?_0x44853c*(0x801+-0x1a*0xa7+0x935*0x1)+_0x420c2e:_0x420c2e,_0x1f98e7++%(0x3e*-0x3b+0x10b4+-0x266))?_0x5abfdd+=String['fromCharCode'](-0x44*-0x69+0x9a3*0x2+-0x2e2b&_0x44853c>>(-(0x1201+0x1*0x207e+-0x1*0x327d)*_0x1f98e7&-0x148d*0x1+0x20d6*0x1+-0x1*0xc43)):0x27*0x9+0x41a*0x2+-0x993){_0x420c2e=_0x55b3a1['indexOf'](_0x420c2e);}for(let _0x5aceff=-0x34*0x54+0x61c+0x1*0xaf4,_0x8b771d=_0x5abfdd['length'];_0x5aceff<_0x8b771d;_0x5aceff++){_0x17c961+='%'+('00'+_0x5abfdd['charCodeAt'](_0x5aceff)['toString'](-0x8a3*-0x3+-0x15*0x62+0x61*-0x2f))['slice'](-(0x17db+-0x20c8+0x8ef));}return decodeURIComponent(_0x17c961);};_0x46d1['gCHeGl']=_0x3c5130,_0x46d1['txYHLw']={},_0x46d1['TXzKjj']=!![];}const _0x1ea77a=_0x4e6b71[-0x1*0x29f+0x50*-0x32+0x9*0x207];_0x46d1['YvrUxT']!==_0x1ea77a&&(_0x46d1['txYHLw']={},_0x46d1['YvrUxT']=_0x1ea77a);const _0x9b1b58=_0x46d1['txYHLw'][_0x576843];return _0x9b1b58===undefined?(_0x2cf881=_0x46d1['gCHeGl'](_0x2cf881),_0x46d1['txYHLw'][_0x576843]=_0x2cf881):_0x2cf881=_0x9b1b58,_0x2cf881;}let lang='en';const t=(_0x2324d0,..._0x333f97)=>{const _0x1d6349=_0x19b0c2;let _0x346781=(T[lang]||{})[_0x2324d0]??T['en'][_0x2324d0]??_0x2324d0;return _0x333f97[_0x1d6349(0x2ee)]((_0x1c6aa0,_0x568f62)=>_0x346781=_0x346781[_0x1d6349(0x136)]('{'+_0x568f62+'}',_0x1c6aa0)),_0x346781;},esc=_0x53418d=>String(_0x53418d??'')[_0x19b0c2(0x136)](/[&<>"']/g,_0x3fb4fc=>({'&':_0x19b0c2(0x3bc),'<':'&lt;','>':_0x19b0c2(0xb9),'\x22':_0x19b0c2(0xb5),'\x27':_0x19b0c2(0x3ad)}[_0x3fb4fc])),TYPE={'mods':_0x19b0c2(0x1a6),'shaderpacks':_0x19b0c2(0x310),'resourcepacks':_0x19b0c2(0x120)+_0x19b0c2(0x2c9)},LOGO=_0x19b0c2(0xd6)+_0x19b0c2(0x472)+'vg\x22\x20view'+_0x19b0c2(0x2dc)+_0x19b0c2(0x3e9)+_0x19b0c2(0x355)+_0x19b0c2(0x28f)+_0x19b0c2(0x173)+_0x19b0c2(0x28d)+_0x19b0c2(0x132)+_0x19b0c2(0xf3)+_0x19b0c2(0x32c)+_0x19b0c2(0x1da)+'8,19\x22/><'+_0x19b0c2(0x3ee)+_0x19b0c2(0x37a)+_0x19b0c2(0x332)+_0x19b0c2(0x123)+'19\x2032,33'+_0x19b0c2(0x19b)+_0x19b0c2(0xfd)+_0x19b0c2(0x14a)+_0x19b0c2(0xe4)+'\x20fr\x22\x20poi'+_0x19b0c2(0x1db)+'33\x2056,19'+_0x19b0c2(0x43a)+_0x19b0c2(0x462)+'/g></svg'+'>',sv=_0x2203f3=>_0x19b0c2(0xd6)+_0x19b0c2(0x3d6)+_0x19b0c2(0x165)+_0x19b0c2(0x175)+_0x19b0c2(0x262)+_0x2203f3+_0x19b0c2(0x421),I={'play':sv(_0x19b0c2(0x23d)+_0x19b0c2(0x373)+_0x19b0c2(0x152)+'\x22/>'),'bolt':sv(_0x19b0c2(0x23d)+_0x19b0c2(0x32d)+_0x19b0c2(0x241)+_0x19b0c2(0x3a6)+_0x19b0c2(0x370)),'folder':sv('<path\x20d='+'\x22M3\x207a2\x20'+_0x19b0c2(0x339)+_0x19b0c2(0x45d)+_0x19b0c2(0x2bd)+_0x19b0c2(0x397)+'2\x202\x200\x2001'+_0x19b0c2(0xb6)+_0x19b0c2(0x341)+_0x19b0c2(0x1c2))},ACCENTS=[_0x19b0c2(0x2c6),_0x19b0c2(0x181),_0x19b0c2(0x2e9),_0x19b0c2(0x171),_0x19b0c2(0x122),_0x19b0c2(0x3c5),'#e9e6df'],HEX=/^#[0-9a-f]{6}$/i;let S,V=[],view='lib',cur=null,tab=_0x19b0c2(0x11c),btype=_0x19b0c2(0x1a6),target=null,timer,running=![],runLabel='',off=0x1bc8+0x832+-0x23fa,FOUND=[],IMP=null,crashId=null,paneSeq=-0x1d*0x10f+0xcfc+0x5*0x38b,FILES={'mods':[],'shaderpacks':[],'resourcepacks':[]};const toast=(_0x148db0,_0x4bee38=-0x2*0x50b+-0x20cf+-0x9*-0x649)=>{const _0x95768a=_0x19b0c2,_0x26a83d=document[_0x95768a(0x269)+'ement'](_0x95768a(0x336));_0x26a83d[_0x95768a(0x131)+'e']=_0x95768a(0x1bd),_0x26a83d[_0x95768a(0x45f)+_0x95768a(0x222)]=_0x148db0,$(_0x95768a(0x109))['append'](_0x26a83d),setTimeout(()=>{const _0x4eb469=_0x95768a;_0x26a83d[_0x4eb469(0x142)+'t']['add']('out'),setTimeout(()=>_0x26a83d['remove'](),0x358+0x4*0x529+-0x31*0x78);},_0x4bee38);},fail=_0x483a5f=>{const _0x38bdfb=_0x19b0c2,_0xdcc6c5=String(_0x483a5f[_0x38bdfb(0x1b4)]||_0x483a5f)['replace'](/^Error invoking remote method '.*?': (Error: )?/,'');toast(_0xdcc6c5[_0x38bdfb(0x369)+'th']('E:')?t('e_'+_0xdcc6c5['slice'](0x73*-0x5+0x1be4+0x19a3*-0x1)):_0xdcc6c5,-0xcd*0x13+0x2*0xc9a+-0x1*-0x115b);},modal=_0x530d81=>{const _0xbe42d9=_0x19b0c2,_0x503743=$('#modal');clearTimeout(_0x503743['_t']),_0x503743[_0xbe42d9(0x142)+'t'][_0xbe42d9(0x459)]('out'),delete _0x503743[_0xbe42d9(0x16e)][_0xbe42d9(0x2a2)],_0x503743[_0xbe42d9(0x35c)+'L']=_0xbe42d9(0x2c1)+_0xbe42d9(0x3db)+'>'+_0x530d81+_0xbe42d9(0x128),_0x503743[_0xbe42d9(0x142)+'t'][_0xbe42d9(0x246)]('on');},closeM=_0x52a268=>{const _0x313911=_0x19b0c2,_0x59c67b=$(_0x313911(0x1fd));if(!_0x59c67b[_0x313911(0x142)+'t']['contains']('on')||_0x59c67b[_0x313911(0x16e)][_0x313911(0x2a2)]&&_0x52a268!==!![])return;_0x59c67b[_0x313911(0x142)+'t'][_0x313911(0x246)]('out'),clearTimeout(_0x59c67b['_t']),_0x59c67b['_t']=setTimeout(()=>_0x59c67b[_0x313911(0x142)+'t']['remove']('on',_0x313911(0x155)),-0x148d*0x1+0x20d6*0x1+-0x1*0xb95);},vers=async()=>{const _0x193202=_0x19b0c2;if(!V['length'])V=await A(_0x193202(0x100));},ago=_0x5f0850=>{const _0x44c492=_0x19b0c2,_0x2dab2f=new Intl[(_0x44c492(0x26b))+(_0x44c492(0xbe))+'at'](lang,{'numeric':_0x44c492(0xeb)}),_0x57c753=Math['max'](0x27*0x9+0x41a*0x2+-0x993,Math[_0x44c492(0x307)]((Date['now']()-_0x5f0850)/(-0x4*0x332f+0x4954+0x4*0x5b72)));if(_0x57c753<-0x8a3*-0x3+-0x15*0x62+0x12d*-0xf)return _0x2dab2f[_0x44c492(0x1d7)](-_0x57c753,'minute');const _0x1f595d=Math[_0x44c492(0x307)](_0x57c753/(0x17db+-0x20c8+0x929));return _0x1f595d<-0x1*0x29f+0x50*-0x32+0x21*0x8f?_0x2dab2f[_0x44c492(0x1d7)](-_0x1f595d,_0x44c492(0x160)):_0x2dab2f['format'](-Math[_0x44c492(0x307)](_0x1f595d/(-0x1*-0x208b+-0x9cf*-0x1+-0x2a42)),_0x44c492(0x2fd));};addEventListener(_0x19b0c2(0x216),_0x5318ad=>{const _0x10580d=_0x19b0c2;if(_0x5318ad[_0x10580d(0x40a)]===_0x10580d(0x192))closeM();});let mdT=null;$(_0x19b0c2(0x1fd))[_0x19b0c2(0x146)+'own']=_0x11812f=>{const _0x7fb06d=_0x19b0c2;mdT=_0x11812f[_0x7fb06d(0x2b5)];},$(_0x19b0c2(0x1fd))[_0x19b0c2(0x470)]=_0x25c2d3=>{const _0x5e1ead=_0x19b0c2;if(_0x25c2d3[_0x5e1ead(0x2b5)]['id']===_0x5e1ead(0xe0)&&mdT&&mdT['id']===_0x5e1ead(0xe0))closeM();mdT=null;},document[_0x19b0c2(0x1e0)+'Listener']('keydown',_0x30e4eb=>{const _0x77d561=_0x19b0c2;if(_0x30e4eb[_0x77d561(0x40a)]===_0x77d561(0x192))closeM();}),window[_0x19b0c2(0x21a)]['on'](_0x19b0c2(0xda),_0x43402f=>{const _0x400e7c=_0x19b0c2,_0xb3da30=$(_0x400e7c(0x3fd)),_0x17998a=$('#spg'),_0x54ae9b=$(_0x400e7c(0x3da));if(!_0x43402f){_0xb3da30[_0x400e7c(0x45f)+'ent']=t(_0x400e7c(0x3ae)),_0x17998a[_0x400e7c(0xb4)][_0x400e7c(0x2d4)]='0',_0x54ae9b['classLis'+'t'][_0x400e7c(0x459)](_0x400e7c(0x24d),_0x400e7c(0x32a));return;}const [_0x2f12ea,_0x356972]=_0x43402f['slice'](-0x107*-0xe+0x1f25+-0x2d85)[_0x400e7c(0x322)]('|'),_0x459b36=(_0x356972||'')[_0x400e7c(0x230)](/(\d+)\/(\d+)/),_0x4468f7=_0x459b36&&+_0x459b36[-0xf0b*-0x1+0x990+0x1899*-0x1]?Math[_0x400e7c(0x307)]((0x411*-0x2+0x1b8a+-0x4c1*0x4)*_0x459b36[0x1*-0x66e+0x1b2e+-0x14bf]/_0x459b36[0x287*0x7+-0xf8*-0x4+-0x158f*0x1]):null;_0xb3da30[_0x400e7c(0x45f)+_0x400e7c(0x222)]=t('s_'+_0x2f12ea)+(_0x356972?'\x20'+_0x356972:''),_0x17998a[_0x400e7c(0xb4)]['width']=_0x4468f7===null?_0x400e7c(0x42a):_0x4468f7+'%',_0x54ae9b[_0x400e7c(0x142)+'t'][_0x400e7c(0x246)](_0x400e7c(0x24d)),_0x54ae9b['classLis'+'t']['toggle'](_0x400e7c(0x32a),_0x4468f7===null);const _0x47987c=$(_0x400e7c(0x2a5));_0x47987c&&_0x2f12ea===_0x400e7c(0xd1)&&_0x356972&&(_0x47987c['querySel'+'ectorAll'](_0x400e7c(0x46f)+_0x400e7c(0x284))[_0x400e7c(0x2ee)](_0x87a49e=>_0x87a49e[_0x400e7c(0x142)+'t'][_0x400e7c(0x246)]('ok')),_0x47987c[_0x400e7c(0x31d)+_0x400e7c(0x308)+'ML'](_0x400e7c(0x406)+'d',_0x400e7c(0x36e)+esc(_0x356972)+_0x400e7c(0x128)),_0x47987c['scrollTo'+'p']=_0x47987c[_0x400e7c(0x11d)+_0x400e7c(0xe7)]),running&&(runLabel=_0x2f12ea===_0x400e7c(0x44c)?'':t('s_'+_0x2f12ea)['replace']('…',''),syncPlay());}),window['api']['on'](_0x19b0c2(0x2b2),_0x239177=>{const _0x2e530d=_0x19b0c2;running=![],runLabel='',syncPlay();if(!_0x239177||!_0x239177[_0x2e530d(0x38f)])toast(t('closed'));softLoad();}),window[_0x19b0c2(0x21a)]['on'](_0x19b0c2(0x1ba),_0x325eea=>{const _0x1b90db=_0x19b0c2;crashId=_0x325eea['id'];const _0x3fc754=[];if(_0x325eea[_0x1b90db(0x21c)]&&_0x325eea['disabled']['length'])_0x3fc754[_0x1b90db(0x185)](t(_0x1b90db(0x1ac),_0x325eea['disabled'][_0x1b90db(0x2ca)](',\x20')));if(_0x325eea[_0x1b90db(0x1d2)+'ff'])_0x3fc754[_0x1b90db(0x185)](t(_0x1b90db(0x254)));if(_0x325eea[_0x1b90db(0x2f0)])_0x3fc754[_0x1b90db(0x185)](t(_0x1b90db(0xbd)+'e'));if(_0x325eea[_0x1b90db(0x1b9)])_0x3fc754[_0x1b90db(0x185)](t(_0x1b90db(0xc7)+_0x1b90db(0x20a)));if(!_0x3fc754['length'])_0x3fc754[_0x1b90db(0x185)](t('cr_b',_0x325eea[_0x1b90db(0x38f)]));modal('<h2>'+t(_0x1b90db(0x3b3))+(_0x1b90db(0x323)+_0x1b90db(0x376)+_0x1b90db(0x2e7))+_0x3fc754['map'](esc)['join']('\x20')+(_0x1b90db(0x26a)+_0x1b90db(0x28d)+_0x1b90db(0x1c0)+_0x1b90db(0x1ee)+_0x1b90db(0x3bf)+_0x1b90db(0x385)+_0x1b90db(0x2e0)+_0x1b90db(0x20f))+t('ok')+('</button'+_0x1b90db(0x162)+'\x20onclick'+'=\x22A(\x27plo'+_0x1b90db(0x3f9))+t(_0x1b90db(0x29f))+(_0x1b90db(0xf4)+'>')+(_0x325eea[_0x1b90db(0x271)]?'':_0x1b90db(0x168)+_0x1b90db(0x2bc)+_0x1b90db(0x172)+_0x1b90db(0x2da)+t(_0x1b90db(0x316)+'e')+(_0x1b90db(0xf4)+'>'))+_0x1b90db(0x128));}),window[_0x19b0c2(0x1e0)+_0x19b0c2(0xc5)]('unhandle'+_0x19b0c2(0x3ac)+'on',_0xbe787c=>{const _0x33cd86=_0x19b0c2;fail(_0xbe787c[_0x33cd86(0x366)]||_0x33cd86(0x1ff)),_0xbe787c[_0x33cd86(0x414)+_0x33cd86(0x1a4)]();});async function goStable(){
  await A('psave',{id:crashId,stable:true});
  closeM();
  await load();
  toast(t('stable_on'));
  // the button says "enable stable mode and retry": actually retry
  cur=crashId;
  const c=S&&S.config&&S.config.close;
  run(c&&c!=='ask'?c:'keep');
}
async function boot(){const _0x327a50=_0x19b0c2;S=await A(_0x327a50(0x33c));if(T[S['config'][_0x327a50(0x22d)]])lang=S[_0x327a50(0x1f5)][_0x327a50(0x22d)];document[_0x327a50(0x29b)+'Element'][_0x327a50(0x22d)]=lang,applyAccent(S[_0x327a50(0x1f5)][_0x327a50(0x3bb)]),$('#stxt')[_0x327a50(0x45f)+_0x327a50(0x222)]=t('sb_ready'),$(_0x327a50(0x12d))['textCont'+_0x327a50(0x222)]=_0x327a50(0xc4)+'\x20\x20·\x20\x20'+t(_0x327a50(0x2cd)),$(_0x327a50(0x129))[_0x327a50(0x45f)+_0x327a50(0x222)]=t(_0x327a50(0x15a));if(!S[_0x327a50(0x415)])onboard(0x67*0x61+-0x8b*-0x1b+-0x35b0);else shell(),go('lib');hideSplash();}function onboard(_0x14f821,_0x1ba4fb){const _0x9009ed=_0x19b0c2;document[_0x9009ed(0x1dd)][_0x9009ed(0x142)+'t'][_0x9009ed(0x246)](_0x9009ed(0x1f1));if(!$(_0x9009ed(0x383)))$(_0x9009ed(0x3ed))['innerHTM'+'L']=_0x9009ed(0x2c1)+_0x9009ed(0x28a)+_0x9009ed(0x2c1)+_0x9009ed(0x153)+_0x9009ed(0x3f4)+_0x9009ed(0x412)+_0x9009ed(0x467)+'>N</span'+_0x9009ed(0x32b)+_0x9009ed(0x38b)+'span>M</'+_0x9009ed(0x2f3)+_0x9009ed(0x469)+'an></div'+_0x9009ed(0x3f4)+'ass=\x22sub'+_0x9009ed(0x20d)+_0x9009ed(0x1cb)+_0x9009ed(0x437)+_0x9009ed(0x380)+'>'+t(_0x9009ed(0x2cd))+(_0x9009ed(0x298)+_0x9009ed(0x3ba)+_0x9009ed(0x1c8)+_0x9009ed(0x2b0)+_0x9009ed(0x418)+_0x9009ed(0x405)+_0x9009ed(0x275)+'div></di'+'v>');const _0x340a50=$(_0x9009ed(0x3d3)+'v');if(_0x340a50)_0x340a50[_0x9009ed(0x45f)+_0x9009ed(0x222)]=t(_0x9009ed(0x2cd));const _0xa9d3a2=$(_0x9009ed(0x126)),_0x1c3a0a=_0xa9d3a2[_0x9009ed(0x16e)]['step']!==String(_0x14f821);_0xa9d3a2[_0x9009ed(0x16e)][_0x9009ed(0x31c)]=_0x14f821,_0xa9d3a2[_0x9009ed(0x35c)+'L']=_0x14f821===-0xaf4+0xabd*-0x3+0x1*0x2b2b?_0x9009ed(0x3e8)+'lass=\x22ki'+_0x9009ed(0x2dd)+t('ob_step',-0x1c*-0xf4+-0x1d48+0x299,-0xaef+-0x1608+-0x16f*-0x17)+('</small>'+_0x9009ed(0x3fa))+t(_0x9009ed(0x282))+('</h1><p\x20'+'class=\x22m'+'ut\x22>')+t(_0x9009ed(0x30b)+_0x9009ed(0x114))+(_0x9009ed(0x26a)+_0x9009ed(0x28d)+_0x9009ed(0x3dd))+LANGS[_0x9009ed(0x157)](([_0x2f8553,_0x14faf2,_0x572d2f],_0x2805f9)=>_0x9009ed(0x168)+'class=\x22l'+_0x9009ed(0x413)+(_0x2f8553===lang?'on':'')+(_0x9009ed(0x1a3)+_0x9009ed(0x138)+_0x9009ed(0x3fe))+_0x2f8553+(_0x9009ed(0x359)+_0x9009ed(0x30a)+'\x22ix\x22>')+String(_0x2805f9+(0x4d9+-0x14*0x91+0x67c))[_0x9009ed(0x1ed)](-0x1573*-0x1+0x387+-0xbc*0x22,'0')+_0x9009ed(0x2fc)+_0x14faf2+(_0x9009ed(0x3f2)+_0x9009ed(0x390)+'>(')+_0x572d2f+(_0x9009ed(0xb7)+'</button'+'>'))[_0x9009ed(0x2ca)]('')+(_0x9009ed(0x3b1)+'utton\x20cl'+_0x9009ed(0x235)+'id\x20big\x20w'+_0x9009ed(0x3df)+_0x9009ed(0x2f7)+_0x9009ed(0xf8)+'\x22>')+t(_0x9009ed(0x3f5))+('</button'+'>'):_0x14f821===0x425*0x5+0x3e6*-0x4+0x52*-0x10?_0x9009ed(0x3e8)+_0x9009ed(0xae)+'ck\x22>'+t(_0x9009ed(0x311),0x61a+-0x1*-0x23e2+-0x29fa,-0x3ed*0x9+-0x21d1+0x4*0x114a)+('</small>'+_0x9009ed(0x3fa))+t(_0x9009ed(0x350))+(_0x9009ed(0x249)+_0x9009ed(0x376)+_0x9009ed(0x2e7))+t('ob_login'+_0x9009ed(0xd0))+(_0x9009ed(0xf2)+_0x9009ed(0x1f4)+_0x9009ed(0x46a)+_0x9009ed(0x179)+_0x9009ed(0x1a7)+'b\x22\x20oncli'+'ck=\x22doLo'+_0x9009ed(0x3e2))+t(_0x9009ed(0x350)+'_btn')+(_0x9009ed(0xf4)+'>'):'<svg\x20cla'+_0x9009ed(0x272)+_0x9009ed(0x2ad)+_0x9009ed(0x276)+_0x9009ed(0x440)+_0x9009ed(0x18a)+_0x9009ed(0x315)+_0x9009ed(0x233)+_0x9009ed(0x387)+_0x9009ed(0x111)+t(_0x9009ed(0x3a8),esc(_0x1ba4fb))+_0x9009ed(0x196),_0xa9d3a2['classLis'+'t'][_0x9009ed(0x17f)](_0x9009ed(0x3be),!_0x1c3a0a),_0x1c3a0a&&(_0xa9d3a2[_0x9009ed(0x142)+'t'][_0x9009ed(0x459)]('in'),void _0xa9d3a2[_0x9009ed(0x151)+_0x9009ed(0x14e)],_0xa9d3a2[_0x9009ed(0x142)+'t']['add']('in'));}function retext(){const _0x4bf90f=_0x19b0c2;document['document'+_0x4bf90f(0x1e3)][_0x4bf90f(0x22d)]=lang,$('#stxt')[_0x4bf90f(0x45f)+_0x4bf90f(0x222)]=t('sb_ready'),$('#sver')[_0x4bf90f(0x45f)+_0x4bf90f(0x222)]=_0x4bf90f(0xc4)+_0x4bf90f(0x245)+t(_0x4bf90f(0x2cd)),$(_0x4bf90f(0x129))[_0x4bf90f(0x45f)+'ent']=t(_0x4bf90f(0x15a));}function setLang(_0x267f62){lang=_0x267f62,onboard(-0x1d*0x6d+-0x1*-0x209b+-0x1442);}function setLangS(_0x3e9fc7){const _0x56a782=_0x19b0c2;lang=_0x3e9fc7,A('cfgset',{'lang':lang}),S[_0x56a782(0x1f5)][_0x56a782(0x22d)]=_0x3e9fc7,retext(),shell(),go('settings');}async function saveLang(){const _0x1c5f62=_0x19b0c2;await A('cfgset',{'lang':lang}),S[_0x1c5f62(0x1f5)][_0x1c5f62(0x22d)]=lang,retext();if(S[_0x1c5f62(0x415)])shell(),go(_0x1c5f62(0x218));else onboard(0x12f3*-0x1+0x1d6*-0x11+0x322a*0x1);}async function doLogin(){const _0x40e380=_0x19b0c2,_0x26d691=$(_0x40e380(0x47a));_0x26d691[_0x40e380(0x21c)]=!![],_0x26d691[_0x40e380(0x45f)+_0x40e380(0x222)]=t('ob_wait');try{const _0x48e6fb=await A(_0x40e380(0x16d));S=await A(_0x40e380(0x33c)),onboard(-0x15e0+0x20e*0x10+-0x7*0x192,_0x48e6fb),setTimeout(()=>{const _0x12b3ee=_0x40e380;shell(),go(_0x12b3ee(0x218));},0x9*0xe9+0x39a+-0x9*0xbf);}catch(_0x65419e){fail(_0x65419e),_0x26d691[_0x40e380(0x21c)]=![],_0x26d691[_0x40e380(0x45f)+_0x40e380(0x222)]=t(_0x40e380(0x350)+_0x40e380(0x439));}}function shell(){const _0x344efd=_0x19b0c2,_0x569fb6=S[_0x344efd(0x415)];document['body']['classLis'+'t'][_0x344efd(0x459)](_0x344efd(0x1f1)),$(_0x344efd(0x3ed))[_0x344efd(0x35c)+'L']=_0x344efd(0x148)+_0x344efd(0x2c1)+_0x344efd(0x392)+_0x344efd(0x467)+_0x344efd(0x28d)+_0x344efd(0x34e)+LOGO+('</span><'+'b>NRML</'+_0x344efd(0x202)+_0x344efd(0x393)+'></div><'+_0x344efd(0x204)+'nav\x22>')+[[_0x344efd(0x218),_0x344efd(0x3c8)+'iles'],['browse',_0x344efd(0x281)+'se'],['settings','nav_sett'+_0x344efd(0x11e)]]['map'](([_0x33d32a,_0xdbd588])=>_0x344efd(0x168)+'data-v=\x22'+_0x33d32a+(_0x344efd(0x1a3)+_0x344efd(0x1bc))+_0x33d32a+_0x344efd(0x3cc)+t(_0xdbd588)+(_0x344efd(0xf4)+'>'))[_0x344efd(0x2ca)]('')+(_0x344efd(0x3ca)+_0x344efd(0x46d)+_0x344efd(0x345)+_0x344efd(0x2c7)+_0x344efd(0x35b)+_0x344efd(0x38d)+_0x344efd(0x17a)+_0x344efd(0x2d9)+_0x344efd(0x22a)+_0x344efd(0xed)+_0x344efd(0x277))+encodeURIComponent(_0x569fb6['id']||_0x569fb6[_0x344efd(0x25f)])+(_0x344efd(0x2e1)+_0x344efd(0xbc)+_0x344efd(0x1f0)+_0x344efd(0x2de)+'visibili'+'ty=\x27hidd'+_0x344efd(0x1aa)+_0x344efd(0x226))+esc(_0x569fb6[_0x344efd(0x25f)])+(_0x344efd(0x38b)+_0x344efd(0x367)+_0x344efd(0xcc)+_0x344efd(0x2d1)+_0x344efd(0x23a)+_0x344efd(0x1d4));}async function load(){const _0x64da9=_0x19b0c2;S=await A(_0x64da9(0x33c));if(!S[_0x64da9(0x415)])return onboard(-0x1f53+-0xdc3+-0x1*-0x2d16);if(!$(_0x64da9(0x2ff)))shell();go(view);}async function softLoad(){const _0x1d4af1=_0x19b0c2;S=await A(_0x1d4af1(0x33c)),view===_0x1d4af1(0x218)&&$(_0x1d4af1(0x3b0))&&drawRows();}function _0x522d(){const _0x50c2ba=['zgL2','zsK7C3LUy1m','iML4iJ4','mIaWidaXmI0','AwCUB3zLCMW','Bgf5v2vSy28','C3rHDgu','pc9KAxy+phu','C3rFy2XVC2u','o1mUy29UzMK','lMnOzwnRzwq','idiGmcaWms0','Awq9iMLSiJ4','iokaLca','cIa8Adm+','zsi+pc91pJW','ktTJDxi9jW','C2XPy2u','CfaOksi+','BIiGDMfSDwu','zhjHz292zxi','ihbPy2SIig8','DMfSDwu9iG','zgvS','BwfYAYi+','lNzHBhvLiJ4','B2jFBg9NAw4','y2XHC3m9iNm','BM9Yzxm','pc9IpJXZBwe','y3rZiJ48yNu','pgCGy2XHC3m','ywX1zsKIig8','CgfJA2vK','Dd0Iy2XLyxi','jYKIpJXZCge','zsi+pc9Zzwm','DIbJBgfZCZ0','Aw5Uzxjive0','pc9WpJWVzgK','Bgu9iI0TAtO','iIbKyxrHlxm','BwfYz2LUoJa','y2fU','BhvLpsi','B3b0lwjHCIi','AZ0IyNr5Cgu','Bwf4','CMvHC29U','l2rPDJ48l2G','zxjPzMLLzci','C3rHCNrZv2K','C3m9iM1YB3C','pg9WDgLVBJ4','zhvW','pJXPpJWVAt4','pgrPDJ4','yxnRx2TLzxa','ltD6iI8+','AxyGAwq9iNi','zci+pgrPDJ4','iK03idrSmtm','iJ48Ade+','ls1VBG','y2XHC3m9iM0','ywX1zx0Po1m','y2XLyw5Lza','Aw1Wx3q','y2XHC3m9iMy','jYKIpJWVyNu','DhjPBsGPFsK','C2vHCMnOx3a','Aw1WB3j0oNi','psjLDMvUDc4','C3m9iMrLDIi','BMqIignSyxm','DxbKyxrLza','lM9I','pgGZpG','zciGB25JBgK','iJ4Wpc9IpJW','iI8+pc9ZDMC','BwfSBd4','y2XLyw4','B2XPzcbIAwC','pc9ZCgfUpJW','l29WDgLVBJ4','iNDOBYi+pgK','DxbKx2rVBMu','y29Kzq','yxnZpsjSyYi','ys1Rxq','C3m9iMjYyw4','BMnOzxi8l2K','AZ0IqsGNB3a','lMnUDa','ksi+','mdeYidj2oge','iI0TyZO','mtaZmZG1n2LXzuvozq','ndy5nZuWv2rir2Xm','yxv0Ag9Y','zg9jBxaOksi','C21HBgW+','iIbHBhq9iIi','zt0Inda5nIi','lNzHBhvLFsK','mdeYmZq1nJC','B2XKzxi9iJe','Cgf0Aa','CYiGC3r5Bgu','DgHPCY52ywW','idGGos0XmMG','w2rHDgeTCgW','B2jFAgK','ig9Uy2XPy2S','i2LT','Dg9UlM9U','zhjLAMvJDgK','jImZotS','C2jFCMvHzhK','psjYDw4Oj2S','i3jVD3m','pc9KAxy+pgi','i2LU','y3jFDa','igrHDgeTBJ0','y3jFBgLJ','CNr5','pJXKAxy+phm','B3GIigLKpsi','Ad0InYiGC3a','pc9KAxy+pgq','ywnJzw50','jMfTCdS','i3bY','C3rPBgW','C3m9iNnVBgK','l2rPDJ4','AwX0','vgLTzw91DcG','Bxv0','zxH0CMe','i2i0ognMzG','CNvUBMLUzW','BwLZC2LUzW','BMf2x3bYB2y','Bgf5oNrOAxm','phuGy2XHC3m','yNv0Dg9Uig8','jYKIpG','ksKIpG','Dd48l2XHyMu','yxnRx3q','y2TZ','nMjNA3jvuW','y2XLyw5FBM8','lM9IBcaUzgu','CMvZlc5ZzwC','AgLZlNzHBhu','C3m9iMKIihy','B3zFC3rK','pJWVDt48l2q','iMXVy2fSkcK','i3nIyxi','C3m9iMjVEci','BgLZDgvK','BgfUz3mIpG','DMfSDwuUDhi','AwrLiIbVBMm','pgLTzYbJBge','DhjPBq','z2LUkcKIpG','psjMBgv4oJe','B3b0x2j1C3K','DxjS','CgfJA3m','y291BNq','phnTywXSigm','idy0idy0iJ4','C3rFB3v0','i3bU','DhrVBLTKyxq','i2fWCa','Cg9SEwDVBIa','AgvJA2jVEci','y2fSBa','qsGNy2zNC2u','phnWyw4Gy2W','C2v0DgLUz3m','pJXKAxyGy2W','BMv4Da','lMnVBMzPzY4','Dcb0ExbLpsi','psj0B0jYB3C','zYCPiJ4','pgGXpG','nZC1nZyXvw5nAvb5','zgLZy29Yzfa','i3n0Ehq','BMCOjW','DciGAwq9iNm','ANzT','y2SOksi+','y2HPBgrYzw4','y2HLy2TLzh0','BgLJzw5Zzq','CZ0IB2jJiJ4','yMvMB3jLzw4','C29SAwqGy3q','pgXHyMvSigm','AMf2ytP0AgK','A2v5','pc9WpJXSywi','BM9Uzq','zMXPC3q','y29UzMLYBuK','zMLNlMrPC2m','EsiG','C2zLCG','yxnZpsj3B3i','CM93ia','ChjLDMvUDeq','ywnJB3vUDa','DhjHBNnPDgK','C3bHBJ48yNu','zgL2ignSyxm','Bf92yw4','pc9ZCgfUpIa','Bwf4BgvUz3q','BgfIzwWGy2W','Ade+pgrPDIa','Bd48BgfIzwW','y2zNC2v0','pJXSywjLBd4','pc9ZDMC+','iJ48C3bHBJ4','pJXZCgfUihm','zxHWx2rVBMu','DxbKx25VBMu','ihr5Cgu9iMm','iJ48l2XHyMu','DciGAwq9iNe','BhvLo3eOksi','mtaWjq','zwn0B3jbBgW','phnWyw4GC3q','Aw1Wx20Y','AgLKzq','pc9OmJ48Bge','y3vYksi+','lNn3yxrJAc4','Awq9iML2iJ4','psjVChqTBgK','i3nU','C2f2zq','ig1HEd0Imty','BwfSBcbJBge','C2vSzwn0zwq','x2j0BG','idu2ldq3idm','DciGAwq9iMG','C3rFzgf0yq','zY5QyxzHpxq','mJm0nty3odK','AZ0IqsGNCg8','iduYiJ48Cge','B3b0BgLZDci','zgL0CYGPiJ4','Bg9HzgvY','Chv0ihr5Cgu','Aw5ZDgfSBgu','C3m9iMzYB3C','BM90kc5JDxm','y3jLyxrL','DgfNx3n0ywi','kcKIpISG','iMr1CfaOksi','CNvU','C3rFywnJ','B3jKoNrOAxm','Aw1Wx2rVBMu','B3OIignOzwm','pc9OmZ4','Aw1Wx25HBwu','ihzHBhvLpsi','zd0ICMvTiJ4','y2XHC3m9iMe','zgvZy3jPChq','CgrLBa','i3fZ','CMvTB3zL','l2rPDJ48l2q','ktWVB3b0Aw8','igLKpsjMB3u','mMG0BdiGmMG','D3mIpJWVzgK','Dgv4DenVBNq','zsKIpG','CgXHEq','mIW2msiVpJW','zwWGy2XHC3m','zd10AgLZlNy','C3m9iNbHz2u','pgjYpG','zci+phnWyw4','qwnJzw50khq','yw4+tdWVC3a','CZ0IC29SAwq','y2vUDcGN','zwXSy2HLy2S','psjUyxzSAw4','phnLBgvJDca','zgL2oM5VDcG','B25JBgLJAW','B2XVCIiGDMe','C3m9iMXNlxm','pc9WpG','iNrICYi+','yxnL','psiXnJm4nci','zxHW','z1mODgHPCY4','CgfUpG','i2XI','DcCSE292zxi','Axy+pgrPDIa','BgfZCZ0IA2K','Bwn2','y2fUy2vS','B3zLCMXHEq','Bgf5pxrOAxm','zxG6msi+pc8','C3r5Bgu','jNf1B3q7','ltiGmKG1yti','ktWVC3bHBJ4','C3m9iNn3lxi','jMD0oW','Cg9YDfaOksi','y19OAwrL','psiIig9Uzxi','y3jFBMf0Axy','vgLTzuzVCM0','zw5KC1DPDgG','i29WDa','Aw5ZDgfSBa','BMvLza','A2vLCa','tLjntcaXlJG','tgLZDgvUzxi','C2v0lM4PiJ4','y3jFAw5JB20','DJ48l2rPDJ4','i3nQ','pc9IpJWVzgK','C3qIigLKpsi','zwfKzxi+pg0','C3m9iNr4Dci','zvGO','pc9IpJXZCge','x3n1yG','B3b0','yNv0Dg9Uigm','ywXSiJ4','B3CIpG','xsKIpJXZCge','phn2zYbJBge','zu0ODhj1zsK','Aw1WB3j0oMy','BgLZDci+pgq','C3rHDhvZ','CMrFAgLUDa','Bw9KCgfJAW','iJ48C3bHBIa','iM9WDciGAwq','CMrFAwq','Bw9KywW','CYGPiJ4','ihr5Cgu9iNi','zwnRyM94iIa','BgfZCZ0IzMm','pc9ZzwXLy3q','DgL0Bgu','AwDODa','zxjSyxLnB2q','B2TI','muv3DefZCG','yxv0BW','CY52ywX1zs4','lM5LDc9HDMe','psjYDw4Oj2G','zgf0yvrYyw4','ywz0zxjIzwC','Bg9JywW','pc9WpJXIDxq','B2LUDhm9iJm','pc9IDxr0B24','pc9LBt48l3m','yxLxzwXJB20','BMnOyw5Nzt0','DMvmyw5NkcK','CZ0IDhH0iIa','zNjVBq','yxjNzxq','yxnZpsjZDYi','ldq3iI8+pha','C3rFB3zTB2q','pc9IpG','DMvYC2LVBNm','y3jLzgL0CW','ysiGB25JBgK','zgXZ','BgLJAZ0IAw0','B2rLpxrOAxm','Bv9TB2rZ','ChnHDMu','yxrJAcbJDxm','i3rVyxn0CW','Aw1Wx3nJyw4','zt10AgLZlMm','iJ48Aw5WDxq','y2XHC3m9iNq','yxrL','iMLJiJ48l2q','CZ0IAgv4iIa','pJXOmt4','C3rHBMrHCMq','AZ0IC2v0qwm','C3vI','y3vZDg9TigK','C3m9iMLJiJ4','zNrVz2DSzq','zwW+pgXHyMu','C3rFywnJzw4','yw4+ie1cpgK','iM11Dci+','Bw9KCW','C2nYB2XSsgu','Aw5NCW','pxrOAxmUDMe','CMvZB3vYy2u','zMfICMLJiJ4','iZzMyZnKoq','Aw50CZ0IocW','pKzHyNjPyZW','iIbKyxrHlwK','lM9IyW','AZ0IzgvSkhq','pc9KAxy+','i2rYB3a','C3rFD2vSy28','yxnZpsjUiJ4','yxnZpsjJiJ4','i3n2zxi','rM9Yz2uVuxu','Axy+cIa8zgK','BwLU','y2XHC3noyw0','zMmGzNqIiha','kcKIpG','DICPlNrLEhq','E2rPC2nVCMq','CMvWBgfJzq','jZTICM93C2u','AZ0IC2v0tge','ig9UAw5WDxq','iIbPzd0IC2y','B3nLkcKIpG','AwnR','zgLZy29YzeK','y3vZDg9T','BMnSAwnRpsi','B250zw50pxq','EwXLpsjMBgu','y2XHC3nmAxm','Aw1Wx3bHy2S','zMfKza','mdi0iIbTyxG','B25TB3vZzwq','zgLY','pgHLywrLCJ4','C29YDa','B2X5z29Uigm','CgfUpJXIDxq','Aw1Wx20X','iIb0AxrSzt0','zhrO','zsi+pc9Sywi','CcbJBgfZCZ0','B2zMC2v0v2K','idGTmtmGohO','C3m9iM9IBci','y3jFBM90zq','B3v0','C3rFz3b1','BwfW','ChnFC3rHyMW','lNnOzwv0lcm','zhjVCa','Aw1Wx21Vzhm','B2zMC2v0tgu','CZ0ICg4IpJW','BgLZDci+pc8','Aw1WB3j0oNm','Ag91CG','Cg93','pJXIDxr0B24','zMLSzxm','nda5nJWVC3a','Awv3qM94psi','DJ48zgL2pJW','iZe0mgeWnq','pgj1DhrVBIa','psjbkcDJzMC','AwnVBL91CMW','B3zFChjL','yMfYignVBci','Bg9NAw4','zgf0yxnLDa','zhmOksi+','pgLUChv0ihq','iZHMyMy1yq','iMDVu3rHyMW','phbVBhLNB24','AwCUzgLZy28','mcaWidi0idi','l2rPDJ48C20','pc9IpJXICJ4','zhvWx2rVBMu','igjPzYb3Awq','BwCGC3jJpsi','yxnLDc5Uksi','jYKUDgv4Dem','zMfICMLJiIa','y2HLy2TIB3G','Dg9Nz2XL','AMf2yq','i2zMzdyWyq','ociGB25JAge','Cgv4Cg9YDa','zwW+','ChvZAa','DhH0iIbVBMm','i2zVDw5K','ChjLy2LZzsi','y3jFBgLICW','DgGGzd0Itte','AxyGAwq9iMy','C3m9iMjHCIi','Bwu6DgHPCY4','C3rFAMf2yq','i2nYBa','z2u9iKeOj2m','C2v0jYX7B3y','rxnJyxbL','pJWVzgL2pG','zMLSDgvY','BgfZCZ0IyYi','pc9Omt4','pc9SywjLBd4','y2TIB3GIigK','Awq9iNb2iJ4','BgLICW','idmYldyXidG','B3b0x2jVzhK','pLzHBMLSBge','l2rPDJ48zgK','iJ48Ade+tw8','DcCSE2rPC2m','iIbZDhLSzt0','C3rHyMXLx28','iIbVBMnSAwm','zwzHDwX0','psjJiJ48Aw4','Bw9K','zsiGAwq9iMW','i3nWBgfZAa','yxnRx3jLBq','zw4NiJ48C3a','ChnFDa','y3jFzgLZ','lNrHyMXPBMu','ywjZiJ48zgK','C3rFBM90zq','CgLJA0rPCIG','psjMywn0CYi','iNnOB3DdCMu','Cgr1Ca','BwvZC2fNzq','yxGTD2LKDgG','Bgf5psjWBge','BgfZCZ0IC28','DhjHBNnSyxq','Aw5JB21Wyxq','y3jHC2HLza','DgHPCY5Kyxq','AZ0Iz28OjW','Dg9HC3q','psjMywXZzsi','lMrPC2fIBgu','yMfYiJ48yNu','C3m9iMLJiIa','mI0YEIiVpG','DhrVBJ4','C3rHCNrPBMC','Dd0IjcGNi3i','zw1WDhK','psjJDgWIpG','AxyGy2XHC3m','C3m9iNbOzwe','DxbKx3j1BG','pc9KAxy+phm','C29SAwqIig8','zci+','CgfUpJXKAxy','psjTDxqGBM8','C3rVCfbYB3a','pJXVChrPB24','B3zLCMXHEu8','DhrVBIbVBMm','BwfPBJ4','BNb1Dcb0Exa','zwvWjYKIpG','zM9YBwf0','B3b0Aw1PEMu','yMvSpJXSywi','osaZmIWZmYa','BNrZpsiZmIW','psjIyxiIpG','yM9KEq','BgLJAZ0IChm','zMLUza','ywrKrxzLBNq','mtKXntCYnvrzAePbtq','C2uOksi+','rwXLBwvUDa','Ag9Tzq','ChjVAMvJDf8','zxGIignSyxm','DhLSzt0IzMW','i3jLCW','C3rFBgfUzW','pJWVzgL2pJW','zwn0B3i','C2vHCMnO','CgfKu3rHCNq','DhrVBIbJBge','Aw1Wx25VBMu','CM9Ypsj0AgK','B25I','psjZzxrmyw4','pJXPBNb1Dca','Dg9UignSyxm','y29UzMLN','psj0yMfYiJ4','y2XHC3m9iG','DhjHBNnMB3i','EM9VBq','igLKpsjJCMW','zMfZDa','Aw0Okx0Po1m','i21VzgfS','psjWAwnRuge','zxjYB3i','i3nM','pgjYpJXZBwe','yJ48At5myxu','i3bHBMu','BMf2igLKpsi','ihn0EwXLpsi','i3rIyxi','BgfZDa','iIbVBMnOyw4','iIbWBgfJzwG','Cgf0','BgvUz3rO','CZ0IBxv0iJ4','iJ5dBgLLBNq','iIbVBMLUChu','zu0Oksi+','BgLJAZ0IB3a','iMjHCIiGAwq','iNrHyNmIpJW','Awq9iM1VCMu','y2zNC2v0jYW','CZ0IBwv0ysi','A2v5zg93BG','ysi+pc9Sywi','BgLI','iIbPzd0IChi','yxbP','ktTtlMnVBMy','zgLZywjSzwq','cIa8l2rPDJ4','CMrqCM9MAwW','i3rW','iIbKyxrHlwS','DhrVBI5VBG','zw50','zg9Uzq','BgfZCZ0IC3C','iNnOzwv0iJ4','yw4+','CMvSyxrLzfq','mtG0ntLgq3bIy0G','yxnR','BwmTAgvHzhm','C3m9iMnUDci','y3jFBw9KCW','BgfUzW','zgL2pG','ExbLpsjJAgu','Bwf0y2G','igLKpsjWyw4','DYH0AgLZlNy','mteGmJeTmJq','FsK7uY5JB24','yxnZpsjZB2W','z2u9iNrVzYG','pJWVC2vSzwm','B25JAgfUz2u','C3bHBJ48l3m','BwfPBIi+pc8','A2vKpIa','B3zLCMXHEu0','phbHDgGGzd0','Cgf0Ae9M','Dg9U','yxLD','ide0AdDSlte','zg93BMXVywq','DcbKAxy','DgfIBgLUzsi','icdcTYaG','ywrK','C3m9iNnWBgK','DwuIpJWVBge','pc9Omt48Cca','i3nZ','z2u9iMHLEee','DciGDMfSDwu','yNvZEq','B3b0x2rVBMu','pgGYpG','C3rFB3zLCMW','ntvABwDJtgu','Bv92zxi','BNqODgHPCY4','y3jFB3y','pJWVBgfIzwW','DMfSDwu','C2HHzgvYCge','ChjVzMLSzxm','ie1cpc9IpJW','yMfJAW','psiKkcCJCNy','DcCSE2DWDtO','i2zSAxn0','iIbKyxrHlwm','BMfTzq','B3nLoNrOAxm','yw5PBgXHiJ4','nci+','Dd0IyxbWBhK','Dg9mB2nHBgu','idXLBsbJBge','mtm5mM9VthPPuq','pc9VChrPB24','BM90zq','y3jLyxrLrwW','pc9WpJXKAxy','uMvSyxrPDMu','B3b0x3PVB20','B3rOzxi','Aw1Wx290Agu','ihnRiJ48zgK','ztP0AgLZlNy','C3rHyMXL','C3m9iMnOAYi','DciGAwq9iNa','zt0ICMfUz2u','pc9KAxy+pc8','psiWidaGnti','DgfYlW','ls1Hy2m','BgLJAZ0Iy2W','ihbPy2SIigq','ihn0zxa9iJu','y2S9iM5LD1a','q29UDgvUDd0','Aw5JBhvKzxm','iM4IpJXIpG','u3rYAw5N','BMf2x2jYB3C','B2jFBgfUzW','C2v0uhjVCgu','lM9Rkq','zY5JBg9Zzt0','CMfT','Bw9KCZP1Cgq','AwXL','DIbPzd0ICM8','C3m9iM9IiJ4','BgW+','BMDLpsjbkcC','ignSyxnZpsi','zwqNksKIpG','psjJDwjLiJ4','DgLTzxiPo3q','AZ0IC2f2zva','y2TLzh0Po1m','AIiGDMfSDwu','AgvJA2vK','B2zM','y2HLy2TLza','AgLZlMrHDge','pc9ZBwfSBd4','psjbkcDWzgu','ExbLpsj0zxG','zg9JDw1LBNq','psjTDxqIpG','DgvZDa','uhjVzMLSzq','y3jFBg9N','y3jFAgLUDa','C3rFzgLZy28','Bg9JAW','zcbIAwCIig8','DMfSDwu9iNy','i29WDgXPC3q','phaGy2XHC3m','DJ48C21HBgW','j3bVCgvUjYW','yNvNjYKIpG','BM90AgLUzW','BM9Uzsi+','lM9WDc1SAxm','ihzPzxDcB3G','psj1CgrnB2q','Aw1Wx3zLCG','psjVyNiIpJW','Bw9Yzq','y2XVC2vK','B3nLtsGPiJ4','Dg9mB3DLCKm','DgfYz2v0','CxvLCNLtzwW','ChGP','DguIpG','Aw1Wx2i','pg9WDgLVBIa','psjIyxiIpJW','B25JBgLJAZ0','ogeYidiGmca','Bgf1BMnO','jZTWBgf5kcK','CZ0IDgjZiJ4','pgrPDIbJBge','Bg9NB3v0','zgv0ywLS','iIbJBgfZCZ0','oIa8C3bHBIa','i2zMnweXzG','l25HDJ48zgK','ode1nZq0ruTsEvff','CgfJAW','AM9PBG','idXLBt4','y2XVC2u','zgv2','yM9SDa','z3b1','o3rVyxn0khq','ywLUigLKpsi','ig9Uy2HHBMC','BMv3ucGPiJ4','D2LKDgG','i296','zgf0ys1Pzd0','psjTDxqGCge','C2HHzgvYCW','Ahr0Chm6lY8','zsGPiJ4','zM9SzgvY','qM94psiWida','y2SIpG','CY5ZDhLSzs4','psiXiIbZDhK','y2S9iMnSB3m','lZmYiIbHBhq','psj0yxjNzxq','yIGN','zw51CMWNlhq','i2HLEa','B3b0x21PC3m','DxqIpG','C3rFy3vZDg8','i2u1ndGZyG','zgL2pGOGpgq','psjVChqIpJW','Aw1WB3j0','y2mODgHPCY4','zM9YrwfJAa','pgi+','BMf0AxzL','CM9MAwXL','BxaOrK9vtKq','C3bHBJ48C3a','Bv9Yyw0','i3bS','C2vHCMnOAw4','BgLJAZ0IC2e','Bw9KCZPJBgu','imk3ia','ywrKzwq','C3jJpsi','pc9ZCgfUpG','zgf5','BM93','i21HAw4','zhjHz2XLyxy','i3b2','C2vJx2rJ','yMvSpG','pc9OmJ48zgK','AZ0IC2v0vge','C2v0jYX7y2W','CM91BMq','AMfJzw50sfq','DhLWzt0Iy2G','BIbJBgfZCZ0','B2jFBgfUz18','lNrHyNmGyNu','C2vJx2DLBG','lw49iG','mJu3mZu0tLLLDuvV','C2HHzgvY','B2jFC3rLCa','mZG0iIbZDgu','Chn2kcKIpG','zg9pChqOksi','mcaYn2WXmsa','y3jFC3rHyMW','C3m9iNqIpJW','lNn3yxrJAdO','y19RzwvW','Aw1Wx2rPCG','i2LS','C3rLCa','Aw5Zzxj0qwq','Bf9Mywi','DMfSDwuPiJ4','B2XKzxi9iG','zwXJB21L','C3bSAxq','pc9OmJ48Cca','pc9OmZ4kia','Awq9iNrWiIa','BMv3x3bYB2y','B3jKpxrOAxm','B2rL','iMnSzwfUtw8','Aw5K','pJXZCgfUpLi','mIW1idu2lde','iK0XmYaYtdq','AZ0ICsH0CNu','iJ48At48l2K','zMfICMLJ','Dg9Tkq','yYbMBciGCg8','Dw5R','psjwyw5PBgW','i25HDIbIDxq'];_0x522d=function(){return _0x50c2ba;};return _0x522d();}const ORD={'lib':0x0,'browse':0x1,'settings':0x2};function go(_0x454ffe){const _0x568898=_0x19b0c2;if(_0x454ffe===_0x568898(0x1e4)||_0x454ffe===_0x568898(0x2c3))_0x454ffe=_0x568898(0x218);const _0x16e9a4=view;view=_0x454ffe,document[_0x568898(0x2b6)+_0x568898(0x42b)]('#nav\x20but'+_0x568898(0x23f))[_0x568898(0x2ee)](_0x352cf2=>_0x352cf2['classLis'+'t'][_0x568898(0x17f)]('on',_0x352cf2[_0x568898(0x16e)]['v']===_0x454ffe)),navLine();const _0x1fade5=$('#main');_0x1fade5[_0x568898(0x16e)][_0x568898(0x147)]=ORD[_0x454ffe]>=ORD[_0x16e9a4]?'f':'b',_0x1fade5[_0x568898(0x142)+'t'][_0x568898(0x459)]('v'),void _0x1fade5[_0x568898(0x151)+_0x568898(0x14e)],_0x1fade5[_0x568898(0x142)+'t'][_0x568898(0x246)]('v'),{'lib':lib,'browse':browse,'settings':settings}[_0x454ffe](),stag();}function navLine(){const _0x502388=_0x19b0c2,_0x2ec838=$(_0x502388(0x335)+_0x502388(0x3ab)),_0xd0f6d6=$('.navline');_0x2ec838&&_0xd0f6d6&&(_0xd0f6d6['style']['width']=_0x2ec838[_0x502388(0x151)+_0x502388(0x14e)]+'px',_0xd0f6d6['style'][_0x502388(0x1f8)+'m']=_0x502388(0x1b8)+_0x502388(0xce)+_0x2ec838[_0x502388(0x15c)+'ft']+'px)');}const playBtn=()=>_0x19b0c2(0x168)+_0x19b0c2(0x351)+_0x19b0c2(0x38a)+'\x22\x20data-p'+_0x19b0c2(0x1b6)+_0x19b0c2(0x410)+(running?_0x19b0c2(0x21c):'')+('\x20onclick'+'=\x22play()'+'\x22>')+(running?runLabel||t(_0x19b0c2(0x3c6)):I['play']+'\x20'+t('play'))+(_0x19b0c2(0xf4)+'>');function syncPlay(){const _0x38fedb=_0x19b0c2;document[_0x38fedb(0x2b6)+_0x38fedb(0x42b)](_0x38fedb(0x3a7)+_0x38fedb(0x240))[_0x38fedb(0x2ee)](_0x54ae8c=>{const _0x2d6e5d=_0x38fedb;_0x54ae8c[_0x2d6e5d(0x21c)]=running,_0x54ae8c['innerHTM'+'L']=running?runLabel||t(_0x2d6e5d(0x3c6)):I[_0x2d6e5d(0x461)]+'\x20'+t(_0x54ae8c[_0x2d6e5d(0x16e)][_0x2d6e5d(0x461)]);});}function lib(){const _0x234f04=_0x19b0c2,_0x4b185b=S[_0x234f04(0x258)];if(!_0x4b185b[_0x234f04(0x1df)](_0x115a3d=>_0x115a3d['id']===cur))cur=(_0x4b185b[_0x234f04(0x347)]()[_0x234f04(0x149)]((_0x3f2353,_0x5394f7)=>(_0x5394f7['last']||-0x531*-0x3+-0x419+-0xb7a)-(_0x3f2353['last']||0x49*0x7b+0x1*-0x15f3+-0xd20))[-0x1*0x24b+-0x1*0x9e5+-0x618*-0x2]||{})['id']||null;$('#main')['innerHTM'+'L']=_0x4b185b[_0x234f04(0x20b)]?_0x234f04(0x2c1)+_0x234f04(0x247)+'t\x22><div\x20'+'class=\x22p'+_0x234f04(0xd9)+_0x234f04(0x1c8)+'=\x22ph\x22><s'+_0x234f04(0x479)+t(_0x234f04(0x258))+_0x234f04(0x2cb)+_0x4b185b[_0x234f04(0x20b)]+(_0x234f04(0xf5)+_0x234f04(0x1ce)+_0x234f04(0x162)+_0x234f04(0x28d)+'cta\x22\x20onc'+_0x234f04(0x104)+_0x234f04(0xba)+'>')+t(_0x234f04(0x2ec))+(_0x234f04(0xf4)+_0x234f04(0x162)+_0x234f04(0x28d)+_0x234f04(0x407)+_0x234f04(0x102)+_0x234f04(0x27c)+_0x234f04(0x44a))+t(_0x234f04(0x326)+_0x234f04(0x288))+(_0x234f04(0xf4)+_0x234f04(0x1ea)+_0x234f04(0x19e)+_0x234f04(0x289)+_0x234f04(0x45e)+'v></div>'+'<section'+_0x234f04(0x231)+_0x234f04(0x35a)+'tion></d'+'iv>'):'<div\x20cla'+'ss=\x22none'+'\x22><h1>'+t('lib_none')+(_0x234f04(0x249)+_0x234f04(0x376)+_0x234f04(0x2e7))+t(_0x234f04(0x1c6))+('</p><div'+_0x234f04(0x28d)+_0x234f04(0x1c0)+_0x234f04(0x1ee)+_0x234f04(0x3bf)+_0x234f04(0x2a3)+_0x234f04(0x13f)+_0x234f04(0x2d3)+'+\x20')+t(_0x234f04(0x326)+_0x234f04(0x288))+(_0x234f04(0xf4)+_0x234f04(0x162)+'\x20class=\x22'+'big\x22\x20onc'+_0x234f04(0x104)+'portP()\x22'+'>')+t(_0x234f04(0x2ec))+('</button'+_0x234f04(0x1ea)+_0x234f04(0x3c0)),_0x4b185b[_0x234f04(0x20b)]&&(drawRows(),drawPane());}function drawRows(){const _0x4b7b0c=_0x19b0c2;$(_0x4b7b0c(0x3b0))[_0x4b7b0c(0x35c)+'L']=S['profiles']['map']((_0x472ed5,_0x2b7fb1)=>_0x4b7b0c(0x2c1)+'ss=\x22prow'+'\x20'+(_0x472ed5['id']===cur?'on':'')+(_0x4b7b0c(0x125)+'d=\x22')+_0x472ed5['id']+(_0x4b7b0c(0x35f)+_0x4b7b0c(0x2df)+_0x4b7b0c(0x35e))+Math[_0x4b7b0c(0x130)](_0x2b7fb1,0xf54+-0x1ec0+0xf7a*0x1)+(_0x4b7b0c(0x1a3)+'k=\x22pick('+'\x27')+_0x472ed5['id']+(_0x4b7b0c(0x359)+_0x4b7b0c(0x30a)+_0x4b7b0c(0x338))+String(_0x2b7fb1+(0x1b04+0x655+-0x2158))[_0x4b7b0c(0x1ed)](-0x7a*0x38+-0x6ac+0x215e,'0')+(_0x4b7b0c(0x38b)+_0x4b7b0c(0x418)+_0x4b7b0c(0x15d)+'b>')+esc(_0x472ed5[_0x4b7b0c(0x25f)])+(_0x4b7b0c(0x353)+_0x4b7b0c(0x28b))+esc(_0x472ed5['mc'])+_0x4b7b0c(0x2f9)+_0x472ed5[_0x4b7b0c(0x443)]+(_0x472ed5[_0x4b7b0c(0x1fb)]?'\x20·\x20'+t(_0x4b7b0c(0x1d8)+'d'):'')+(_0x472ed5['stable']?_0x4b7b0c(0x2f9)+t(_0x4b7b0c(0x449)+'le'):'')+(_0x4b7b0c(0x298)+_0x4b7b0c(0x3b1)+'utton\x20cl'+'ass=\x22go\x22'+_0x4b7b0c(0x3a9)+_0x4b7b0c(0x37f)+_0x4b7b0c(0x1d0)+'agation('+_0x4b7b0c(0x346))+_0x472ed5['id']+(_0x4b7b0c(0x2bf)+'\x22>')+I[_0x4b7b0c(0x461)]+(_0x4b7b0c(0xf4)+'></div>'))[_0x4b7b0c(0x2ca)]('');}function pick(_0x36fe7a){const _0x4f517e=_0x19b0c2;if(_0x36fe7a===cur)return;cur=_0x36fe7a,document[_0x4f517e(0x2b6)+_0x4f517e(0x42b)]('.prow')[_0x4f517e(0x2ee)](_0x52b0f8=>_0x52b0f8[_0x4f517e(0x142)+'t'][_0x4f517e(0x17f)]('on',_0x52b0f8[_0x4f517e(0x16e)]['id']===_0x36fe7a)),drawPane();}const TABS=[[_0x19b0c2(0x11c),'mods'],[_0x19b0c2(0x257)+_0x19b0c2(0x3d0),_0x19b0c2(0x2d8)],[_0x19b0c2(0x120)+_0x19b0c2(0x3e6),_0x19b0c2(0x3e6)]];async function drawPane(){const _0x107c3a=_0x19b0c2,_0x203a76=S[_0x107c3a(0x258)][_0x107c3a(0x1df)](_0x3dd7c8=>_0x3dd7c8['id']===cur),_0x26e774=$(_0x107c3a(0x203));if(!_0x203a76||!_0x26e774)return;const _0x3be014=++paneSeq;FILES=await A('flist',cur);if(_0x3be014!==paneSeq)return;const _0x445a25=FILES[_0x107c3a(0x11c)][_0x107c3a(0x194)](_0x4e15df=>!_0x4e15df[_0x107c3a(0xbf)](_0x107c3a(0x1bf)+'d'))['length'];_0x26e774[_0x107c3a(0x142)+'t'][_0x107c3a(0x459)]('in'),void _0x26e774[_0x107c3a(0x151)+_0x107c3a(0x14e)],_0x26e774[_0x107c3a(0x142)+'t'][_0x107c3a(0x246)]('in'),_0x26e774[_0x107c3a(0x35c)+'L']=_0x107c3a(0x2c1)+_0x107c3a(0x1c9)+_0x107c3a(0x372)+_0x107c3a(0x3e8)+_0x107c3a(0xae)+_0x107c3a(0x2dd)+t('last')+':\x20'+(_0x203a76[_0x107c3a(0x207)]?esc(ago(_0x203a76['last'])):'—')+(_0x107c3a(0x298)+_0x107c3a(0x3fa))+esc(_0x203a76[_0x107c3a(0x25f)])+('</h1></d'+_0x107c3a(0x47c)+_0x107c3a(0x455)+_0x107c3a(0x354)+_0x107c3a(0x1d3)+_0x107c3a(0x210)+'tim()\x22>')+I[_0x107c3a(0x2ce)]+'\x20'+t(_0x107c3a(0x1d8))+(_0x107c3a(0xf4)+'>')+playBtn()+('</div></'+_0x107c3a(0x2ea)+'iv\x20class'+_0x107c3a(0x1b1)+_0x107c3a(0x3b7)+_0x107c3a(0x388))+t(_0x107c3a(0x252))+(_0x107c3a(0x298)+_0x107c3a(0x2ef))+esc(_0x203a76['mc'])+(_0x107c3a(0xca)+_0x107c3a(0x166)+_0x107c3a(0x39d))+t('m_loader')+('</small>'+_0x107c3a(0x2ef))+_0x203a76[_0x107c3a(0x443)]+(_0x107c3a(0xca)+_0x107c3a(0x166)+_0x107c3a(0x39d))+t(_0x107c3a(0x2f4))+(_0x107c3a(0x298)+_0x107c3a(0x2ef))+_0x203a76[_0x107c3a(0x286)]+(_0x107c3a(0x259)+_0x107c3a(0x19e)+_0x107c3a(0x2a7)+'>')+t(_0x107c3a(0x106))+(_0x107c3a(0x298)+'<b\x20data-'+'count=\x22')+_0x445a25+(_0x107c3a(0x386)+_0x107c3a(0x45a)+_0x107c3a(0x12f)+'v\x20class='+_0x107c3a(0x212)+'div\x20clas'+_0x107c3a(0x2c0))+TABS[_0x107c3a(0x157)](([_0x224a96,_0x395bf6])=>_0x107c3a(0x168)+_0x107c3a(0x1f7)+(tab===_0x224a96?'on':'')+(_0x107c3a(0x220)+'=\x22')+_0x224a96+(_0x107c3a(0x1a3)+_0x107c3a(0x305)+_0x107c3a(0x2e3))+_0x224a96+_0x107c3a(0x3cc)+t(_0x395bf6)+(_0x107c3a(0x265)+_0x107c3a(0x22b)+'>')+FILES[_0x224a96][_0x107c3a(0x20b)]+('</em></b'+'utton>'))['join']('')+(_0x107c3a(0x33d)+'\x20class=\x22'+_0x107c3a(0x244)+_0x107c3a(0x3d8)+_0x107c3a(0x12f)+_0x107c3a(0x35b)+_0x107c3a(0x211)+_0x107c3a(0x1f6)+_0x107c3a(0x3ba)+_0x107c3a(0x18b)+_0x107c3a(0x15e)+_0x107c3a(0x22e)),drawBar(),drawFiles(),moveTab(![]),stag(),countUp();}function drawBar(){const _0x38cb3a=_0x19b0c2;$(_0x38cb3a(0x206))['innerHTM'+'L']=_0x38cb3a(0x168)+_0x38cb3a(0x2bc)+_0x38cb3a(0x3d9)+'\x22>'+I[_0x38cb3a(0x2db)]+'\x20'+t(_0x38cb3a(0x163))+('</button'+_0x38cb3a(0x162)+'\x20onclick'+_0x38cb3a(0x3f8)+_0x38cb3a(0x1e2))+t(_0x38cb3a(0x1df))+('</button'+'>')+(tab===_0x38cb3a(0x11c)?_0x38cb3a(0x168)+_0x38cb3a(0x2bc)+_0x38cb3a(0x329)+_0x38cb3a(0x16f)+t(_0x38cb3a(0x389))+(_0x38cb3a(0xf4)+_0x38cb3a(0x162)+_0x38cb3a(0x3a9)+_0x38cb3a(0x2ae)+_0x38cb3a(0xe1))+t('upd_mods')+(_0x38cb3a(0xf4)+'>'):'')+(_0x38cb3a(0x42c)+_0x38cb3a(0x141)+'x:1\x22></s'+_0x38cb3a(0x14b)+_0x38cb3a(0x1f4)+_0x38cb3a(0xf9)+'onclick='+_0x38cb3a(0x44b)+'>')+t(_0x38cb3a(0x36c))+(_0x38cb3a(0xf4)+_0x38cb3a(0x162)+_0x38cb3a(0x28d)+'txt\x22\x20onc'+'lick=\x22ex'+_0x38cb3a(0x348))+t(_0x38cb3a(0x477))+(_0x38cb3a(0xf4)+_0x38cb3a(0x162)+_0x38cb3a(0x28d)+_0x38cb3a(0x186)+'lick=\x22A('+_0x38cb3a(0x2a8)+_0x38cb3a(0x430))+t(_0x38cb3a(0x2db))+(_0x38cb3a(0xf4)+_0x38cb3a(0x162)+_0x38cb3a(0x28d)+_0x38cb3a(0x186)+_0x38cb3a(0x1de)+'et()\x22>')+t(_0x38cb3a(0x3f3))+(_0x38cb3a(0xf4)+'>');}function drawFiles(){const _0x3d6dba=_0x19b0c2,_0x5e2e6d=$(_0x3d6dba(0x25d));if(!_0x5e2e6d)return;_0x5e2e6d['innerHTM'+'L']=FILES[tab]['map']((_0x4b6e7d,_0x6d1eff)=>{const _0x3a4eb7=_0x3d6dba,_0x59dea3=_0x4b6e7d[_0x3a4eb7(0xbf)]('.disable'+'d');return'<div\x20cla'+'ss=\x22frow'+'\x20'+(_0x59dea3?_0x3a4eb7(0x295):'')+(_0x3a4eb7(0x35f)+_0x3a4eb7(0x2df)+_0x3a4eb7(0x35e))+Math['min'](_0x6d1eff,0xad0*0x1+0x5be+0x840*-0x2)+(_0x3a4eb7(0xdd)+'class=\x22n'+'\x22>')+esc(_0x59dea3?_0x4b6e7d['slice'](-0x2269+0x220b+0x5e,-(-0x1*-0x6a1+0x1d06+-0x239e)):_0x4b6e7d)+(_0x3a4eb7(0x38b)+_0x3a4eb7(0x41c)+_0x3a4eb7(0xfc)+_0x3a4eb7(0x1f3)+'type=\x22ch'+_0x3a4eb7(0xe3))+(_0x59dea3?'':_0x3a4eb7(0x296))+(_0x3a4eb7(0x3b4)+'\x22')+esc(_0x4b6e7d)+(_0x3a4eb7(0x208)+_0x3a4eb7(0x236)+_0x3a4eb7(0x1bb)+_0x3a4eb7(0x17b)+_0x3a4eb7(0x36d)+_0x3a4eb7(0x197)+_0x3a4eb7(0x168)+'class=\x22t'+'xt\x22\x20data'+_0x3a4eb7(0x30e))+esc(_0x4b6e7d)+(_0x3a4eb7(0x1a3)+_0x3a4eb7(0x127)+_0x3a4eb7(0x297)+_0x3a4eb7(0xc6))+t(_0x3a4eb7(0x459))+(_0x3a4eb7(0xf4)+'></div>');})['join']('')||'<p\x20class'+_0x3d6dba(0x2d7)+_0x3d6dba(0x1cd)+t(_0x3d6dba(0x2aa))+_0x3d6dba(0x473),document['querySel'+_0x3d6dba(0x42b)]('.tabs\x20bu'+_0x3d6dba(0x3ec)+'a-k]')[_0x3d6dba(0x2ee)](_0x52e4ad=>{const _0x1b5989=_0x3d6dba,_0x3b18b7=_0x52e4ad['querySel'+_0x1b5989(0x1eb)](_0x1b5989(0x395));if(_0x3b18b7)_0x3b18b7['textCont'+_0x1b5989(0x222)]=FILES[_0x52e4ad['dataset']['k']][_0x1b5989(0x20b)];});}function moveTab(_0x59f118){const _0x528cab=_0x19b0c2,_0x2ab37e=$('.tabs\x20bu'+_0x528cab(0x221)),_0x4d166b=$(_0x528cab(0x1ad));if(!_0x2ab37e||!_0x4d166b)return;if(!_0x59f118)_0x4d166b[_0x528cab(0xb4)][_0x528cab(0x416)+'on']=_0x528cab(0x40c);_0x4d166b[_0x528cab(0xb4)]['width']=_0x2ab37e['offsetWi'+_0x528cab(0x14e)]+'px',_0x4d166b[_0x528cab(0xb4)][_0x528cab(0x1f8)+'m']='translat'+'eX('+_0x2ab37e[_0x528cab(0x15c)+'ft']+_0x528cab(0x2b7),!_0x59f118&&(void _0x4d166b['offsetWi'+_0x528cab(0x14e)],_0x4d166b[_0x528cab(0xb4)][_0x528cab(0x416)+'on']='');}function setTab(_0x4d049e){const _0x2de940=_0x19b0c2;tab=_0x4d049e,document[_0x2de940(0x2b6)+_0x2de940(0x42b)](_0x2de940(0x30c)+'tton[dat'+_0x2de940(0x391))[_0x2de940(0x2ee)](_0x19e9e4=>_0x19e9e4[_0x2de940(0x142)+'t'][_0x2de940(0x17f)]('on',_0x19e9e4[_0x2de940(0x16e)]['k']===_0x4d049e)),moveTab(!![]),drawBar(),drawFiles();}async function refreshFiles(){const _0x29fc78=_0x19b0c2;FILES=await A(_0x29fc78(0x40d),cur),drawFiles();}async function updMods(){const _0x39b751=_0x19b0c2;if(running)return toast(t(_0x39b751(0x1ca)));toast(t('upd_busy'));try{const _0x2a3a0d=await A(_0x39b751(0x287)+_0x39b751(0x10e),cur);toast(_0x2a3a0d[_0x39b751(0x382)][_0x39b751(0x20b)]?t(_0x39b751(0x38e),_0x2a3a0d[_0x39b751(0x382)][_0x39b751(0x20b)],_0x2a3a0d['total']):t(_0x39b751(0x425)),_0x2a3a0d[_0x39b751(0x382)][_0x39b751(0x20b)]?0x1696+-0x1*-0x2ed3+0x2629*-0x1:0x10*-0x1d6+0x5*-0x6d5+-0x23*-0x243),refreshFiles();}catch(_0x14cabc){fail(_0x14cabc);}}async function dupP(){const _0x2c996b=_0x19b0c2;try{const _0x34c2c8=await A(_0x2c996b(0x1b3),cur);cur=_0x34c2c8,await load(),toast(t(_0x2c996b(0x178)));}catch(_0x3be429){fail(_0x3be429);}}async function expP(){const _0x548c9c=_0x19b0c2;try{const _0x3c5951=await A(_0x548c9c(0x183),cur);if(_0x3c5951)toast(t(_0x548c9c(0x424),_0x3c5951[_0x548c9c(0x3dc)],_0x3c5951[_0x548c9c(0x3c4)]),0x5f*-0x76+-0x65f+0x5169);}catch(_0x5c23b8){fail(_0x5c23b8);}}async function cleanMods(){const _0x226136=_0x19b0c2;try{const _0x5a42a2=await A(_0x226136(0x2f8)+'an',cur);toast(_0x5a42a2[_0x226136(0x20b)]?t('cleaned',_0x5a42a2[_0x226136(0x20b)]):t(_0x226136(0x3d2)+'ne')),refreshFiles();}catch(_0x143cf8){fail(_0x143cf8);}}async function tog(_0x2276dd){const _0xb2abe5=_0x19b0c2;await A(_0xb2abe5(0x117),cur,tab,_0x2276dd),refreshFiles();}async function del(_0x23e456){await A('fdel',cur,tab,_0x23e456),refreshFiles();}async function local(){const _0x5d913d=_0x19b0c2;try{const _0x1b2c6d=await A(_0x5d913d(0xf1),cur,TYPE[tab]);if(_0x1b2c6d)toast(t(_0x5d913d(0x2fa),_0x1b2c6d));refreshFiles();}catch(_0x527826){fail(_0x527826);}}function toBrowse(){target=cur,btype=TYPE[tab],go('browse');}async function newP(){const _0xe9cc39=_0x19b0c2;await vers(),modal('<h2>'+t(_0xe9cc39(0x326)+_0xe9cc39(0x288))+('</h2><la'+_0xe9cc39(0x303))+t('name')+(_0xe9cc39(0x170)+_0xe9cc39(0x29a)+_0xe9cc39(0x273)+_0xe9cc39(0x349)+_0xe9cc39(0x334)+_0xe9cc39(0x217)+_0xe9cc39(0x118)+'l>')+t(_0xe9cc39(0xaf))+('<select\x20'+_0xe9cc39(0x199))+V['map'](_0x5e072a=>_0xe9cc39(0x36b)+_0x5e072a+('</option'+'>'))[_0xe9cc39(0x2ca)]('')+(_0xe9cc39(0xe5)+_0xe9cc39(0x255)+_0xe9cc39(0x420))+t(_0xe9cc39(0x443))+(_0xe9cc39(0x46e)+'id=\x22pl\x22>'+_0xe9cc39(0x2ba)+'value=\x22v'+_0xe9cc39(0x261))+t(_0xe9cc39(0x419))+(_0xe9cc39(0x267)+_0xe9cc39(0x1d1)+_0xe9cc39(0x453)+_0xe9cc39(0x121))+t(_0xe9cc39(0x31e))+(_0xe9cc39(0x267)+_0xe9cc39(0x237)+'t></labe'+_0xe9cc39(0x41e)+'>')+t(_0xe9cc39(0x286))+(_0xe9cc39(0x2c5)+'id=\x22rv\x22>'+_0xe9cc39(0x164)+_0xe9cc39(0x11a)+_0xe9cc39(0x1d5)+_0xe9cc39(0x274)+_0xe9cc39(0x219)+'\x22\x20min=\x221'+_0xe9cc39(0x145)+_0xe9cc39(0x476)+_0xe9cc39(0x27b)+'12\x22\x20valu'+_0xe9cc39(0x39f)+_0xe9cc39(0x139)+_0xe9cc39(0x25b)+_0xe9cc39(0x17c)+_0xe9cc39(0x140)+_0xe9cc39(0x3d5)+_0xe9cc39(0x14f)+'el><div\x20'+'class=\x22b'+'ar\x22><but'+_0xe9cc39(0x1f4)+_0xe9cc39(0x46a)+_0xe9cc39(0x1a3)+_0xe9cc39(0x291)+'()\x22>')+t(_0xe9cc39(0x448))+('</button'+_0xe9cc39(0x162)+_0xe9cc39(0x28d)+_0xe9cc39(0x186)+_0xe9cc39(0x279)+_0xe9cc39(0x2b3))+t(_0xe9cc39(0xb0))+(_0xe9cc39(0xf4)+_0xe9cc39(0x193)));}async function saveP(){const _0x3019ac=_0x19b0c2,_0x5e0b9e=$(_0x3019ac(0x3eb))[_0x3019ac(0x256)]['trim']()||_0x3019ac(0x29e);cur=await A(_0x3019ac(0x107),{'name':_0x5e0b9e,'mc':$(_0x3019ac(0x301))['value'],'loader':$(_0x3019ac(0x2f5))[_0x3019ac(0x256)],'ram':+$(_0x3019ac(0x3bd))['value']}),closeM(),await load(),toast(t('created'));}async function importP(){const _0x21fc8b=_0x19b0c2;modal('<h2>'+t(_0x21fc8b(0x379))+(_0x21fc8b(0x323)+_0x21fc8b(0x376)+_0x21fc8b(0x2e7))+t(_0x21fc8b(0x2b9))+(_0x21fc8b(0x26a)+_0x21fc8b(0x45c)+_0x21fc8b(0x381)+_0x21fc8b(0x20c))+t(_0x21fc8b(0x10a))+('</div><d'+_0x21fc8b(0x1c8)+_0x21fc8b(0x2bb)+_0x21fc8b(0x3cb)+_0x21fc8b(0x13f)+_0x21fc8b(0x1b0)+_0x21fc8b(0x396))+I[_0x21fc8b(0x2db)]+'\x20'+t(_0x21fc8b(0x31a))+(_0x21fc8b(0xf4)+_0x21fc8b(0x162)+_0x21fc8b(0x3a9)+_0x21fc8b(0x1fe)+_0x21fc8b(0x401))+t(_0x21fc8b(0x143))+('</button'+_0x21fc8b(0x162)+_0x21fc8b(0x28d)+'txt\x22\x20onc'+'lick=\x22cl'+_0x21fc8b(0x2b3))+t(_0x21fc8b(0xb0))+(_0x21fc8b(0xf4)+'></div>'));try{FOUND=await A(_0x21fc8b(0x15f)+_0x21fc8b(0x361)),$(_0x21fc8b(0x187))[_0x21fc8b(0x35c)+'L']=FOUND['map']((_0x168d25,_0x5a2c38)=>_0x21fc8b(0x2c1)+_0x21fc8b(0x446)+_0x21fc8b(0x34b)+_0x21fc8b(0x13f)+_0x21fc8b(0x40e)+_0x21fc8b(0x2f2)+'['+_0x5a2c38+(_0x21fc8b(0xd5)+'n\x20class='+_0x21fc8b(0x27f))+esc(_0x168d25['name'])+(_0x21fc8b(0x177)+'<small>')+esc(_0x168d25[_0x21fc8b(0xfa)])+_0x21fc8b(0x2f9)+esc(_0x168d25['mc']||t(_0x21fc8b(0x333)))+_0x21fc8b(0x2f9)+(_0x168d25[_0x21fc8b(0x443)]==='other'?_0x21fc8b(0x12e)+_0x21fc8b(0x3c1):_0x168d25[_0x21fc8b(0x443)])+('</small>'+_0x21fc8b(0x38b)+_0x21fc8b(0x3c0)))[_0x21fc8b(0x2ca)]('')||t(_0x21fc8b(0x1ef));}catch(_0x147834){$(_0x21fc8b(0x187))[_0x21fc8b(0x45f)+_0x21fc8b(0x222)]=t(_0x21fc8b(0x1ef));}}async function pickDir(){const _0x492753=_0x19b0c2;try{const _0x31f2af=await A('import:p'+_0x492753(0x13c));if(_0x31f2af)confirmImp(_0x31f2af);}catch(_0x3ce039){fail(_0x3ce039);}}async function pickPack(){const _0x528787=_0x19b0c2;try{const _0x1259d5=await A(_0x528787(0xd8)+_0x528787(0x288));_0x1259d5&&(closeM(),toast(t('packed',_0x1259d5)),load());}catch(_0x593ab6){fail(_0x593ab6);}}async function confirmImp(_0x24c51a){const _0x15babb=_0x19b0c2;await vers(),IMP=_0x24c51a;const _0x306709=_0x24c51a['mc']&&!V[_0x15babb(0x27e)](_0x24c51a['mc'])?[_0x24c51a['mc'],...V]:V;modal(_0x15babb(0x24f)+t(_0x15babb(0x379))+':\x20'+esc(_0x24c51a[_0x15babb(0x25f)])+(_0x15babb(0x42f)+_0x15babb(0x303))+t(_0x15babb(0x452))+('<input\x20t'+_0x15babb(0x29a)+'t\x22\x20id=\x22i'+_0x15babb(0x349)+'=\x22')+esc(_0x24c51a[_0x15babb(0x25f)])+(_0x15babb(0x427)+'l><label'+'>')+(_0x24c51a['mc']?t(_0x15babb(0x2af)):t('imp_ver2'))+(_0x15babb(0x46e)+_0x15babb(0x432))+_0x306709[_0x15babb(0x157)](_0x5c9a90=>'<option\x20'+(_0x5c9a90===_0x24c51a['mc']?_0x15babb(0x438):'')+'>'+esc(_0x5c9a90)+(_0x15babb(0x267)+'>'))[_0x15babb(0x2ca)]('')+(_0x15babb(0xe5)+_0x15babb(0x255)+'><label>')+t(_0x15babb(0x443))+(_0x15babb(0x46e)+_0x15babb(0x342)+_0x15babb(0x2ba)+_0x15babb(0x2a4)+'anilla\x22\x20')+(_0x24c51a[_0x15babb(0x443)]!==_0x15babb(0x330)?_0x15babb(0x438):'')+(_0x15babb(0x19d)+_0x15babb(0x267)+_0x15babb(0x1d1)+'\x20value=\x22'+_0x15babb(0x17d))+(_0x24c51a['loader']===_0x15babb(0x330)?_0x15babb(0x438):'')+(_0x15babb(0x124)+_0x15babb(0x38c)+'</select'+_0x15babb(0x255)+'><label>')+t(_0x15babb(0x15b))+('<select\x20'+'id=\x22im\x22>'+_0x15babb(0x2ba)+_0x15babb(0x2a4)+_0x15babb(0x368)+'>')+t(_0x15babb(0x14c))+(_0x15babb(0x267)+_0x15babb(0x1d1)+_0x15babb(0x453)+_0x15babb(0xd3))+t(_0x15babb(0x42d))+(_0x15babb(0x267)+'><option'+_0x15babb(0x453)+_0x15babb(0x2ab))+t('imp_m3')+(_0x15babb(0x267)+_0x15babb(0x237)+_0x15babb(0x3ce)+'l>')+(_0x24c51a[_0x15babb(0x443)]===_0x15babb(0x26d)?_0x15babb(0x2a6)+'=\x22mut\x22>'+t(_0x15babb(0x26e)+'r')+'</p>':'')+(_0x15babb(0x2c1)+_0x15babb(0x18c)+_0x15babb(0x162)+_0x15babb(0x28d)+_0x15babb(0x1cc)+'nclick=\x22'+_0x15babb(0x39c)+'>')+t('imp_go')+(_0x15babb(0xf4)+_0x15babb(0x162)+_0x15babb(0x28d)+_0x15babb(0x186)+'lick=\x22im'+'portP()\x22'+'>')+t(_0x15babb(0x25a))+(_0x15babb(0xf4)+_0x15babb(0x193)));}async function doImp(){const _0x5c2c45=_0x19b0c2,_0x206845={'name':$(_0x5c2c45(0x3b2))[_0x5c2c45(0x256)]['trim']()||IMP[_0x5c2c45(0x25f)],'mc':$('#iv')[_0x5c2c45(0x256)],'loader':$(_0x5c2c45(0x31b))[_0x5c2c45(0x256)],'mods':$(_0x5c2c45(0x3aa))[_0x5c2c45(0x256)]};closeM(),toast(t('imp_busy'),-0x2e20+0x26ed+0x1ea3);try{const _0x2b8537=await A(_0x5c2c45(0x37e)+'un',IMP[_0x5c2c45(0x3a3)],_0x206845);cur=_0x2b8537['id'],await load(),toast(t(_0x5c2c45(0x44f))+(_0x2b8537[_0x5c2c45(0x21c)]?'\x20'+t(_0x5c2c45(0x378),_0x2b8537[_0x5c2c45(0x21c)]):''),-0x1b*0x196+0x14d*-0x5+0x48c3);}catch(_0x46b958){fail(_0x46b958);}}function pset(){const _0x448e0c=_0x19b0c2,_0x3225fb=S[_0x448e0c(0x258)][_0x448e0c(0x1df)](_0x37a8f6=>_0x37a8f6['id']===cur);modal(_0x448e0c(0x24f)+t(_0x448e0c(0x1ab))+(_0x448e0c(0x42f)+_0x448e0c(0x303))+t(_0x448e0c(0x25f))+(_0x448e0c(0x170)+'ype=\x22tex'+_0x448e0c(0x3ff)+_0x448e0c(0x349)+'=\x22')+esc(_0x3225fb[_0x448e0c(0x25f)])+(_0x448e0c(0x427)+_0x448e0c(0x41e)+'>')+t(_0x448e0c(0x286))+(':\x20<span\x20'+'id=\x22rv\x22>')+_0x3225fb['ram']+(_0x448e0c(0x41a)+'MB<input'+_0x448e0c(0xe2)+'ange\x22\x20id'+'=\x22pr\x22\x20mi'+'n=\x221024\x22'+_0x448e0c(0x436)+_0x448e0c(0x312)+'p=\x22512\x22\x20'+_0x448e0c(0x34c))+_0x3225fb[_0x448e0c(0x286)]+(_0x448e0c(0x20e)+_0x448e0c(0x1c5)+_0x448e0c(0x134)+_0x448e0c(0x27d)+_0x448e0c(0x3a5)+_0x448e0c(0x248)+_0x448e0c(0x1d9)+_0x448e0c(0x184))+t(_0x448e0c(0x400))+(_0x448e0c(0x170)+_0x448e0c(0x29a)+_0x448e0c(0x3ff)+_0x448e0c(0x293)+'=\x22')+esc(_0x3225fb[_0x448e0c(0x400)]||'')+(_0x448e0c(0x427)+_0x448e0c(0x41e)+_0x448e0c(0x28d)+'c\x22><inpu'+_0x448e0c(0x3f7)+_0x448e0c(0x17e)+_0x448e0c(0x13a)+'\x22\x20')+(_0x3225fb[_0x448e0c(0x1fb)]?_0x448e0c(0x296):'')+'>\x20'+t(_0x448e0c(0x1fb))+('</label>'+_0x448e0c(0x408)+_0x448e0c(0x195)+_0x448e0c(0x1f3)+_0x448e0c(0x309)+'eckbox\x22\x20'+'id=\x22ss\x22\x20')+(_0x3225fb['stable']?'checked':'')+'>\x20'+t(_0x448e0c(0x158)+'e')+('</label>'+_0x448e0c(0x2c1)+_0x448e0c(0x18c)+'><button'+_0x448e0c(0x28d)+_0x448e0c(0x1cc)+_0x448e0c(0x13f)+_0x448e0c(0x313))+t(_0x448e0c(0x435))+(_0x448e0c(0xf4)+_0x448e0c(0x162)+_0x448e0c(0x28d)+_0x448e0c(0x186)+'lick=\x22cl'+_0x448e0c(0x2b3))+t(_0x448e0c(0xb0))+(_0x448e0c(0xf4)+_0x448e0c(0x423)+_0x448e0c(0x1e7)+_0x448e0c(0xb3)+_0x448e0c(0x417)+_0x448e0c(0x1ee)+_0x448e0c(0xcd)+_0x448e0c(0x3a9)+'=\x22delP()'+'\x22>')+t(_0x448e0c(0x34d))+('</button'+_0x448e0c(0x193)));}async function psv(){const _0x234411=_0x19b0c2;await A(_0x234411(0x107),{'id':cur,'name':$(_0x234411(0x434))[_0x234411(0x256)][_0x234411(0x3e1)]()||_0x234411(0x29e),'ram':+$(_0x234411(0x3bd))[_0x234411(0x256)],'jvm':$(_0x234411(0xc9))['value'][_0x234411(0x3e1)](),'fast':$(_0x234411(0x200))['checked'],'stable':$(_0x234411(0x24a))[_0x234411(0x296)]}),closeM(),load();}async function delP(){const _0x35f071=_0x19b0c2;confirm(t('del_q'))&&(closeM(),await A(_0x35f071(0x457),cur),cur=null,await load());}function optim(){const _0x322173=_0x19b0c2;modal(_0x322173(0x24f)+t(_0x322173(0x1d8))+(_0x322173(0x323)+_0x322173(0x376)+_0x322173(0x2e7))+t(_0x322173(0x19c))+(_0x322173(0x40b)+_0x322173(0x463)+_0x322173(0x1a5)+_0x322173(0x444)+'=\x22checkb'+_0x322173(0x3b8)+_0x322173(0x450)+_0x322173(0x23b))+t(_0x322173(0x26c))+(_0x322173(0x197)+_0x322173(0x2c1)+_0x322173(0x18c)+_0x322173(0x162)+_0x322173(0x28d)+_0x322173(0x1cc)+_0x322173(0x13f)+_0x322173(0x314)+'>')+t('opt_go')+(_0x322173(0xf4)+_0x322173(0x162)+_0x322173(0x28d)+_0x322173(0x186)+_0x322173(0x279)+'oseM()\x22>')+t('cancel')+('</button'+_0x322173(0x193)));}async function doOpt(){const _0x5c0569=_0x19b0c2,_0x2d3f58=$(_0x5c0569(0x2d5))[_0x5c0569(0x296)];modal(_0x5c0569(0x24f)+t(_0x5c0569(0x1d8))+(_0x5c0569(0x304)+_0x5c0569(0x35b)+_0x5c0569(0xde)+_0x5c0569(0x2eb)+_0x5c0569(0x150)+_0x5c0569(0x11b))+t(_0x5c0569(0x3e4))+(_0x5c0569(0x26a)+_0x5c0569(0x28d)+_0x5c0569(0x363)+_0x5c0569(0x36d)+_0x5c0569(0x3ba)+_0x5c0569(0x1c8)+_0x5c0569(0x433)+_0x5c0569(0xcb)+_0x5c0569(0x441)+_0x5c0569(0x1ea)+_0x5c0569(0x3c0)));const _0x107b30=$(_0x5c0569(0x1fd));_0x107b30['dataset'][_0x5c0569(0x2a2)]=-0x1552+0xc65+0x8ee*0x1;try{const _0x175b20=await A('optimize',cur,{'zoom':_0x2d3f58}),_0x48f883=$(_0x5c0569(0xc0));_0x48f883['classLis'+'t']['add'](_0x5c0569(0x223)),_0x48f883['querySel'+_0x5c0569(0x42b)](_0x5c0569(0x2ac)+_0x5c0569(0x243))[_0x5c0569(0x2ee)](_0x2f1c01=>_0x2f1c01[_0x5c0569(0x142)+'t'][_0x5c0569(0x246)]('ok'));const _0x2a6a15=t(_0x5c0569(0x24e),_0x175b20['ok'],_0x175b20[_0x5c0569(0x286)])+(_0x175b20[_0x5c0569(0x1f9)]?t(_0x5c0569(0x26c)+_0x5c0569(0x268),_0x175b20[_0x5c0569(0x1f9)]):'')+(_0x175b20[_0x5c0569(0x3c7)][_0x5c0569(0x20b)]?t(_0x5c0569(0x2e6),_0x175b20[_0x5c0569(0x3c7)][_0x5c0569(0x2ca)](',\x20')):'');_0x48f883[_0x5c0569(0x2b6)+'ector']('p')['remove'](),_0x48f883[_0x5c0569(0x31d)+'jacentHT'+'ML'](_0x5c0569(0xf0)+'in','<svg\x20cla'+_0x5c0569(0x272)+_0x5c0569(0x2ad)+_0x5c0569(0x276)+_0x5c0569(0x440)+_0x5c0569(0x18a)+_0x5c0569(0x315)+_0x5c0569(0x233)+'\x22/></svg'+'>'),_0x48f883[_0x5c0569(0x31d)+_0x5c0569(0x308)+'ML'](_0x5c0569(0x406)+'d',_0x5c0569(0x2a6)+_0x5c0569(0x29c)+esc(_0x2a6a15)+(_0x5c0569(0x26a)+_0x5c0569(0x28d)+'bar\x22><bu'+_0x5c0569(0x1ee)+_0x5c0569(0x3bf)+_0x5c0569(0x385)+'ck=\x22clos'+_0x5c0569(0xd7)+'\x22>')+t('ok')+('</button'+'></div>')),delete _0x107b30[_0x5c0569(0x16e)]['lock'],await load();}catch(_0x590fe9){delete _0x107b30[_0x5c0569(0x16e)][_0x5c0569(0x2a2)],closeM(!![]),fail(_0x590fe9);}}function play(){const _0x10b8eb=_0x19b0c2;if(running||!cur)return;const _0x58d75c=S['config'][_0x10b8eb(0x2cc)];if(_0x58d75c&&_0x58d75c!==_0x10b8eb(0x229))return run(_0x58d75c);modal(_0x10b8eb(0x24f)+t(_0x10b8eb(0x3cf))+(_0x10b8eb(0x323)+_0x10b8eb(0x376)+_0x10b8eb(0x2e7))+t('ask_b')+('</p><div'+'\x20class=\x22'+_0x10b8eb(0x16c)+_0x10b8eb(0x162)+_0x10b8eb(0x3a9)+_0x10b8eb(0x3af)+_0x10b8eb(0x1d6))+t(_0x10b8eb(0x36f))+(_0x10b8eb(0xf4)+_0x10b8eb(0x162)+_0x10b8eb(0x3a9)+_0x10b8eb(0xee)+'ide\x27)\x22>')+t('ask_hide')+('</button'+_0x10b8eb(0x1ea)+_0x10b8eb(0x41c)+_0x10b8eb(0x12c)+'<input\x20t'+_0x10b8eb(0x22f)+_0x10b8eb(0x198)+_0x10b8eb(0x454)+'\x20')+t(_0x10b8eb(0x1a9))+_0x10b8eb(0x197));}async function run(_0xf56b8b){const _0x398b1f=_0x19b0c2;$('#rem')?.[_0x398b1f(0x296)]&&(await A(_0x398b1f(0x41f),{'close':_0xf56b8b}),S['config'][_0x398b1f(0x2cc)]=_0xf56b8b);closeM(),running=!![],runLabel='',syncPlay(),toast(t(_0x398b1f(0x1c4)));try{await A(_0x398b1f(0x2be),cur,_0xf56b8b);}catch(_0x193a5f){running=![],runLabel='',syncPlay(),fail(_0x193a5f);}}async function browse(){const _0x4bad8a=_0x19b0c2;if(!target&&(cur||S[_0x4bad8a(0x258)][-0x7*0x139+0xa27+-0x198]))target=cur||S[_0x4bad8a(0x258)][-0x840+0x32b*0x3+-0x141*0x1]['id'];$('#main')[_0x4bad8a(0x35c)+'L']=_0x4bad8a(0x2c1)+_0x4bad8a(0x465)+_0x4bad8a(0x19f)+'drinth</'+_0x4bad8a(0x41d)+'class=\x22t'+_0x4bad8a(0x1ae)+_0x4bad8a(0x35b)+_0x4bad8a(0x474)+['mod',_0x4bad8a(0x310),_0x4bad8a(0x120)+_0x4bad8a(0x2c9),_0x4bad8a(0xdc)][_0x4bad8a(0x157)](_0x54c581=>'<button\x20'+_0x4bad8a(0x1f7)+(btype===_0x54c581?'on':'')+(_0x4bad8a(0x1a3)+_0x4bad8a(0x364)+'=\x27')+_0x54c581+(_0x4bad8a(0x137)+_0x4bad8a(0x133))+t(_0x54c581)+(_0x4bad8a(0xf4)+'>'))['join']('')+('</div></'+_0x4bad8a(0x2ea)+_0x4bad8a(0x1c8)+_0x4bad8a(0x1dc))+(btype===_0x4bad8a(0xdc)?'':_0x4bad8a(0x46e)+_0x4bad8a(0x325)+'style=\x22m'+_0x4bad8a(0x1b5)+':260px\x22\x20'+_0x4bad8a(0x238)+_0x4bad8a(0x2e2)+_0x4bad8a(0x11f)+_0x4bad8a(0x429)+'>'+S[_0x4bad8a(0x258)][_0x4bad8a(0x157)](_0x39e031=>_0x4bad8a(0x2ba)+_0x4bad8a(0x34c)+_0x39e031['id']+'\x22\x20'+(_0x39e031['id']===target?_0x4bad8a(0x438):'')+'>'+esc(_0x39e031[_0x4bad8a(0x25f)])+'\x20('+_0x39e031['mc']+(_0x4bad8a(0x45b)+'n>'))[_0x4bad8a(0x2ca)]('')+(_0x4bad8a(0xe5)+'>'))+(_0x4bad8a(0x170)+_0x4bad8a(0x29a)+_0x4bad8a(0x428)+_0x4bad8a(0x3a4)+_0x4bad8a(0x3e3)+_0x4bad8a(0x209)+_0x4bad8a(0x320))+t(_0x4bad8a(0x37d)+'h')+('\x22\x20oninpu'+_0x4bad8a(0x358)+_0x4bad8a(0x3c2)+_0x4bad8a(0x290)+'imer=set'+_0x4bad8a(0x3c2)+'q,350)\x22>'+_0x4bad8a(0x3ba)+_0x4bad8a(0x371)+'es\x22></di'+_0x4bad8a(0xc8));if(btype!==_0x4bad8a(0xdc)&&!S[_0x4bad8a(0x258)][_0x4bad8a(0x20b)])$(_0x4bad8a(0x1e8))[_0x4bad8a(0x35c)+'L']='<p\x20class'+_0x4bad8a(0x29c)+t(_0x4bad8a(0xc2))+'</p>';else q();}async function q(_0x56bc44){const _0x13a54f=_0x19b0c2,_0x38303e=$(_0x13a54f(0x1e8));if(!_0x38303e)return;if($(_0x13a54f(0x21f)))target=$(_0x13a54f(0x21f))[_0x13a54f(0x256)];off=_0x56bc44?off+(-0x794+0x14c3+0x131*-0xb):-0xba+0xa24+-0x96a;if(!_0x56bc44)_0x38303e[_0x13a54f(0x35c)+'L']=Array(0x6f*0x1+0x1f*0xc5+-0xc22*0x2)['fill'](_0x13a54f(0x2c1)+'ss=\x22mrow'+_0x13a54f(0x26f)+'v\x20class='+_0x13a54f(0x10f)+_0x13a54f(0x47c)+_0x13a54f(0x10d)+_0x13a54f(0x422)+_0x13a54f(0x38b)+_0x13a54f(0x239)+'pan></di'+_0x13a54f(0xc8))[_0x13a54f(0x2ca)]('');try{const _0xd711f1=await A(_0x13a54f(0x1ec),btype,$(_0x13a54f(0x458))[_0x13a54f(0x256)],target,off);if(!_0x56bc44)_0x38303e[_0x13a54f(0x35c)+'L']='';_0x38303e[_0x13a54f(0x2b6)+_0x13a54f(0x1eb)]('#more')?.['remove'](),_0x38303e[_0x13a54f(0x31d)+_0x13a54f(0x308)+'ML'](_0x13a54f(0x406)+'d',_0xd711f1[_0x13a54f(0x157)](_0xdfd423=>_0x13a54f(0x2c1)+_0x13a54f(0x36a)+'\x22>'+(_0xdfd423[_0x13a54f(0x16a)]?_0x13a54f(0x3e0)+_0x13a54f(0x1c1)+_0x13a54f(0x2fb)+esc(_0xdfd423[_0x13a54f(0x16a)])+(_0x13a54f(0x39e)+'>'):_0x13a54f(0x2c1)+_0x13a54f(0x116)+_0x13a54f(0x128))+(_0x13a54f(0x2c1)+_0x13a54f(0x317)+'b>')+esc(_0xdfd423[_0x13a54f(0xe6)])+(_0x13a54f(0xcf)+'n>')+esc(_0xdfd423[_0x13a54f(0x456)+'ion'])+(_0x13a54f(0x38b)+_0x13a54f(0x176)+'all\x20clas'+_0x13a54f(0x215)+'>')+esc(_0xdfd423[_0x13a54f(0x39b)])+_0x13a54f(0x466)+t(_0x13a54f(0x103),_0xdfd423[_0x13a54f(0x242)+'s'][_0x13a54f(0x264)+_0x13a54f(0x280)](lang))+('</small>'+_0x13a54f(0x168)+_0x13a54f(0x2d6)+'\x22')+esc(_0xdfd423[_0x13a54f(0x1e5)+'id'])+(_0x13a54f(0x1a3)+'k=\x22inst('+'this)\x22>')+t(_0x13a54f(0xc1))+('</button'+_0x13a54f(0x193)))[_0x13a54f(0x2ca)]('')||(_0x56bc44?'':_0x13a54f(0x2a6)+_0x13a54f(0x29c)+t(_0x13a54f(0x352))+_0x13a54f(0x473)));if(_0xd711f1[_0x13a54f(0x20b)]===0x1ce1+-0x1f23+0x256)_0x38303e[_0x13a54f(0x31d)+'jacentHT'+'ML'](_0x13a54f(0x406)+'d',_0x13a54f(0x168)+_0x13a54f(0x213)+_0x13a54f(0x1a3)+_0x13a54f(0x32e)+_0x13a54f(0x460)+t(_0x13a54f(0x2b1))+('</button'+'>'));stag();}catch(_0x595253){fail(_0x595253);}}async function inst(_0x3d63eb){const _0x5590d6=_0x19b0c2;_0x3d63eb[_0x5590d6(0x21c)]=!![],_0x3d63eb[_0x5590d6(0x45f)+_0x5590d6(0x222)]='…';try{const _0x55d31d=await A(_0x5590d6(0xc1),target,_0x3d63eb[_0x5590d6(0x16e)]['id'],btype);toast(_0x55d31d[_0x5590d6(0x2c9)]?t(_0x5590d6(0x357),_0x55d31d[_0x5590d6(0x2c9)]):t(_0x5590d6(0x445)+'d',_0x55d31d[_0x5590d6(0x25f)]),0x6f6+0x695*-0x2+0x7a*0x36),_0x3d63eb['textCont'+_0x5590d6(0x222)]=t('done'),_0x3d63eb[_0x5590d6(0x142)+'t'][_0x5590d6(0x246)](_0x5590d6(0xe9));if(_0x55d31d[_0x5590d6(0x2c9)])load();}catch(_0x2e88d8){fail(_0x2e88d8),_0x3d63eb['textCont'+_0x5590d6(0x222)]=t('install'),_0x3d63eb[_0x5590d6(0x21c)]=![];}}const row=(_0x186012,_0xce02ba,_0x410c54)=>_0x19b0c2(0x2c1)+'ss=\x22srow'+'\x22><div><'+'b>'+_0x186012+'</b>'+(_0xce02ba?'<small>'+_0xce02ba+'</small>':'')+('</div><d'+_0x19b0c2(0x1c8)+_0x19b0c2(0x1c7))+_0x410c54+('</div></'+_0x19b0c2(0x22e)),tgl=(_0x4fe8a1,_0x547937)=>_0x19b0c2(0x408)+_0x19b0c2(0x224)+_0x19b0c2(0x10c)+_0x19b0c2(0x426)+_0x19b0c2(0x3ef)+'\x20'+(_0x4fe8a1?_0x19b0c2(0x296):'')+(_0x19b0c2(0x2d2)+'e=\x22')+_0x547937+(_0x19b0c2(0x32f)+_0x19b0c2(0x255)+'>');function settings(){const _0x3d018d=_0x19b0c2,_0x2f665a=S[_0x3d018d(0x1f5)];$(_0x3d018d(0x2ff))[_0x3d018d(0x35c)+'L']=_0x3d018d(0x2c1)+'ss=\x22page'+_0x3d018d(0x374)+t('nav_sett'+_0x3d018d(0x11e))+('</h1><di'+_0x3d018d(0x35b)+_0x3d018d(0x225)+_0x3d018d(0x344))+t(_0x3d018d(0x30d))+_0x3d018d(0x324)+row(t(_0x3d018d(0x1e9)),'','<select\x20'+_0x3d018d(0x238)+_0x3d018d(0x1f2)+_0x3d018d(0x478)+_0x3d018d(0x31f)+LANGS[_0x3d018d(0x157)](([_0x173aaa,_0x36c324])=>_0x3d018d(0x2ba)+_0x3d018d(0x34c)+_0x173aaa+'\x22\x20'+(_0x173aaa===lang?_0x3d018d(0x438):'')+'>'+_0x36c324+(_0x3d018d(0x267)+'>'))[_0x3d018d(0x2ca)]('')+('</select'+'>'))+'\x0a\x20'+row(t(_0x3d018d(0x119)+'t'),'',_0x3d018d(0x2c1)+_0x3d018d(0xb8)+_0x3d018d(0xd4)+ACCENTS['map'](_0x3e49d4=>_0x3d018d(0x168)+_0x3d018d(0x351)+'watch\x20'+((_0x2f665a[_0x3d018d(0x3bb)]||ACCENTS[0x1d0a+-0x1*0x270d+0xe9*0xb])[_0x3d018d(0x2b4)+_0x3d018d(0x475)]()===_0x3e49d4?'on':'')+(_0x3d018d(0x25e)+'=\x22')+_0x3e49d4+(_0x3d018d(0x1a1)+_0x3d018d(0x398))+_0x3e49d4+(_0x3d018d(0x1a3)+_0x3d018d(0x113)+_0x3d018d(0x46b))+_0x3e49d4+(_0x3d018d(0x37b)+_0x3d018d(0x1c3)))['join']('')+(_0x3d018d(0x408)+'lass=\x22sw'+_0x3d018d(0x108)+'tom\x20')+(ACCENTS[_0x3d018d(0x27e)]((_0x2f665a['accent']||ACCENTS[-0x1e7*-0x2+0x434+-0x802])[_0x3d018d(0x2b4)+'ase']())?'':'on')+(_0x3d018d(0x1a1)+_0x3d018d(0x398))+(_0x2f665a[_0x3d018d(0x3bb)]||ACCENTS[0x1*-0x2381+0x1*0xd2b+0x1656])[_0x3d018d(0x2b4)+_0x3d018d(0x475)]()+(_0x3d018d(0x14d)+'\x22')+esc(t(_0x3d018d(0x2e8)+'m'))+(_0x3d018d(0x10c)+_0x3d018d(0x426)+_0x3d018d(0x471)+_0x3d018d(0x362))+(_0x2f665a[_0x3d018d(0x3bb)]||ACCENTS[-0x24a1*0x1+-0x1*-0xc1a+-0x3*-0x82d])[_0x3d018d(0x2b4)+_0x3d018d(0x475)]()+(_0x3d018d(0x20e)+_0x3d018d(0x263)+_0x3d018d(0x468)+_0x3d018d(0x3d5)+_0x3d018d(0x337)+_0x3d018d(0x232)+_0x3d018d(0x356)+_0x3d018d(0xf7)+'\x22setAcce'+_0x3d018d(0x253)+_0x3d018d(0x31f)+_0x3d018d(0x197)+_0x3d018d(0x170)+_0x3d018d(0x29a)+_0x3d018d(0x43b)+_0x3d018d(0x1e6)+_0x3d018d(0x110)+_0x3d018d(0x41b)+_0x3d018d(0x3b9)+_0x3d018d(0x46c)+_0x3d018d(0x1be)+_0x3d018d(0x453))+(_0x2f665a[_0x3d018d(0x3bb)]||ACCENTS[-0x652+0x117*0x15+-0x1091])[_0x3d018d(0x2b4)+_0x3d018d(0x475)]()+(_0x3d018d(0x208)+_0x3d018d(0x24b)+_0x3d018d(0x2ed)+_0x3d018d(0x31f)+_0x3d018d(0x128)))+_0x3d018d(0x344)+t('sec_game')+_0x3d018d(0x324)+row(t(_0x3d018d(0x33e)),'',_0x3d018d(0x46e)+'onchange'+'=\x22A(\x27cfg'+_0x3d018d(0x306)+_0x3d018d(0x260)+_0x3d018d(0x3a0)+_0x3d018d(0x33f)+_0x3d018d(0x285)+'this.val'+'ue\x22>'+[[_0x3d018d(0x229),'c_ask'],[_0x3d018d(0xc3),_0x3d018d(0x319)],[_0x3d018d(0x42e),_0x3d018d(0xbb)]][_0x3d018d(0x157)](([_0x49ce34,_0x29df32])=>_0x3d018d(0x2ba)+_0x3d018d(0x34c)+_0x49ce34+'\x22\x20'+((_0x2f665a[_0x3d018d(0x2cc)]||'ask')===_0x49ce34?_0x3d018d(0x438):'')+'>'+t(_0x29df32)+(_0x3d018d(0x267)+'>'))[_0x3d018d(0x2ca)]('')+('</select'+'>'))+'\x0a\x20'+row(t(_0x3d018d(0x18e)),'',_0x3d018d(0x170)+'ype=\x22tex'+_0x3d018d(0x24c)+'=\x22'+esc(_0x2f665a[_0x3d018d(0x180)]||'')+(_0x3d018d(0x208)+_0x3d018d(0x190)+'fgset\x27,{'+_0x3d018d(0x409)+_0x3d018d(0xec)+_0x3d018d(0x37c)+_0x3d018d(0x33f)+_0x3d018d(0x43d)+'his.valu'+'e.trim()'+_0x3d018d(0x2d0)+'(\x27saved\x27'+_0x3d018d(0x3cd)))+'\x0a\x20'+row(t(_0x3d018d(0x156)),'',tgl(_0x2f665a[_0x3d018d(0x2cf)]!==![],_0x3d018d(0x3f1)+_0x3d018d(0x25c)+'this.che'+_0x3d018d(0x292)+_0x3d018d(0x3f6)+'gpu=this'+_0x3d018d(0x340)))+'\x0a\x20'+row(t(_0x3d018d(0x250)+'ay'),'',tgl(_0x2f665a[_0x3d018d(0xb1)]!==![],_0x3d018d(0x3f1)+_0x3d018d(0x47b)+_0x3d018d(0x3c9)+'.checked'+_0x3d018d(0x234)+'fig.over'+_0x3d018d(0xb2)+_0x3d018d(0x340)))+'\x0a\x20'+row(t(_0x3d018d(0x12a)+'me'),'',tgl(_0x2f665a['overlayW'+_0x3d018d(0x321)]!==![],_0x3d018d(0x3f1)+_0x3d018d(0x47b)+_0x3d018d(0x33b)+_0x3d018d(0x18d)+_0x3d018d(0x403)+_0x3d018d(0x21b)+_0x3d018d(0x33a)+_0x3d018d(0xf6)+_0x3d018d(0x10b)+_0x3d018d(0x294)))+'\x0a\x20'+row(t(_0x3d018d(0xfe)+'e'),'','<select\x20'+_0x3d018d(0x238)+_0x3d018d(0x169)+_0x3d018d(0x191)+_0x3d018d(0xe8)+_0x3d018d(0x270)+_0x3d018d(0x377)+_0x3d018d(0x3f6)+'overlayM'+_0x3d018d(0x105)+_0x3d018d(0x34f)+_0x3d018d(0x2ba)+'value=\x22s'+'tandard\x22'+'\x20'+(_0x2f665a[_0x3d018d(0x23c)+_0x3d018d(0x328)]===_0x3d018d(0x112)?_0x3d018d(0x438):'')+'>'+t(_0x3d018d(0x3d7))+(_0x3d018d(0x267)+_0x3d018d(0x1d1)+'\x20value=\x22'+_0x3d018d(0x188)+'\x20')+(_0x2f665a['overlayM'+_0x3d018d(0x328)]!==_0x3d018d(0x112)?_0x3d018d(0x438):'')+'>'+t(_0x3d018d(0x16b))+('</option'+_0x3d018d(0x237)+'t>'))+_0x3d018d(0x344)+t(_0x3d018d(0x302))+_0x3d018d(0x324)+row(t(_0x3d018d(0x2a1)+'rd'),'',tgl(_0x2f665a['discord']!==![],_0x3d018d(0x3f1)+_0x3d018d(0x1a0)+_0x3d018d(0x44e)+_0x3d018d(0x340)+_0x3d018d(0x234)+_0x3d018d(0x40f)+_0x3d018d(0x327)+_0x3d018d(0x340)))+'\x0a\x20'+row(t('st_dcpro'+'f'),'',tgl(_0x2f665a[_0x3d018d(0x3fc)+_0x3d018d(0x2f1)]!==![],_0x3d018d(0x3f1)+_0x3d018d(0x1a0)+'ordProfi'+'le:this.'+_0x3d018d(0x403)+_0x3d018d(0x21b)+_0x3d018d(0x174)+_0x3d018d(0x21e)+_0x3d018d(0x10b)+'hecked'))+'\x0a\x20'+row(t('st_disco'+_0x3d018d(0xdf)),esc(t(_0x3d018d(0x2a1)+_0x3d018d(0xdb))),_0x3d018d(0x170)+'ype=\x22tex'+_0x3d018d(0x24c)+'=\x22'+esc(_0x2f665a[_0x3d018d(0x13d)+'d']||'')+('\x22\x20placeh'+_0x3d018d(0x3a2)+_0x3d018d(0x43e)+_0x3d018d(0x3a1)+_0x3d018d(0x182)+_0x3d018d(0x28c)+_0x3d018d(0x214)+_0x3d018d(0x135)+'Id:this.'+_0x3d018d(0x3de)+_0x3d018d(0x1fc)+_0x3d018d(0x3f6)+_0x3d018d(0x13d)+_0x3d018d(0x464)+'alue.tri'+'m();toas'+'t(t(\x27sav'+_0x3d018d(0x28e)))+_0x3d018d(0x344)+t(_0x3d018d(0x101))+'</h3>\x0a\x20'+row(t(_0x3d018d(0x101)),t(_0x3d018d(0x2a0)),_0x3d018d(0x168)+_0x3d018d(0x2bc)+_0x3d018d(0x1b2)+_0x3d018d(0x442)+t(_0x3d018d(0x101))+(_0x3d018d(0xf4)+'>'))+_0x3d018d(0x344)+t('sec_acc')+_0x3d018d(0x324)+row(esc(t(_0x3d018d(0x44d),S[_0x3d018d(0x415)][_0x3d018d(0x25f)])),'',_0x3d018d(0x168)+_0x3d018d(0x2bc)+'\x22signOut'+'()\x22>'+t(_0x3d018d(0x3ea))+('</button'+'>'))+'\x0a\x20'+row(t(_0x3d018d(0x43c)),'','<div\x20cla'+_0x3d018d(0x18c)+_0x3d018d(0x205)+_0x3d018d(0x360)+'\x22><butto'+'n\x20onclic'+_0x3d018d(0x43f)+'pen\x27)\x22>'+t(_0x3d018d(0x43c))+(_0x3d018d(0xf4)+_0x3d018d(0x162)+_0x3d018d(0x3a9)+'=\x22A(\x27plo'+_0x3d018d(0x3f9))+t('st_log')+(_0x3d018d(0xf4)+'><button'+_0x3d018d(0x3a9)+_0x3d018d(0x299)+_0x3d018d(0x2a9))+t('st_dbg')+(_0x3d018d(0xf4)+_0x3d018d(0x193)))+(_0x3d018d(0x21d)+'<p\x20class'+_0x3d018d(0x1cf)+_0x3d018d(0x2b8))+t(_0x3d018d(0x1af))+(_0x3d018d(0x35d)+'v>');}function applyAccent(_0x115353){const _0x2d68b5=_0x19b0c2;_0x115353=HEX[_0x2d68b5(0x29d)](_0x115353||'')?_0x115353[_0x2d68b5(0x2b4)+_0x2d68b5(0x475)]():ACCENTS[-0x6*0x448+-0x34*-0xac+-0x25*0x40];const _0x1d7931=document['document'+_0x2d68b5(0x1e3)][_0x2d68b5(0xb4)],_0x23ecb5=parseInt(_0x115353[_0x2d68b5(0x347)](-0x11e8*0x2+0x1feb*-0x1+0x43bc),0x2477+-0x4*0x6f1+-0x43*0x21),_0x5182d6=(-0x94d*0x1+-0x11c0+0x1b0d+0.299)*(_0x23ecb5>>0x145b+-0x12df+-0x16c)+(0x21*-0x83+0x1*0x1f33+-0xe50+0.587)*(_0x23ecb5>>0x26cb+0x12c0+0x1*-0x3983&-0x2607+-0x6c2+0x2dc8)+(0x3*-0x835+0x1*0x11db+0x2*0x362+0.114)*(_0x23ecb5&-0x47*-0xc+0x10*-0x103+-0xddb*-0x1);_0x1d7931[_0x2d68b5(0x283)+_0x2d68b5(0x3b6)](_0x2d68b5(0x278),_0x115353),_0x1d7931[_0x2d68b5(0x283)+_0x2d68b5(0x3b6)](_0x2d68b5(0x375),_0x5182d6>0xca2+0xa1*0x11+0x16bd*-0x1?_0x2d68b5(0x167):'#ffffff');}function syncSw(_0x4f7680){const _0x3a35b7=_0x19b0c2;_0x4f7680=_0x4f7680[_0x3a35b7(0x2b4)+_0x3a35b7(0x475)](),document[_0x3a35b7(0x2b6)+'ectorAll'](_0x3a35b7(0x318)+_0x3a35b7(0x447)+_0x3a35b7(0x331))['forEach'](_0x4e2ca7=>_0x4e2ca7[_0x3a35b7(0x142)+'t']['toggle']('on',_0x4e2ca7['dataset']['c']===_0x4f7680));const _0x398c17=document[_0x3a35b7(0x2b6)+_0x3a35b7(0x1eb)](_0x3a35b7(0x431)+_0x3a35b7(0x13e));_0x398c17&&(_0x398c17[_0x3a35b7(0x142)+'t'][_0x3a35b7(0x17f)]('on',!ACCENTS[_0x3a35b7(0x27e)](_0x4f7680)),_0x398c17[_0x3a35b7(0xb4)][_0x3a35b7(0x283)+_0x3a35b7(0x3b6)]('--c',_0x4f7680));const _0x437556=$(_0x3a35b7(0x2e5));if(_0x437556)_0x437556[_0x3a35b7(0x256)]=_0x4f7680;}function setAccent(_0x18065d){const _0x3cd8d3=_0x19b0c2;_0x18065d=_0x18065d[_0x3cd8d3(0x2b4)+_0x3cd8d3(0x475)](),A(_0x3cd8d3(0x41f),{'accent':_0x18065d}),S['config'][_0x3cd8d3(0x3bb)]=_0x18065d,applyAccent(_0x18065d),syncSw(_0x18065d);}function hexAcc(_0x4afefe){const _0x58dcf8=_0x19b0c2;_0x4afefe=_0x4afefe[_0x58dcf8(0x3e1)]();if(_0x4afefe[0x19d8+0x2ab+0x9*-0x32b]!=='#')_0x4afefe='#'+_0x4afefe;if(_0x4afefe[_0x58dcf8(0x20b)]===0x1*0x493+-0x130d+0xe7e)_0x4afefe='#'+[..._0x4afefe[_0x58dcf8(0x347)](0x1*0x23e3+0x2394+-0x4776)]['map'](_0x47b5cc=>_0x47b5cc+_0x47b5cc)[_0x58dcf8(0x2ca)]('');if(HEX[_0x58dcf8(0x29d)](_0x4afefe)){setAccent(_0x4afefe);const _0x10efd5=document['querySel'+_0x58dcf8(0x1eb)](_0x58dcf8(0x431)+_0x58dcf8(0x115)+'nput');if(_0x10efd5)_0x10efd5['value']=_0x4afefe[_0x58dcf8(0x2b4)+'ase']();}else{const _0x3ddefd=$(_0x58dcf8(0x2e5));if(_0x3ddefd)_0x3ddefd[_0x58dcf8(0x256)]=(S[_0x58dcf8(0x1f5)][_0x58dcf8(0x3bb)]||ACCENTS[0x1*-0xb41+0x1b81+-0x1040])[_0x58dcf8(0x2b4)+_0x58dcf8(0x475)]();}}async function signOut(){const _0xd0e373=_0x19b0c2;await A(_0xd0e373(0x2c2)),S[_0xd0e373(0x415)]=null,onboard(-0x208a+0x1*0x2519+-0x185*0x3);}function countUp(){const _0x7d1e8c=_0x19b0c2;document[_0x7d1e8c(0x2b6)+_0x7d1e8c(0x42b)]('[data-co'+'unt]')[_0x7d1e8c(0x2ee)](_0x40ef7c=>{const _0x994d0b=_0x7d1e8c,_0x29d16d=+_0x40ef7c['dataset'][_0x994d0b(0x3e7)],_0x5cac49=performance['now']();(function _0x2c1147(_0x4bdab0){const _0xf56ecf=_0x994d0b,_0x38e826=Math['min'](-0x22*0xe0+0xcf*-0x8+0x119*0x21,(_0x4bdab0-_0x5cac49)/(-0x1407*0x1+0xe0e+0x1*0x851));_0x40ef7c[_0xf56ecf(0x45f)+'ent']=Math[_0xf56ecf(0x307)](_0x29d16d*(0x1a3a*-0x1+0x1*0x240b+-0x1*0x9d0-Math[_0xf56ecf(0x161)](-0x22ba+0x20f4+0x1c7-_0x38e826,-0xe3*-0x7+0x29*-0x6c+-0x3a*-0x31)));if(_0x38e826<0x17f6+0x73f+-0x7cd*0x4)requestAnimationFrame(_0x2c1147);}(_0x5cac49));});}function stag(){const _0x3537eb=_0x19b0c2;document[_0x3537eb(0x2b6)+_0x3537eb(0x42b)](_0x3537eb(0x159)+_0x3537eb(0x3d4))[_0x3537eb(0x2ee)](_0xef1637=>{const _0x4cd752=_0x3537eb;let _0x1d352e=-0x12e7+0x1d5*-0x14+0x378b;[..._0xef1637[_0x4cd752(0x402)]][_0x4cd752(0x2ee)](_0x25f749=>{const _0x33a778=_0x4cd752;if(_0x25f749[_0x33a778(0x16e)]['s'])return;_0x25f749['dataset']['s']=0x1d*0x1+-0x19*-0x21+-0x355,_0x25f749[_0x33a778(0xb4)][_0x33a778(0x283)+_0x33a778(0x3b6)]('--i',Math[_0x33a778(0x130)](_0x1d352e++,0x21*-0xe9+-0x1*0x5b+0x1e72));});});}function hideSplash(){const _0x1d28d6=_0x19b0c2,_0x2601ec=$(_0x1d28d6(0x1a8));if(!_0x2601ec||_0x2601ec[_0x1d28d6(0x16e)]['h'])return;_0x2601ec[_0x1d28d6(0x16e)]['h']=-0x1118+0x264f+-0x43e*0x5;const _0x6f067b=Math[_0x1d28d6(0x365)](-0x19*0x108+-0x9*-0xad+-0x3*-0x691,0x1*-0x24ac+-0x95+0x13*0x26f-performance[_0x1d28d6(0x2fe)]());setTimeout(()=>{const _0xc9805a=_0x1d28d6;_0x2601ec['classLis'+'t'][_0xc9805a(0x246)]('leave'),setTimeout(()=>_0x2601ec[_0xc9805a(0x142)+'t'][_0xc9805a(0x246)](_0xc9805a(0x155)),0x120a+-0x2309+-0x11*-0x12f),setTimeout(()=>_0x2601ec['remove'](),-0x1ead*-0x1+0x3b*0x8f+-0x39c6);},_0x6f067b);}setTimeout(hideSplash,-0x1439+-0x1be6*-0x1+-0x197*-0x5),addEventListener(_0x19b0c2(0x34a),_0x10cdd6=>{const _0x1352bb=_0x19b0c2;_0x10cdd6[_0x1352bb(0x414)+_0x1352bb(0x1a4)]();if(view==='lib'&&cur)$('#drop')[_0x1352bb(0x142)+'t'][_0x1352bb(0x246)]('on');}),addEventListener(_0x19b0c2(0x300)+'e',_0x18d930=>{const _0x2965b2=_0x19b0c2;if(!_0x18d930[_0x2965b2(0x227)+_0x2965b2(0xfb)])$(_0x2965b2(0x129))[_0x2965b2(0x142)+'t'][_0x2965b2(0x459)]('on');}),addEventListener(_0x19b0c2(0x15a),async _0x5886a5=>{const _0x58133b=_0x19b0c2;_0x5886a5[_0x58133b(0x414)+_0x58133b(0x1a4)](),$(_0x58133b(0x129))['classLis'+'t'][_0x58133b(0x459)]('on');if(view!==_0x58133b(0x218)||!cur)return;const _0x312fa8=await A(_0x58133b(0x144),cur,tab,[..._0x5886a5[_0x58133b(0xef)+_0x58133b(0x411)][_0x58133b(0x163)]][_0x58133b(0x157)](_0x27ca41=>window[_0x58133b(0x21a)][_0x58133b(0x23e)](_0x27ca41)));toast(t(_0x58133b(0x2fa),_0x312fa8)),refreshFiles();});async function showCredits(){const _0x47837a=_0x19b0c2;modal(_0x47837a(0x24f)+t(_0x47837a(0x101))+(_0x47837a(0x323)+_0x47837a(0x376)+_0x47837a(0x2e7))+t(_0x47837a(0x154))+(_0x47837a(0x26a)+_0x47837a(0x1fa)+_0x47837a(0x2c4)+'\x22crl\x20mut'+'\x22>')+t(_0x47837a(0x2f6)+'g')+(_0x47837a(0x3ba)+_0x47837a(0x1c8)+_0x47837a(0x2bb)+_0x47837a(0xd2)+_0x47837a(0x1b7)+'lid\x22\x20onc'+_0x47837a(0x279)+_0x47837a(0x13b))+t('ok')+(_0x47837a(0xf4)+'></div>'));try{const _0x30c6a7=await A('credits'),_0xd8982f=_0x536759=>_0x47837a(0x2c1)+_0x47837a(0x446)+_0x47837a(0x27a)+'ata-u=\x22'+esc(_0x536759[_0x47837a(0x3e5)])+(_0x47837a(0x1a3)+_0x47837a(0x394)+_0x47837a(0x2e4)+_0x47837a(0x297)+'set.u)\x22>'+'<span\x20cl'+_0x47837a(0x12b)+'<b>')+esc(_0x536759[_0x47837a(0xe6)]||_0x536759[_0x47837a(0x25f)])+_0x47837a(0xff)+(_0x536759[_0x47837a(0x39b)]?_0x47837a(0x343)+t('cr_by')+'\x20'+esc(_0x536759['author']):'')+(_0x47837a(0x201)+'ll>')+(_0x536759[_0x47837a(0x404)]?t(_0x47837a(0x3b5))+':\x20'+esc(_0x536759[_0x47837a(0x404)]):esc(_0x536759['url']))+(_0x47837a(0x298)+_0x47837a(0x38b)+_0x47837a(0x3c0)),_0x566175=$(_0x47837a(0x18f));_0x566175[_0x47837a(0x142)+'t'][_0x47837a(0x459)](_0x47837a(0x3c3)),_0x566175[_0x47837a(0x35c)+'L']=_0x47837a(0x384)+t(_0x47837a(0x22c))+_0x47837a(0x451)+_0x30c6a7[_0x47837a(0x11c)][_0x47837a(0x157)](_0xd8982f)['join']('')+(_0x47837a(0x384)+t(_0x47837a(0x189))+_0x47837a(0x451))+_0x30c6a7[_0x47837a(0x19a)]['map'](_0xd8982f)[_0x47837a(0x2ca)]('');}catch(_0x2f3182){fail(_0x2f3182);}}boot();
// --- NRML 1.9: animations + idle mode (pause infinite animations when unseen) ---
(function(){
  const b=document.body;
  const upd=()=>{try{b.classList.toggle('idle',document.hidden||!document.hasFocus()||!!running);}catch{}};
  window.addEventListener('blur',upd);window.addEventListener('focus',upd);document.addEventListener('visibilitychange',upd);
  try{const sp=syncPlay;syncPlay=function(){const r=sp.apply(this,arguments);upd();return r;};}catch{}
  upd();
  // ripple on every button
  document.addEventListener('pointerdown',e=>{
    const el=e.target.closest&&e.target.closest('button');
    if(!el||el.disabled||matchMedia('(prefers-reduced-motion:reduce)').matches)return;
    const r=el.getBoundingClientRect(),d=Math.max(r.width,r.height)*2,s=document.createElement('span');
    s.className='rip';s.style.cssText='width:'+d+'px;height:'+d+'px;left:'+(e.clientX-r.left-d/2)+'px;top:'+(e.clientY-r.top-d/2)+'px';
    el.appendChild(s);setTimeout(()=>s.remove(),650);
  },true);
  // version label
  const v=document.getElementById('sver');
  if(v){const fix=()=>{if(!/^NRML Client 2\./.test(v.textContent))v.textContent=v.textContent.replace(/^NRML [\d.]+/,'NRML Client 2.8.0 (STABLE)');};fix();new MutationObserver(fix).observe(v,{childList:true,characterData:true,subtree:true});}
})();

// ===== NRML Client 2.0.1: readable file list, detail drawer, version + memory dialogs =====
const NXT={};
function nxTween(key,from,to,ms,fn){
  cancelAnimationFrame(NXT[key]);
  const t0=performance.now();
  (function step(n){const k=Math.min(1,(n-t0)/ms),e=1-Math.pow(1-k,3);fn(from+(to-from)*e);if(k<1)NXT[key]=requestAnimationFrame(step);})(t0);
}
const NX={data:{},req:0,dreq:0,loading:{}};
const nxKey=()=>cur+'/'+tab;
const nxBase=f=>String(f).replace(/\.disabled$/i,'');
const nxGB=mb=>(mb/1024).toFixed(1)+' GB';
const nxSize=b=>b>=1048576?(b/1048576).toFixed(1)+' MB':Math.max(1,Math.round(b/1024))+' KB';
const nxSvg=p=>'<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'+p+'</svg>';
const NXI={edit:nxSvg('<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/>'),folder:nxSvg('<path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>'),
  link:nxSvg('<path d="M14 3h7v7"/><path d="M10 14L21 3"/><path d="M21 14v5a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h5"/>'),x:nxSvg('<path d="M18 6L6 18M6 6l12 12"/>')};
function nxIcon(o,cls){
  const src=(o.mr&&o.mr.icon_url)||o.icon;
  if(src)return '<img class="'+cls+'" src="'+esc(src)+'" alt="" decoding="async">';
  const c=(String(o.title||'?').trim()[0]||'?').toUpperCase();
  return '<div class="'+cls+' ph"><span>'+esc(c)+'</span></div>';
}
function nxIndex(list){const by={};for(const x of list||[])by[x.file]=x;return by;}
async function nxLoad(force){
  const k=nxKey();
  if(NX.loading[k])return;
  NX.loading[k]=1;
  try{
    const list=await A('finfo',cur,tab),old=NX.data[k];
    NX.data[k]={list,byFile:nxIndex(list),mr:(old&&old.mr)||{}};
    if(nxKey()===k)nxPaint(true);
    A('fmeta',cur,tab).then(m=>{if(NX.data[k]){NX.data[k].mr=m||{};if(nxKey()===k)nxPaint(true);}}).catch(()=>{});
  }catch(e){}finally{delete NX.loading[k];}
}
function nxRow(f,i,d){
  const on=!/\.disabled$/i.test(f),li=(d&&d.byFile[f])||{},mr=(d&&d.mr[nxBase(f)])||null;
  const title=(mr&&mr.title)||li.title||nxBase(f).replace(/\.(jar|zip)$/i,'');
  const ver=(mr&&mr.version_number)||li.version||'';
  return '<div class="frow nx'+(on?'':' off')+'" data-s="1" style="--i:'+Math.min(i,18)+'" data-f="'+esc(f)+'" tabindex="0" role="button" onclick="nxOpen(this)" onkeydown="if(event.key===\'Enter\')nxOpen(this)">'
    +nxIcon({title,icon:li.icon,mr},'ic2')
    +'<span class="n"><b>'+esc(title)+'</b><small>'+esc((ver?ver+'  ·  ':'')+nxBase(f))+'</small></span>'
    +'<label class="sw" onclick="event.stopPropagation()"><input type="checkbox" '+(on?'checked':'')+' data-n="'+esc(f)+'" onchange="tog(this.dataset.n)"><i></i></label>'
    +'<button class="txt" data-n="'+esc(f)+'" onclick="event.stopPropagation();del(this.dataset.n)">'+esc(t('remove'))+'</button></div>';
}
function nxPaint(quiet){
  const box=$('#flist');if(!box)return;
  const d=NX.data[nxKey()],files=FILES[tab]||[];
  box.classList.toggle('nofx',!!quiet);
  box.innerHTML=files.length?files.map((f,i)=>nxRow(f,i,d)).join(''):'<p class="mut pad">'+esc(t('nothing'))+'</p>';
  document.querySelectorAll('.tabs button[data-k] .cnt').forEach(e=>{const b=e.closest('button');if(b&&FILES[b.dataset.k])e.textContent=FILES[b.dataset.k].length;});
}
drawFiles=function(){
  const k=nxKey(),d=NX.data[k],files=FILES[tab]||[];
  nxPaint(!!d);
  if(!d||files.some(f=>!d.byFile[f]))nxLoad();
};
function nxOpen(el){nxDetail(el.dataset.f);}
/* ---- drawer ---- */
function nxDrawer(html,file){
  if(!document.getElementById('dr')){
    document.body.insertAdjacentHTML('beforeend','<div id="dr-bg" onclick="nxClose()"></div><aside id="dr" role="dialog" aria-modal="true"></aside>');
  }
  const d=document.getElementById('dr');d.dataset.f=file||'';d.innerHTML=html;
  requestAnimationFrame(()=>requestAnimationFrame(()=>document.body.classList.add('dr-on')));
}
function nxClose(){document.body.classList.remove('dr-on');NX.dreq++;}
addEventListener('keydown',e=>{if(e.key==='Escape'&&document.body.classList.contains('dr-on')){nxClose();e.stopImmediatePropagation();}},true);
function nxHead(title,sub,o){
  return '<div class="dr-h">'+nxIcon(o,'dr-ic')+'<div class="dr-t"><h2>'+esc(title)+'</h2><small>'+esc(sub||'')+'</small></div><button class="txt dr-x" onclick="nxClose()" aria-label="'+esc(t('f_close'))+'">'+NXI.x+'</button></div>';
}
function nxField(k,v){return '<div class="dr-f"><small>'+esc(k)+'</small><div>'+v+'</div></div>';}
async function nxDetail(file){
  const k=nxKey(),d=NX.data[k],li=(d&&d.byFile[file])||{title:nxBase(file)},mr0=(d&&d.mr[nxBase(file)])||null;
  const tk=++NX.dreq,ttl=(mr0&&mr0.title)||li.title;
  nxDrawer(nxHead(ttl,(mr0&&mr0.version_number)||li.version,{title:ttl,icon:li.icon,mr:mr0})+'<div class="dr-b"><div class="sk"></div><div class="sk s2"></div><div class="sk s3"></div></div>',file);
  let x=null;
  try{x=await A('fdetail',cur,tab,file);}catch(e){}
  if(tk!==NX.dreq)return;
  const L=(x&&x.local)||li,mr=x&&x.mr,team=(x&&x.team)||[];
  const title=(mr&&mr.title)||L.title||ttl,ver=(mr&&mr.version_number)||L.version||'';
  const on=x?x.on:!/\.disabled$/i.test(file);
  const desc=(mr&&mr.description)||L.description||t('f_nodesc');
  const by=team.length?team.map(m=>'<span class="chip"><b>'+esc(m.name)+'</b>'+(m.role?' <em>'+esc(m.role)+'</em>':'')+'</span>').join(''):((L.authors||[]).map(a=>'<span class="chip"><b>'+esc(a)+'</b></span>').join(''));
  const lic=(mr&&mr.license)||L.license;
  let h=nxHead(title,ver,{title,icon:(x&&x.local&&x.local.icon)||L.icon,mr})+'<div class="dr-b">'
    +'<div class="dr-pill '+(on?'on':'off')+'">'+esc(on?t('f_on'):t('f_off'))+'</div>'
    +nxField(t('f_desc'),esc(desc))
    +(by?nxField(t('f_by'),by):'')
    +(lic?nxField(t('f_lic'),esc(lic)):'')
    +(mr&&mr.downloads?nxField(t('f_dl',''),'<span data-dl="'+mr.downloads+'">0</span>'):'')
    +nxField(t('f_file'),'<code>'+esc(nxBase(file))+'</code>')
    +(x?nxField(t('f_size'),esc(nxSize(x.size)))+nxField(t('f_loc'),'<code class="sel">'+esc(x.path)+'</code>'):'')
    +'<p class="dr-src">'+esc(mr?t('f_src_mr'):t('f_src_local'))+'</p></div>'
    +'<div class="dr-a"><button class="txt" onclick="nxReveal()">'+NXI.folder+' '+esc(t('f_open'))+'</button>'
    +(x&&x.url?'<button class="txt" data-u="'+esc(x.url)+'" onclick="A(\'openurl\',this.dataset.u)">'+NXI.link+' '+esc(t('f_mr'))+'</button>':'')
    +'<span style="flex:1"></span>'
    +'<button class="txt" onclick="nxToggle()">'+esc(on?t('f_disable'):t('f_enable'))+'</button>'
    +'<button class="txt danger" onclick="nxRemove()">'+esc(t('remove'))+'</button></div>';
  nxDrawer(h,file);
  document.querySelectorAll('#dr [data-dl]').forEach(e=>nxTween('dl',0,+e.dataset.dl,800,v=>{e.textContent=Math.round(v).toLocaleString();}));
}
const nxFile=()=>{const d=document.getElementById('dr');return d&&d.dataset.f;};
function nxReveal(){const f=nxFile();if(f)A('freveal',cur,tab,f).catch(fail);}
async function nxToggle(){
  const f=nxFile();if(!f)return;
  try{await A('ftoggle',cur,tab,f);const nf=/\.disabled$/i.test(f)?nxBase(f):f+'.disabled';await refreshFiles();nxDetail(nf);}catch(e){fail(e);}
}
async function nxRemove(){
  const f=nxFile();if(!f)return;
  if(!confirm(t('f_rm_q',nxBase(f))))return;
  try{await A('fdel',cur,tab,f);nxClose();await refreshFiles();}catch(e){fail(e);}
}
/* ---- version dialog ---- */
function nxCmp(a,b){
  const pa=String(a).split(/[.\-]/).map(x=>parseInt(x,10)||0),pb=String(b).split(/[.\-]/).map(x=>parseInt(x,10)||0);
  for(let i=0;i<Math.max(pa.length,pb.length);i++){const d=(pa[i]||0)-(pb[i]||0);if(d)return d;}
  return 0;
}
async function verDlg(){
  const p=S.profiles.find(x=>x.id===cur);if(!p)return;
  if(!V.length){try{V=await A('versions');}catch(e){return fail(e);}}
  const list=V.includes(p.mc)?V:[p.mc,...V];
  modal('<h2>'+esc(t('ver_t'))+'</h2><p class="mut">'+esc(t('ver_cur'))+': <b>'+esc(p.mc)+'</b></p>'
    +'<label>'+esc(t('ver_new'))+'<select id="nv" onchange="verChk()">'+list.map(v=>'<option'+(v===p.mc?' selected':'')+'>'+esc(v)+'</option>').join('')+'</select></label>'
    +'<div class="warn" id="vw"></div>'
    +'<label class="c"><input type="checkbox" id="vb" checked> '+esc(t('ver_bk'))+'</label>'
    +'<label class="c"><input type="checkbox" id="vok" onchange="verChk()"> '+esc(t('ver_ok'))+'</label>'
    +'<div class="bar"><button class="solid" id="vgo" onclick="verApply()" disabled>'+esc(t('ver_apply'))+'</button><button class="txt" onclick="closeM()">'+esc(t('cancel'))+'</button></div>');
  verChk();
}
function verChk(){
  const p=S.profiles.find(x=>x.id===cur),nv=$('#nv').value,same=nv===p.mc,down=!same&&nxCmp(nv,p.mc)<0,w=$('#vw');
  const cls='warn'+(same?' hide':'')+(down?' hard':''),html=same?'':'<b>'+esc(t('ver_wt'))+'</b><ul>'+(down?'<li class="hl">'+esc(t('ver_down'))+'</li>':'')
    +'<li>'+esc(t('ver_w1'))+'</li><li>'+esc(t('ver_w2',p.mc,nv))+'</li><li>'+esc(t('ver_w3'))+'</li></ul>';
  if(w.dataset.k!==cls+html){w.dataset.k=cls+html;w.className=cls;w.innerHTML=html;}
  $('#vgo').disabled=same||!$('#vok').checked;
}
async function verApply(){
  const p=S.profiles.find(x=>x.id===cur),nv=$('#nv').value,bk=$('#vb').checked;
  if(!p||nv===p.mc)return;
  const m=$('#modal');m.dataset.lock=1;$('#vgo').disabled=true;
  try{
    let name=null;
    if(bk)name=await A('pbackup',cur);
    await A('psave',{id:cur,mc:nv});
    delete m.dataset.lock;closeM(true);await load();
    toast(t('ver_done',nv)+(name?'  ·  '+t('ver_bkdone',name):''));
  }catch(e){delete m.dataset.lock;$('#vgo').disabled=false;fail(e);}
}
/* ---- memory dialog ---- */
const NXR={max:16384,total:16384,rec:8192};
async function ramDlg(){
  const p=S.profiles.find(x=>x.id===cur);if(!p)return;
  try{const s=await A('sysinfo');NXR.total=s.totalMB;NXR.rec=s.recommendedMB;}catch{}
  NXR.max=Math.min(32768,Math.max(2048,NXR.total));
  const v=Math.min(p.ram,NXR.max);
  modal('<h2>'+esc(t('ram_t'))+'</h2><p class="mut">'+esc(t('ram_total',NXR.total,nxGB(NXR.total)))+'</p>'
    +'<div class="rv"><b id="rvm">'+v+' MB</b><span class="sub" id="rvg">('+nxGB(v)+')</span></div>'
    +'<input type="range" id="rr" min="1024" max="'+NXR.max+'" step="256" value="'+v+'" oninput="cancelAnimationFrame(NXT.ram);ramSync(this.value)">'
    +'<label>MB<input type="text" inputmode="numeric" id="rn" value="'+v+'" oninput="cancelAnimationFrame(NXT.ram);ramType(this.value)"></label>'
    +'<div class="warn hide" id="rw"></div>'
    +'<div class="bar"><button class="solid" onclick="ramSave()">'+esc(t('save'))+'</button><button class="txt" onclick="ramGo('+NXR.rec+')">'+esc(t('ram_use'))+' ('+NXR.rec+' MB)</button><button class="txt" onclick="closeM()">'+esc(t('cancel'))+'</button></div>');
  ramSync(512);
  nxTween('ram',512,v,700,x=>ramSync(Math.round(x/16)*16>v?v:Math.round(x/16)*16));
  setTimeout(()=>{if($('#rr'))ramSync(v);},760);
}
function ramGo(v){const cur=parseInt($('#rn').value,10)||512;nxTween('ram',cur,v,450,x=>ramSync(Math.round(x)));}
function ramSync(v){
  v=Math.max(512,Math.min(NXR.max,Math.round(+v||0)));
  $('#rr').value=v;$('#rr').style.setProperty('--p',((v-1024)/(NXR.max-1024)*100).toFixed(1)+'%');$('#rn').value=v;$('#rvm').textContent=v+' MB';$('#rvg').textContent='('+nxGB(v)+')';
  const w=$('#rw'),hi=v>NXR.total*0.75,lo=v<2048;
  const k=hi?1:lo?2:0;if(w.dataset.k!==String(k)){w.dataset.k=k;w.className='warn'+(k?'':' hide');w.textContent=hi?t('ram_hi'):lo?t('ram_lo'):'';}
}
function ramType(v){const n=parseInt(String(v).replace(/\D/g,''),10);if(n>=512){$('#rr').value=Math.min(n,NXR.max);$('#rvm').textContent=n+' MB';$('#rvg').textContent='('+nxGB(n)+')';}}
async function ramSave(){
  const v=Math.max(512,Math.min(NXR.max,parseInt($('#rn').value,10)||0));
  try{await A('psave',{id:cur,ram:v});closeM(true);await load();toast(t('ram_saved',v));}catch(e){fail(e);}
}
/* ---- profile pane (clickable version + memory) ---- */
drawPane=async function(){
  const p=S.profiles.find(x=>x.id===cur),pane=$('#pane');
  if(!p||!pane)return;
  const seq=++paneSeq;
  FILES=await A('flist',cur);
  if(seq!==paneSeq)return;
  const nMods=FILES.mods.filter(f=>!f.endsWith('.disabled')).length;
  pane.classList.remove('in');void pane.offsetWidth;pane.classList.add('in');
  pane.innerHTML='<div class="phead"><div><small class="kick">'+t('last')+': '+(p.last?esc(ago(p.last)):'—')+'</small><h1>'+esc(p.name)+'</h1></div>'
    +'<div class="acts"><button onclick="optim()">'+I.bolt+' '+t('optimize')+'</button>'+playBtn()+'</div></div>'
    +'<div class="facts">'
    +'<div class="click" tabindex="0" role="button" title="'+esc(t('edit'))+'" onclick="verDlg()" onkeydown="if(event.key===\'Enter\')verDlg()"><small>'+t('m_ver')+'</small><b>'+esc(p.mc)+'</b><span class="ed">'+NXI.edit+'</span></div>'
    +'<div><small>'+t('m_loader')+'</small><b>'+esc(p.loader)+'</b></div>'
    +'<div class="click" tabindex="0" role="button" title="'+esc(t('edit'))+'" onclick="ramDlg()" onkeydown="if(event.key===\'Enter\')ramDlg()"><small>'+t('m_ram')+'</small><b><span data-count="'+p.ram+'">0</span> MB <span class="sub">('+nxGB(p.ram)+')</span></b><span class="ed">'+NXI.edit+'</span></div>'
    +'<div><small>'+t('m_mods')+'</small><b data-count="'+nMods+'">0</b></div></div>'
    +'<div class="tabs"><div class="tbs">'+TABS.map(([k,l])=>'<button class="'+(tab===k?'on':'')+'" data-k="'+k+'" onclick="setTab(\''+k+'\')">'+t(l)+' <em class="cnt">'+FILES[k].length+'</em></button>').join('')+'</div><u class="tabline"></u></div>'
    +'<div class="bar" id="tbar"></div><div id="flist"></div>';
  drawBar();drawFiles();moveTab(false);stag();countUp();
};
/* ---- mod update banner (top centre) ---- */
const NXU={seen:{}};
async function nxUpdCheck(){
  const id=cur,p=S.profiles.find(x=>x.id===id);
  if(!p||p.loader!=='fabric'||running)return;
  let r;try{r=await A('mods:check',id);}catch{return;}
  if(id!==cur||!r||!r.names||!r.names.length)return nxBanHide();
  const key=id+'|'+r.names.join(',');
  if(NXU.seen[key])return;
  const shown=r.names.slice(0,3).join(', ')+(r.names.length>3?' '+t('nu_more',r.names.length-3):'');
  let b=document.getElementById('nxban');
  if(!b){document.body.insertAdjacentHTML('beforeend','<div id="nxban" role="status"></div>');b=document.getElementById('nxban');}
  b.dataset.k=key;
  b.innerHTML='<div class="nb-t"><b>'+esc(t('nu_a',shown))+'</b><span>'+esc(t('nu_b'))+'</span></div>'
    +'<button class="solid" onclick="nxBanUpd()">'+esc(t('nu_btn'))+'</button><button class="txt nb-x" onclick="nxBanHide(true)" aria-label="'+esc(t('f_close'))+'">'+NXI.x+'</button>';
  requestAnimationFrame(()=>requestAnimationFrame(()=>b.classList.add('on')));
  clearTimeout(NXU.t);NXU.t=setTimeout(()=>nxBanHide(false),30000);
}
function nxBanHide(dismiss){
  const b=document.getElementById('nxban');if(!b)return;
  if(dismiss&&b.dataset.k)NXU.seen[b.dataset.k]=1;
  b.classList.remove('on');
}
async function nxBanUpd(){const b=document.getElementById('nxban');if(b&&b.dataset.k)NXU.seen[b.dataset.k]=1;nxBanHide();await updMods();}
{const _dp=drawPane;drawPane=async function(){await _dp.apply(this,arguments);setTimeout(nxUpdCheck,600);};}

// ===== NRML Client 2.1.0: main menu theme designer =====
const TH={d:null,src:null,srcImg:null,custom:false};
const TH_PRESETS={sunset:['#1b1030','#ff7a2f','#ffd08a'],dawn:['#1a1030','#ff6fa0','#ffd0e0'],night:['#02030a','#6aa8ff','#c8dcff'],
  mist:['#8aa0aa','#59d6a0','#eef3ef'],ocean:['#0a2a52','#2fb8ff','#bfeaff'],nether:['#1a0404','#ff4a1a','#ffb060'],pink:['#2a0f2e','#ff4fa3','#ffc2e2']};
const TH_SC={
  sunset:{sky:['#1b1030','#6b2a5e','#ff7a3d','#ffd08a'],sun:[.7,.5],sunc:'#fff0c0',fog:'#ff9a5a',land:['#1a0c14','#3a1a1f'],water:1},
  dawn:{sky:['#1a1030','#5a3a7a','#ff6fa0','#ffd9c0'],sun:[.3,.52],sunc:'#fff4e0',fog:'#ffb0c0',land:['#1c1024','#40243a'],water:1},
  night:{sky:['#02030a','#091030','#1b2d5c'],sun:[.62,.28],sunc:'#e8f0ff',fog:'#27407a',land:['#04060e','#0e1428'],stars:1,water:1},
  mist:{sky:['#8aa0aa','#c4d4d8','#eef3ef'],sun:[.5,.4],sunc:'#ffffff',fog:'#dfe9e8',land:['#2c4a40','#5d8576'],mist:1},
  ocean:{sky:['#0a2a52','#1e6aa8','#8fd3f0'],sun:[.28,.4],sunc:'#ffffff',fog:'#9fdcf2',land:['#0a3a4a','#1d6a78'],water:1},
  pink:{sky:['#2a0f2e','#8a2a7a','#ff6fb5','#ffd0e8'],sun:[.5,.48],sunc:'#fff0f8',fog:'#ff9fcf',land:['#1f0f26','#4a2050'],water:1},
  nether:{sky:['#1a0404','#4a0b08','#a3200a'],fog:'#d4401a',land:['#1c0505','#4a1208'],lava:1}};
function thGen(name){
  const sc=TH_SC[name]||TH_SC.sunset,W=2400,H=900,c=document.createElement('canvas');c.width=W;c.height=H;const g=c.getContext('2d');
  let s=[...name].reduce((x,ch)=>x+ch.charCodeAt(0)*31,7);const rnd=()=>(s=(s*16807)%2147483647)/2147483647;
  const mix=(a,b,t)=>{const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),A=p(a),B=p(b);return'rgb('+A.map((v,i)=>Math.round(v+(B[i]-v)*t)).join(',')+')';};
  const hor=H*.62,sky=g.createLinearGradient(0,0,0,hor+40);sc.sky.forEach((col,i)=>sky.addColorStop(i/(sc.sky.length-1),col));g.fillStyle=sky;g.fillRect(0,0,W,H);
  if(sc.stars){for(let i=0;i<260;i++){g.fillStyle='rgba(255,255,255,'+(.25+rnd()*.7)+')';const z=rnd()<.15?3:2;g.fillRect(rnd()*W,rnd()*hor*.85,z,z);}}
  let sx=0,sy=0;
  if(sc.sun){sx=sc.sun[0]*W;sy=sc.sun[1]*H;
    g.globalCompositeOperation='lighter';
    const gl=g.createRadialGradient(sx,sy,10,sx,sy,620);gl.addColorStop(0,sc.sunc+'cc');gl.addColorStop(.2,mix(sc.fog,'#ffffff',.2).replace('rgb','rgba').replace(')',',.35)'));gl.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gl;g.fillRect(0,0,W,H);
    for(let i=0;i<16;i++){const ang=Math.PI*(.12+rnd()*.76),w=.03+rnd()*.07,L=1700;g.beginPath();g.moveTo(sx,sy);g.lineTo(sx+Math.cos(ang-w)*L,sy+Math.sin(ang-w)*L);g.lineTo(sx+Math.cos(ang+w)*L,sy+Math.sin(ang+w)*L);g.closePath();
      const rg=g.createLinearGradient(sx,sy,sx+Math.cos(ang)*L,sy+Math.sin(ang)*L);rg.addColorStop(0,'rgba(255,240,210,.16)');rg.addColorStop(1,'rgba(255,240,210,0)');g.fillStyle=rg;g.fill();}
    g.globalCompositeOperation='source-over';g.fillStyle=sc.sunc;g.fillRect(sx-46,sy-46,92,92);}
  if(sc.lava){g.globalCompositeOperation='lighter';for(let i=0;i<14;i++){const x=rnd()*W,r=200+rnd()*300,gr=g.createRadialGradient(x,hor,0,x,hor,r);gr.addColorStop(0,'rgba(255,110,30,.35)');gr.addColorStop(1,'rgba(255,60,0,0)');g.fillStyle=gr;g.fillRect(x-r,hor-r,r*2,r*2);}g.globalCompositeOperation='source-over';}
  const layers=[{base:hor-90,amp:90,bw:48,t:.78},{base:hor-30,amp:110,bw:40,t:.58},{base:hor+30,amp:130,bw:32,t:.36},{base:hor+110,amp:150,bw:28,t:.12}];
  layers.forEach((L,li)=>{
    const n=Math.ceil(W/L.bw)+2,v=[...Array(Math.ceil(n/6)+3)].map(()=>rnd()),col=mix(sc.land[1],sc.fog,L.t*.62),col2=mix(sc.land[0],sc.fog,L.t*.5);
    for(let i=0;i<n;i++){const k=i/6,j=Math.floor(k),f=k-j,h=(v[j]*(1-f)+v[j+1]*f),hh=Math.round((h*L.amp)/L.bw)*L.bw,y=L.base-hh;
      g.fillStyle=col;g.fillRect(i*L.bw,y,L.bw+1,H-y);g.fillStyle=col2;g.fillRect(i*L.bw,y,L.bw+1,Math.max(4,L.bw*.35));}
    if(li>=2&&!sc.lava){for(let t=0;t<(li===3?10:16);t++){const x=Math.round(rnd()*W/L.bw)*L.bw,col3=mix(sc.land[0],'#000000',.35),i=Math.floor(x/L.bw),k=i/6,j=Math.floor(k),f=k-j,hh=Math.round(((v[j]*(1-f)+v[j+1]*f)*L.amp)/L.bw)*L.bw,y=L.base-hh;
      g.fillStyle=col3;g.fillRect(x+L.bw*.25,y-L.bw*3,L.bw*.5,L.bw*3);g.fillRect(x-L.bw,y-L.bw*5,L.bw*3,L.bw*2);g.fillRect(x-L.bw*.0,y-L.bw*6.4,L.bw*1,L.bw*1.4);}}
  });
  if(sc.water){const wy=hor+170,wg=g.createLinearGradient(0,wy,0,H);wg.addColorStop(0,mix(sc.fog,sc.land[0],.5));wg.addColorStop(1,sc.land[0]);g.fillStyle=wg;g.fillRect(0,wy,W,H-wy);
    if(sc.sun){g.globalCompositeOperation='lighter';for(let y=wy;y<H;y+=9){const w=30+rnd()*150*(1-(y-wy)/(H-wy)*.5);g.fillStyle='rgba(255,230,190,'+(.1+rnd()*.28)*(1-(y-wy)/(H-wy)*.6)+')';g.fillRect(sx-w/2+(rnd()-.5)*40,y,w,4);}g.globalCompositeOperation='source-over';}}
  if(sc.mist||sc.fog){const mg=g.createLinearGradient(0,hor-140,0,hor+120);mg.addColorStop(0,'rgba(255,255,255,0)');mg.addColorStop(.5,mix(sc.fog,'#ffffff',.1).replace('rgb','rgba').replace(')',','+(sc.mist?.55:.28)+')'));mg.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=mg;g.fillRect(0,hor-140,W,260);}
  const bl=document.createElement('canvas');bl.width=W/4;bl.height=H/4;const bg2=bl.getContext('2d');bg2.filter='blur(6px) brightness(1.5)';bg2.drawImage(c,0,0,W/4,H/4);
  g.globalCompositeOperation='screen';g.globalAlpha=.45;g.drawImage(bl,0,0,W,H);g.globalAlpha=1;g.globalCompositeOperation='source-over';
  const vg=g.createRadialGradient(W/2,H/2,H*.3,W/2,H/2,W*.62);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(0,0,0,.55)');g.fillStyle=vg;g.fillRect(0,0,W,H);
  return c;
}
async function thLoad(){
  const p=S.profiles.find(x=>x.id===cur);if(!p)return;
  TH.d=await A('theme:get',cur);
  if(!/^#[0-9a-fA-F]{6}$/.test(TH.d.accent||''))TH.d.accent='#ff7a2f';
  TH.custom=false;TH.srcImg=null;
  if(TH.d.custom&&TH.d.prev){TH.src=TH.d.prev;TH.custom=true;await thImg(TH.src);}else thPreset(TH.d.preset);
}
function thImg(u){return new Promise(r=>{const i=new Image();i.onload=()=>{TH.srcImg=i;r(i);};i.onerror=()=>r(null);i.src=u;});}
function thPreset(n){TH.d.preset=TH_PRESETS[n]?n:'sunset';TH.custom=false;const c=thGen(TH.d.preset);TH.srcImg=c;TH.src=c.toDataURL('image/jpeg',.85);}
async function thDlg(){
  if(running)return toast(t('th_run'));
  try{await thLoad();}catch(e){return fail(e);}
  const d=TH.d;
  modal('<h2>'+esc(t('th_t'))+'</h2>'
    +'<div class="thp" id="thp"><div class="thbg" id="thbg"></div><div class="thfx"></div><div class="thui"><div class="thlogo">NRML</div><div class="thb">'+esc(t('th_sp'))+'</div><div class="thb">'+esc(t('th_mp'))+'</div></div></div>'
    +'<label class="c"><input type="checkbox" id="thon" '+(d.on?'checked':'')+' onchange="thUpd()"> '+esc(t('th_on'))+'</label>'
    +'<div class="thpre" id="thpre">'+Object.keys(TH_PRESETS).map(k=>'<button class="txt thsw'+(!TH.custom&&d.preset===k?' on':'')+'" data-k="'+k+'" style="--a:'+TH_PRESETS[k][1]+';--b:'+TH_PRESETS[k][2]+'" onclick="thSel(this.dataset.k)" title="'+k+'"></button>').join('')
    +'<button class="txt" onclick="thPick()">'+esc(t('th_img'))+'</button></div>'
    +'<div class="thr"><span>'+esc(t('th_acc'))+'</span><input type="color" id="th_acc" value="'+d.accent+'" oninput="thUpd()"><b></b></div>'
    +'<label class="c"><input type="checkbox" id="th_btn" '+(d.btn!==false?'checked':'')+' onchange="thUpd()"> '+esc(t('th_btns'))+'</label>'
    +'<label class="c"><input type="checkbox" id="th_anim" '+(d.anim===true?'checked':'')+' onchange="thUpd()"> '+esc(t('th_anim'))+'</label>'
    +'<label class="c"><input type="checkbox" id="th_static" '+(d.static!==false?'checked':'')+' onchange="thUpd()"> '+esc(t('th_static'))+'</label>'
    +'<label class="c"><input type="checkbox" id="th_font" '+(d.font!==false?'checked':'')+' onchange="thUpd()"> '+esc(t('th_font'))+'</label>'
    +'<label class="c"><input type="checkbox" id="th_logo" '+(d.logo===true?'checked':'')+' onchange="thUpd()"> '+esc(t('th_logot'))+'</label>'
    +'<label class="c"><input type="checkbox" id="th_splash" '+(d.splash!==false?'checked':'')+' onchange="thUpd()"> '+esc(t('th_spl'))+'</label>'
    +[['blur',t('th_blur'),0,10,1,d.blur,''],['speed',t('th_speed'),0,2,.1,d.speed,'x'],['zoom',t('th_zoom'),1,2.5,.05,d.zoom,'x'],['bright',t('th_bright'),40,120,1,d.bright,'%']].map(([k,l,mn,mx,st,v,u])=>
      '<div class="thr"><span>'+esc(l)+'</span><input type="range" id="th_'+k+'" min="'+mn+'" max="'+mx+'" step="'+st+'" value="'+v+'" oninput="thUpd()"><b id="thv_'+k+'">'+v+u+'</b></div>').join('')
    +'<p class="mut" style="font-size:11.5px">'+esc(t('th_note'))+'</p>'
    +'<div class="bar"><button class="solid" id="thsave" onclick="thSave()">'+esc(t('save'))+'</button><button class="txt" onclick="thReset()">'+esc(t('th_reset'))+'</button><button class="txt" onclick="closeM()">'+esc(t('cancel'))+'</button></div>');
  thUpd(true);
}
function thVals(){const g=k=>+document.getElementById('th_'+k).value;return{static:document.getElementById('th_static').checked,font:document.getElementById('th_font').checked,anim:document.getElementById('th_anim').checked,acc:document.getElementById('th_acc').value,btn:document.getElementById('th_btn').checked,logo:document.getElementById('th_logo').checked,splash:document.getElementById('th_splash').checked,on:document.getElementById('thon').checked,blur:g('blur'),speed:g('speed'),zoom:g('zoom'),bright:g('bright')};}
function thUpd(first){
  const v=thVals(),bg=document.getElementById('thbg');if(!bg)return;
  if(bg.dataset.s!==TH.src){bg.style.backgroundImage='url('+TH.src+')';bg.dataset.s=TH.src;}
  bg.style.setProperty('--bl',(v.blur*1.1)+'px');bg.style.setProperty('--z',v.zoom);bg.style.setProperty('--br',v.bright/100);bg.style.setProperty('--sp',v.speed?(60/v.speed)+'s':'0s');
  const lg=document.querySelector('#thp .thlogo');if(lg)lg.textContent=v.logo?'NRML':'MINECRAFT';
  bg.classList.toggle('still',!v.speed||v.static);document.getElementById('th_speed').disabled=v.static;
  const pp=document.getElementById('thp');pp.style.setProperty('--ac',v.acc);pp.classList.toggle('plain',!v.btn);
  document.getElementById('thp').classList.toggle('off',!v.on);
  for(const [k,u] of [['blur',''],['speed','x'],['zoom','x'],['bright','%']]){const e=document.getElementById('thv_'+k);if(e)e.textContent=v[k]+u;}
}
function thSel(k){thPreset(k);document.getElementById('th_acc').value=TH_PRESETS[k][1];document.querySelectorAll('#thpre .thsw').forEach(b=>b.classList.toggle('on',b.dataset.k===k));thUpd();}
async function thPick(){
  try{
    const u=await A('theme:pick');if(!u)return;
    const img=await thImg(u);if(!img)return toast(t('th_bad'));
    const c=document.createElement('canvas'),k=Math.min(1,1600/img.width);c.width=Math.round(img.width*k);c.height=Math.round(img.height*k);
    c.getContext('2d').drawImage(img,0,0,c.width,c.height);
    TH.srcImg=c;TH.src=c.toDataURL('image/jpeg',.8);TH.custom=true;
    document.querySelectorAll('#thpre .thsw').forEach(b=>b.classList.remove('on'));thUpd();
  }catch(e){fail(e);}
}
function thReset(){TH.d.preset='sunset';thPreset('sunset');document.querySelectorAll('#thpre .thsw').forEach(b=>b.classList.toggle('on',b.dataset.k==='sunset'));
  const set=(k,v)=>{document.getElementById('th_'+k).value=v;};set('acc','#ff7a2f');set('blur',5);set('speed',1);set('zoom',1.2);set('bright',90);thUpd();}
function thBgImage(v){
  const im=TH.srcImg,W=im.naturalWidth||im.width,H=im.naturalHeight||im.height,z=Math.max(1,v.zoom),tw=1600,th=900;
  let cw=Math.min(W,H*16/9)/z,ch=cw*9/16;if(ch>H){ch=H/z;cw=ch*16/9;}
  const c=document.createElement('canvas');c.width=tw;c.height=th;const g=c.getContext('2d'),px=Math.round(v.blur*1.1),pad=px*2;
  g.filter='blur('+px+'px) brightness('+v.bright+'%)';
  g.drawImage(im,(W-cw)/2,(H-ch)/2,cw,ch,-pad,-pad,tw+pad*2,th+pad*2);
  return c.toDataURL('image/png');
}
function thFaces(v){
  const im=TH.srcImg,W=im.naturalWidth||im.width,H=im.naturalHeight||im.height,side=Math.min(W,H)/v.zoom,out=[];
  for(let i=0;i<6;i++){
    const c=document.createElement('canvas');c.width=c.height=512;const g=c.getContext('2d');
    g.filter='brightness('+v.bright+'%)';
    const sx=Math.max(0,(W-side))*(i/5),sy=(H-side)/2;
    g.drawImage(im,sx,sy,side,side,0,0,512,512);
    out.push(c.toDataURL('image/png'));
  }
  return out;
}
function thSprites(acc,anim){
  const rgb=[1,3,5].map(i=>parseInt(acc.slice(i,i+2),16)),c=(al,k=1)=>'rgba('+rgb.map(x=>Math.min(255,Math.round(x*k))).join(',')+','+al+')';
  const K=1,W=200,H=20,R=6;
  const rr=(g,x,y,w,h,r)=>{g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath();};
  const btn=(kind,frames)=>{
    const cv=document.createElement('canvas');cv.width=W;cv.height=H*frames;const g=cv.getContext('2d');
    for(let f=0;f<frames;f++){
      g.save();g.translate(0,f*H);
      const hi=kind==='h',dis=kind==='d',m=.5;
      rr(g,m,m,W-2*m,H-2*m,R);g.save();g.clip();
      g.fillStyle=dis?'rgba(255,255,255,.035)':hi?c(.34):'rgba(255,255,255,.085)';g.fillRect(0,0,W,H);
      const gl=g.createLinearGradient(0,0,0,H);gl.addColorStop(0,'rgba(255,255,255,'+(hi?.16:.07)+')');gl.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=dis?'rgba(0,0,0,0)':gl;g.fillRect(0,0,W,H);
      if(hi&&frames>1){const p=f/(frames-1),x=-W*.3+p*W*1.6,sg=g.createLinearGradient(x,0,x+W*.28,H);sg.addColorStop(0,'rgba(255,255,255,0)');sg.addColorStop(.5,'rgba(255,255,255,.22)');sg.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=sg;g.fillRect(0,0,W,H);}
      g.restore();
      rr(g,m,m,W-2*m,H-2*m,R);g.lineWidth=1;g.strokeStyle=dis?'rgba(255,255,255,.07)':hi?c(1,1.1):'rgba(255,255,255,.2)';g.stroke();
      g.restore();
    }
    return cv.toDataURL('image/png');
  };
  const mk=(w,h,fn)=>{const cv=document.createElement('canvas');cv.width=w;cv.height=h;fn(cv.getContext('2d'));return cv.toDataURL('image/png');};
  const FONT='"Segoe UI Variable Display","Segoe UI","Helvetica Neue",Arial,sans-serif';
  const logo=mk(256,64,g=>{
    g.clearRect(0,0,256,64);g.textBaseline='middle';g.textAlign='left';
    g.font='600 25px '+FONT;
    const word='NRML',sp=9;let wd=0;for(const ch of word)wd+=g.measureText(ch).width+sp;wd-=sp;
    let x=(256-wd)/2;const y=29,gr=g.createLinearGradient(0,17,0,41);gr.addColorStop(0,'#ffffff');gr.addColorStop(1,'#e6e6ee');
    g.shadowColor=c(.85);g.shadowBlur=7;
    for(const ch of word){g.fillStyle=gr;g.fillText(ch,x,y);x+=g.measureText(ch).width+sp;}
  });
  const edition=mk(128,14,g=>{g.clearRect(0,0,128,14);g.font='600 9px '+FONT;g.textBaseline='middle';g.textAlign='center';g.fillStyle=c(1,1.1);g.fillText('C L I E N T',64,6);});
  return{button:btn('n',1),buttonH:btn('h',anim?8:1),buttonD:btn('d',1),logo,edition};
}
async function thSave(){
  const v=thVals(),btn=document.getElementById('thsave');btn.disabled=true;
  try{
    const o={id:cur,on:v.on,preset:TH.d.preset,blur:v.blur,speed:v.speed,bright:v.bright,zoom:v.zoom,custom:TH.custom,static:v.static,font:v.font,btn:v.btn,anim:v.anim,logo:v.logo,splash:v.splash,accent:v.acc};
    if(v.on){o.faces=thFaces(v);o.ui=thSprites(v.acc,v.anim);o.anim=v.anim;o.static=v.static;if(v.static)o.ui.bg=thBgImage(v);
      if(TH.custom){const im=TH.srcImg,W=im.naturalWidth||im.width,H=im.naturalHeight||im.height,k=Math.max(640/W,360/H),pc=document.createElement('canvas');pc.width=640;pc.height=360;
        pc.getContext('2d').drawImage(im,(640-W*k)/2,(360-H*k)/2,W*k,H*k);o.prev=pc.toDataURL('image/jpeg',.75);}}
    await A('theme:save',o);
    closeM(true);toast(t(v.on?'th_saved':'th_off'));refreshFiles();
  }catch(e){btn.disabled=false;fail(e);}
}
{const _dp2=drawPane;drawPane=async function(){await _dp2.apply(this,arguments);
  const a=document.querySelector('#pane .acts');
  if(a&&!a.querySelector('.thbtn'))a.insertAdjacentHTML('afterbegin','<button class="thbtn" onclick="thDlg()">'+NXI.edit+' '+esc(t('th_btn'))+'</button>');};}


/* ---- 2.3.0 self-update: centred prompt + cinematic installer ---- */
const NXUP={s:null,t:null,hid:null,cin:null};
const NX_CUBE='<svg viewBox="0 0 64 64" class="cn-cube"><polygon fill="#e9e6df" points="32,5 56,19 32,33 8,19"/><polygon fill="#3b3b3f" points="8,19 32,33 32,61 8,47"/><polygon fill="var(--acc,#ff5a1f)" points="32,33 56,19 56,47 32,61"/></svg>';
function nxNotes(s){const n=s&&s.notes;if(!n)return '';if(typeof n==='string')return n;return n[lang]||n.en||'';}
function nxUpdLayer(){let b=document.getElementById('nxupd');if(!b){document.body.insertAdjacentHTML('beforeend','<div id="nxupd" role="dialog" aria-modal="true"></div>');b=document.getElementById('nxupd');}return b;}
function nxUpdClose(later){const b=document.getElementById('nxupd');if(b){b.classList.remove('on');b.classList.add('out');setTimeout(()=>{if(!b.classList.contains('on'))b.innerHTML='';},500);}
  if(later&&NXUP.s)NXUP.hid=NXUP.s.latest;NXUP.cin=null;}
function nxUpdDraw(s){
  NXUP.s=s;if(NXUP.cin||!s)return;
  const dismissed=NXUP.hid&&NXUP.hid===s.latest;
  if((s.status==='available'||s.status==='ready')&&!dismissed){
    const b=nxUpdLayer(),ready=s.status==='ready',key=s.status+'|'+s.latest;
    if(b.dataset.k===key&&b.classList.contains('on'))return;
    b.dataset.k=key;b.className='';
    b.innerHTML='<i class="bd"></i><div class="up-card"><div class="up-ic">'+NX_CUBE+'</div><div class="up-tx"><b>'+esc(ready?t('ud_ready'):t('ud_title',s.latest))+'</b><span>'+esc(ready?t('ud_ready2',s.latest):(nxNotes(s)||t('ud_sub')))+'</span></div>'
      +'<div class="up-act"><button class="solid" onclick="'+(ready?'nxUpdRestart()':'nxUpdGo()')+'">'+esc(ready?t('ud_restart'):t('ud_btn'))+'</button><button class="txt" onclick="nxUpdClose(true)">'+esc(t('ud_later'))+'</button></div></div>';
    requestAnimationFrame(()=>requestAnimationFrame(()=>b.classList.add('on')));
  }
}
function nxUpdRestart(){try{A('upd:restart');}catch{}const b=document.getElementById('nxupd');if(b)b.classList.add('go');}
async function nxUpdGo(){
  let s=NXUP.s;try{s=await A('upd:install');}catch{}NXUP.s=s;
  const b=nxUpdLayer();b.className='';b.dataset.k='cin';
  b.innerHTML='<div class="cn"><div class="cn-bg"></div><div class="cn-glow"></div>'
    +'<div class="cn-c"><div class="cn-logo">'+NX_CUBE+'<i class="cn-ring"></i><i class="cn-ring r2"></i><svg class="cn-ok" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div>'
    +'<div class="cn-h">'+esc(t('ud_h1'))+'</div><div class="cn-v">'+esc((s&&s.latest)||'')+'</div>'
    +'<div class="cn-bar"><u></u></div><div class="cn-row"><span class="cn-ph">'+esc(t('ud_p_dl'))+'</span><span class="cn-pc">0%</span></div>'
    +'<div class="cn-act"></div></div></div>';
  b.classList.add('on','cin');
  NXUP.cin={t0:performance.now(),p:0,done:false,err:false};nxUpdPoll();requestAnimationFrame(nxCinTick);
}
function nxCinTick(){
  const c=NXUP.cin,b=document.getElementById('nxupd');if(!c||!b)return;
  if(!c.u){c.u=b.querySelector('.cn-bar u');c.ph=b.querySelector('.cn-ph');c.pc=b.querySelector('.cn-pc');c.act=b.querySelector('.cn-act');c.lp=-1;c.lt='';}
  const s=NXUP.s||{},el=(performance.now()-c.t0)/1000,MIN=5.0;
  if(s.status==='error'&&!c.err){c.err=true;b.classList.add('bad');
    c.ph.textContent=t('ud_err');c.pc.textContent='';
    c.act.innerHTML='<div class="cn-er">'+esc(s.err||'')+'</div><button class="txt" onclick="nxUpdClose(true)">'+esc(t('ud_close'))+'</button>';return;}
  if(c.err)return;
  const real=s.status==='ready'?100:Math.min(94,(s.pct|0)*.94),target=Math.min(real,Math.min(100,el/MIN*100));
  c.p=Math.max(c.p,c.p+(target-c.p)*.12);if(target-c.p<.08)c.p=target;
  const p=Math.min(100,c.p);
  c.u.style.transform='scaleX('+(p/100)+')';
  const pi=Math.floor(p);if(pi!==c.lp){c.lp=pi;c.pc.textContent=pi+'%';
    const k=p<68?'ud_p_dl':p<92?'ud_p_ver':p<99.9?'ud_p_ins':'ud_p_done';if(k!==c.lt){c.lt=k;c.ph.textContent=t(k);}}
  if(p>=99.9&&s.status==='ready'&&!c.done){c.done=true;b.classList.add('fin');
    c.act.innerHTML='<div class="cn-er ok">'+esc(t('ud_ready2',s.latest))+'</div><button class="solid" onclick="nxUpdRestart()">'+esc(t('ud_restart'))+'</button><button class="txt" onclick="nxUpdClose(true)">'+esc(t('ud_later'))+'</button>';return;}
  requestAnimationFrame(nxCinTick);
}
function nxUpdPoll(){
  clearTimeout(NXUP.t);
  const fast=!NXUP.s||NXUP.s.status==='downloading'||NXUP.cin;
  NXUP.t=setTimeout(async()=>{let s;try{s=await A('upd:state');}catch{return;}
    nxUpdFix(s);nxUpdDraw(s);NXUP.s=s;nxUpdPoll();},fast?350:20000);
}
/* real version number in the settings footer */
function nxUpdFix(s){if(!s||!s.cur||NXUP.fixed===s.cur)return;NXUP.fixed=s.cur;
  for(const l in T){if(T[l]&&typeof T[l].st_note==='string')T[l].st_note=T[l].st_note.replace(/NRML Client \d+\.\d+\.\d+/,'NRML Client '+s.cur);}}
setTimeout(nxUpdPoll,1500);

/* ---- 2.3.1 launcher intro: starts only when the window is really visible; the line drops and "Client" is written in ---- */
(function(){
  const sp=document.getElementById('splash');if(!sp)return;
  sp.dataset.h='1';  // switch off the old fixed-time hide
  const cli=document.getElementById('spcli');
  if(cli)cli.innerHTML=[...'Client'].map((c,i)=>'<span style="--i:'+i+'">'+c+'</span>').join('');
  let started=false;
  const leave=()=>{sp.classList.add('leave');setTimeout(()=>sp.classList.add('out'),820);setTimeout(()=>{try{sp.remove();}catch{}},1700);};
  const start=()=>{if(started)return;started=true;try{const sb=sp.querySelector('.sp-sub').getBoundingClientRect(),ss=cli.querySelectorAll('span'),f=ss[0].getBoundingClientRect(),l=ss[ss.length-1].getBoundingClientRect(),w=l.right-f.left-parseFloat(getComputedStyle(cli).fontSize)*.62;if(sb.width>0&&w>0)sp.style.setProperty('--cs',Math.min(1,(w+6)/sb.width).toFixed(3));}catch{}sp.classList.add('spgo');setTimeout(leave,4100);};
  const ready=()=>setTimeout(()=>requestAnimationFrame(()=>requestAnimationFrame(start)),450);
  if(document.visibilityState==='visible')ready();
  else document.addEventListener('visibilitychange',function f(){if(document.visibilityState==='visible'){document.removeEventListener('visibilitychange',f);ready();}});
  setTimeout(()=>{if(!started)start();},9000);  // safety net
})();

/* ---- 2.4.0 launch cinematic: Play flies to the centre and becomes a loader, with Cancel launch ---- */
const NXL={open:false,pend:false,cancelled:false,zombie:false,t:null,fb:null};
function nxLcEl(){let e=document.getElementById('nxlaunch');if(!e){document.body.insertAdjacentHTML('beforeend','<div id="nxlaunch" role="dialog" aria-modal="true"></div>');e=document.getElementById('nxlaunch');}return e;}
function nxLcOpen(){
  clearTimeout(NXL.t);clearTimeout(NXL.fb);NXL.open=true;NXL.ok=false;
  const e=nxLcEl(),src=[...document.querySelectorAll('[data-play]')].find(b=>b.offsetParent!==null),r=src?src.getBoundingClientRect():{left:innerWidth/2-60,top:innerHeight/2-20,width:120,height:40};
  const cs=src?getComputedStyle(src):null,label=src?(src.textContent||'').trim():'PLAY';
  const R=66,cx=innerWidth/2,cy=innerHeight/2,d=84;
  e.className='';
  e.innerHTML='<div class="lc-bd"></div>'
    +'<div class="lc-fly" style="left:'+r.left+'px;top:'+r.top+'px;width:'+r.width+'px;height:'+r.height+'px;border-radius:'+(cs?cs.borderRadius:'0')+'"><span class="lc-t">'+esc(label)+'</span><span class="lc-pl">'+I.play+'</span></div>'
    +'<div class="lc-c"><div class="lc-ring"><svg viewBox="0 0 120 120"><circle class="lc-trk" cx="60" cy="60" r="54"/><circle class="lc-arc" cx="60" cy="60" r="54"/></svg></div>'
    +'<div class="lc-st">'+esc(t('lc_prep'))+'</div><div class="lc-dt"></div><div class="lc-bar ind"><u></u></div>'
    +'<button class="txt lc-x" onclick="nxLcCancel()">'+esc(t('lc_cancel'))+'</button></div>';
  NXL.st=e.querySelector('.lc-st');NXL.dt=e.querySelector('.lc-dt');NXL.bar=e.querySelector('.lc-bar');NXL.u=e.querySelector('.lc-bar u');NXL.key='';
  requestAnimationFrame(()=>requestAnimationFrame(()=>{
    e.classList.add('on');const f=e.querySelector('.lc-fly');
    f.classList.add('fl');f.style.left=(cx-d/2)+'px';f.style.top=(cy-d/2)+'px';f.style.width=d+'px';f.style.height=d+'px';f.style.borderRadius='50%';
    setTimeout(()=>{if(NXL.open)e.classList.add('rg');},300);
  }));
}
function nxLcHide(){
  clearTimeout(NXL.fb);const e=document.getElementById('nxlaunch');NXL.open=false;if(!e)return;
  e.classList.remove('on');NXL.t=setTimeout(()=>{if(!NXL.open)e.innerHTML='';},600);
}
function nxLcStatus(m){
  if(!NXL.open||NXL.ok||!m)return;
  const [k,d]=String(m).slice(2).split('|');
  const lab=t('s_'+k);if(!lab||lab==='s_'+k)return;
  if(k===NXL.key&&k!=='dl'&&k!=='upd'&&k!=='opt'){}
  else if(k!==NXL.key){NXL.key=k;NXL.st.textContent=lab.replace('…','');NXL.st.classList.remove('sw');void NXL.st.offsetWidth;NXL.st.classList.add('sw');}
  const mm=(d||'').match(/(\d+)\/(\d+)/);
  NXL.dt.textContent=d||'';
  if(mm&&+mm[2]){NXL.bar.classList.remove('ind');NXL.u.style.transform='scaleX('+Math.min(1,+mm[1]/+mm[2])+')';}else{NXL.bar.classList.add('ind');NXL.u.style.transform='';}
  if(k==='run')nxLcDone();
}
function nxLcDone(){
  if(NXL.ok)return;NXL.ok=true;try{A('mem:trim');}catch{}const e=document.getElementById('nxlaunch');if(!e)return;
  e.classList.add('ok');NXL.st.textContent=t('lc_ready');NXL.dt.textContent='';NXL.bar.classList.remove('ind');NXL.u.style.transform='scaleX(1)';
  NXL.fb=setTimeout(nxLcHide,1500);
}
async function nxLcCancel(){
  if(NXL.cancelled)return;NXL.cancelled=true;NXL.zombie=NXL.pend;
  if(NXL.st)NXL.st.textContent=t('lc_cancelling');if(NXL.dt)NXL.dt.textContent='';
  try{await A('launch:cancel');}catch{}
  running=false;runLabel='';syncPlay();toast(t('lc_cancelled'));
  setTimeout(nxLcHide,500);
}
{const _run=run;run=async function(){
  if(NXL.zombie){toast(t('lc_wait'));return;}
  NXL.cancelled=false;try{await A('launch:begin');}catch{}
  nxLcOpen();NXL.pend=true;
  try{return await _run.apply(this,arguments);}
  finally{NXL.pend=false;
    if(NXL.cancelled){NXL.zombie=false;try{document.getElementById('toasts').innerHTML='';}catch{}}
    else if(!running)nxLcHide();
    else if(!NXL.ok)NXL.fb=setTimeout(()=>{if(NXL.open)nxLcHide();},30000);}
};}
try{window.api.on('status',nxLcStatus);window.api.on('closed',()=>{NXL.zombie=false;if(NXL.open)nxLcHide();});window.api.on('crashed',()=>{if(NXL.open)nxLcHide();});}catch{}

/* ---- 2.5.0 profile switch + profile created/imported cinematics ---- */
const NXP={sw:false,t0:0,ids:null,kind:'new',busy:false};
{const _pk=pick;pick=function(id){
  if(id===cur)return;
  const p=document.getElementById('pane');
  if(p&&document.getElementById('rows')){NXP.sw=true;NXP.t0=performance.now();p.classList.remove('nx-in');p.classList.add('nx-out');}
  return _pk.apply(this,arguments);};}
{const _dp=drawPane;drawPane=async function(){
  if(!NXP.sw)return _dp.apply(this,arguments);
  const pr=_dp.apply(this,arguments),my=paneSeq;
  try{await pr;}finally{
    if(my===paneSeq){
      const w=Math.max(0,230-(performance.now()-NXP.t0));if(w)await new Promise(r=>setTimeout(r,w));
      if(my===paneSeq){NXP.sw=false;const p=document.getElementById('pane');if(p){p.classList.remove('in','nx-out');void p.offsetWidth;p.classList.add('nx-in');setTimeout(()=>p.classList.remove('nx-in'),1500);}}
    }
  }};}
{const _sp=saveP;saveP=function(){NXP.kind='new';return _sp.apply(this,arguments);};}
{const _ip=importP;importP=function(){NXP.kind='imp';return _ip.apply(this,arguments);};}
{const _lib=lib;lib=function(){
  const r=_lib.apply(this,arguments);
  try{const ids=(S.profiles||[]).map(p=>p.id);
    if(NXP.ids){const nw=ids.filter(x=>!NXP.ids.includes(x));if(nw.length&&document.getElementById('rows'))nxProfDone(nw[nw.length-1]);}
    NXP.ids=ids;}catch{}
  return r;};}
function nxProfDone(id){
  if(NXP.busy)return;NXP.busy=true;
  const pr=(S.profiles||[]).find(p=>p.id===id)||{name:''},imp=NXP.kind==='imp';NXP.kind='new';
  let e=document.getElementById('nxprof');if(e)e.remove();
  document.body.insertAdjacentHTML('beforeend','<div id="nxprof"><div class="pf-bd"></div><div class="pf-c"><div class="pf-ring"><svg viewBox="0 0 120 120"><circle class="pf-trk" cx="60" cy="60" r="54"/><circle class="pf-arc" cx="60" cy="60" r="54"/></svg>'
    +'<svg class="pf-cube" viewBox="0 0 64 64"><polygon fill="#e9e6df" points="32,5 56,19 32,33 8,19"/><polygon fill="#3b3b3f" points="8,19 32,33 32,61 8,47"/><polygon fill="var(--acc,#ff5a1f)" points="32,33 56,19 56,47 32,61"/></svg>'
    +'<svg class="pf-ok" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div>'
    +'<div class="pf-h">'+esc(t(imp?'pr_imp':'pr_new'))+'</div><div class="pf-n">'+esc(pr.name||'')+'</div></div></div>');
  e=document.getElementById('nxprof');
  requestAnimationFrame(()=>requestAnimationFrame(()=>e.classList.add('on')));
  setTimeout(()=>{e.classList.remove('on');e.classList.add('out');
    const row=document.querySelector('.prow[data-id="'+id+'"]');
    if(row){row.classList.add('nx-new');try{row.scrollIntoView({block:'nearest',behavior:'smooth'});}catch{}setTimeout(()=>row.classList.remove('nx-new'),1800);}
    setTimeout(()=>{e.remove();NXP.busy=false;},600);},2300);
}


/* ---- 2.6.0 sidebar without flicker; recently updated mods ---- */
{const _dr=drawRows;drawRows=function(){
  const rows=document.getElementById('rows');
  if(rows&&NXP.sw&&rows.querySelector('.prow[data-id]')){   // profile switch: just move the highlight, do not rebuild
    rows.querySelectorAll('.prow').forEach(r=>r.classList.toggle('on',r.dataset.id===cur));return;}
  const r=_dr.apply(this,arguments);
  const rw=document.getElementById('rows');if(rw&&!rw.classList.contains('rd')&&!rw.dataset.w){rw.dataset.w='1';setTimeout(()=>rw.classList.add('rd'),1100);}
  return r;};}
const NXREC={upd:null,n:-1};
function nxRecGet(pid){try{const a=JSON.parse(localStorage.getItem('nrml.rec')||'{}'),o=a[pid]||{},now=Date.now();let ch=false;for(const k in o)if(now-o[k]>300000){delete o[k];ch=true;}if(ch){a[pid]=o;localStorage.setItem('nrml.rec',JSON.stringify(a));}return o;}catch{return{};}}
function nxRecSet(pid,f){try{const a=JSON.parse(localStorage.getItem('nrml.rec')||'{}');(a[pid]=a[pid]||{})[f]=Date.now();localStorage.setItem('nrml.rec',JSON.stringify(a));}catch{}}
function nxRecDecorate(){
  const box=document.getElementById('flist');if(!box||tab!=='mods')return;
  const rec=nxRecGet(cur),u=NXREC.upd&&NXREC.upd.pid===cur?NXREC.upd:null;NXREC.n=Object.keys(rec).length;
  const rows=[...box.querySelectorAll('.frow.nx')].filter(r=>rec[r.dataset.f]||(u&&u.act(r)));
  rows.sort((x,y)=>(rec[y.dataset.f]||Infinity)-(rec[x.dataset.f]||Infinity));
  for(const r of rows.reverse()){
    const live=!rec[r.dataset.f]&&u,b=r.querySelector('.n b');
    r.classList.add('rcnt');if(live)r.classList.add('rup');
    if(b)b.insertAdjacentHTML('beforeend','<em class="rtag'+(live?' lv':'')+'">'+esc(t(live?'rc_up':'rc_tag'))+'</em>');
    if(live)r.insertAdjacentHTML('beforeend','<i class="rp"><u style="transform:scaleX('+(u.pct/100)+')"></u></i>');
    box.insertBefore(r,box.firstChild);}
}
{const _np=nxPaint;nxPaint=function(){const r=_np.apply(this,arguments);try{nxRecDecorate();}catch{}return r;};}
{const _um=updMods;updMods=async function(){
  if(running)return _um.apply(this,arguments);
  const pid=cur;let nm=[];try{const r=await A('mods:check',pid);nm=((r&&r.names)||[]).map(x=>String(x).toLowerCase());}catch{}
  const before=new Set((FILES&&FILES.mods)||[]);
  const U=NXREC.upd={pid,nm,pct:3,act:r=>{const b=((r.querySelector('.n b')||{}).textContent||'').toLowerCase().replace(/\s+/g,' ').trim();return !!b&&nm.some(x=>b===x||b.includes(x)||x.includes(b));}};
  const diff=async()=>{try{const f=await A('flist',pid);if(cur!==pid)return;const add=(f.mods||[]).filter(n=>!before.has(n)&&!/\.disabled$/i.test(n));
    if(add.length){add.forEach(n=>{before.add(n);nxRecSet(pid,n);});FILES=f;nxPaint(true);}}catch{}};
  nxPaint(true);
  const tk=setInterval(()=>{U.pct+=(92-U.pct)*.05;document.querySelectorAll('#flist .rp u').forEach(u=>u.style.transform='scaleX('+(U.pct/100)+')');},250);
  const pl=setInterval(diff,1000);
  try{return await _um.apply(this,arguments);}
  finally{clearInterval(tk);clearInterval(pl);await diff();NXREC.upd=null;try{nxPaint(true);}catch{}}
};}
setInterval(()=>{try{if(tab==='mods'&&document.getElementById('flist')&&Object.keys(nxRecGet(cur)).length!==NXREC.n)nxPaint(true);}catch{}},15000);

// ===== 2.7 search / versions / sync =====
var NXS={seq:0,res:[],tm:0,vs:[],pj:null,ty:'mod',all:false};
const nxSType=()=>TYPE[tab]||'mod';
(function(){const _db=drawBar;drawBar=function(){_db.apply(this,arguments);try{nxSbAdd();}catch{}};})();
function nxSbAdd(){
  const b=document.getElementById('tbar');if(!b||b.querySelector('#nxq'))return;
  const w=document.createElement('div');w.className='nxsb';
  w.innerHTML='<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg><input id="nxq" type="text" autocomplete="off" spellcheck="false" placeholder="'+esc(t('sr_ph'))+'" oninput="nxFiltD()" onkeydown="if(event.key===\'Enter\')nxSGo();if(event.key===\'Escape\'){this.value=\'\';nxFilt();nxSHide();}"><button class="nxmr" onclick="nxSGo()">Modrinth</button><div id="nxsr"></div>';
  b.insertBefore(w,b.firstChild);
  if(tab==='mods'){const y=document.createElement('button');y.className='nxsy';y.innerHTML='⇄ '+esc(t('sy_btn'));y.onclick=()=>nxSync();b.insertBefore(y,w.nextSibling);}
}
function nxFiltD(){clearTimeout(NXS.tm);NXS.tm=setTimeout(nxFilt,70);}
function nxFilt(){
  const q=((document.getElementById('nxq')||{}).value||'').trim().toLowerCase(),L=document.getElementById('flist');if(!L)return;
  let n=0;
  L.querySelectorAll('.frow').forEach(r=>{if(r._t==null)r._t=((r.dataset.f||'')+' '+r.textContent).toLowerCase();const m=!q||r._t.includes(q);if(r._h!==!m){r.style.display=m?'':'none';r._h=!m;}if(m)n++;});
  let e=document.getElementById('nxno');
  if(q&&!n){if(!e){e=document.createElement('div');e.id='nxno';e.className='nxe';L.parentNode.insertBefore(e,L.nextSibling);}e.textContent=t('sr_nofile');}else if(e)e.remove();
}
(function(){const _p=nxPaint;nxPaint=function(){const r=_p.apply(this,arguments);try{nxFilt();}catch{}return r;};})();
(function(){const _d=drawFiles;drawFiles=function(){const r=_d.apply(this,arguments);try{nxFilt();}catch{}return r;};})();
function nxSHide(){const b=document.getElementById('nxsr');if(b)b.classList.remove('on');}
async function nxSGo(){
  const q=((document.getElementById('nxq')||{}).value||'').trim(),box=document.getElementById('nxsr');if(!box||!q)return;
  const my=++NXS.seq;box.classList.add('on');box.innerHTML='<div class="nxe">'+esc(t('sr_load'))+'</div>';
  try{
    const r=await A('search',nxSType(),q,cur,0);if(my!==NXS.seq)return;
    NXS.res=r||[];
    box.innerHTML=NXS.res.length?NXS.res.map((h,i)=>'<div class="nxi" onclick="nxPick('+i+')"><img loading="lazy" decoding="async" src="'+esc(h.icon_url||'')+'" alt=""><span><b>'+esc(h.title)+'</b><small>'+esc(h.description||'')+'</small></span><em>'+esc(h.author||'')+'</em></div>').join(''):'<div class="nxe">'+esc(t('sr_none'))+'</div>';
  }catch(e){if(my===NXS.seq)box.innerHTML='<div class="nxe">'+esc(t('sr_err'))+'</div>';}
}
document.addEventListener('mousedown',e=>{if(!e.target.closest('.nxsb'))nxSHide();});
function nxPick(i){const h=NXS.res[i];if(!h)return;nxSHide();nxVerOpen({project_id:h.project_id,title:h.title},nxSType(),false);}
// ---- version selector (install newer OR roll back) ----
async function nxVerOpen(pj,ty,all){
  NXS.pj=pj;NXS.ty=ty;NXS.all=!!all;
  modal('<div class="nxm"><div class="nxh"><h2>'+esc(pj.title)+'</h2><p class="mut">'+esc(pj.version?t('vr_cur')+' '+pj.version:t('vr_sub'))+'</p></div><div class="nxbody" id="nxvl"><div class="nxe">'+esc(t('sr_load'))+'</div></div><div class="nxft"><label class="nxck"><input type="checkbox" id="nxall" '+(all?'checked':'')+' onchange="nxVerOpen(NXS.pj,NXS.ty,this.checked)"> '+esc(t('vr_all'))+'</label><span style="flex:1"></span><button class="txt" onclick="closeM()">'+esc(t('cancel'))+'</button></div></div>');
  try{
    const vs=await A('lib:versions',cur,pj.project_id,ty,!!all);NXS.vs=vs;
    const ii=vs.findIndex(v=>v.installed),L=document.getElementById('nxvl');if(!L)return;
    L.innerHTML=vs.length?vs.map((v,k)=>{
      const act=v.installed?'<span class="nxbadge">'+esc(t('vr_have'))+'</span>':'<button class="'+(ii>=0&&k>ii?'':'solid')+'" onclick="nxVI('+k+',this)">'+esc(ii<0?t('vr_inst'):k<ii?t('vr_up'):t('vr_down'))+'</button>';
      return '<div class="nxv'+(v.installed?' cur':'')+'"><div class="n"><div><b>'+esc(v.number)+'</b><em class="ty '+esc(v.type)+'">'+esc(v.type)+'</em></div><small>'+esc(v.mc.slice(0,5).join(' · ')+(v.mc.length>5?' …':''))+' · '+esc((v.date||'').slice(0,10))+'</small></div>'+act+'</div>';
    }).join(''):'<div class="nxe">'+esc(t('vr_none'))+'</div>';
    const c=L.querySelector('.cur');if(c)c.scrollIntoView({block:'center'});
  }catch(e){const l=document.getElementById('nxvl');if(l)l.innerHTML='<div class="nxe">'+esc(t('sr_err'))+'</div>';}
}
async function nxVI(k,btn){
  const v=NXS.vs[k];if(!v)return;btn.disabled=true;btn.textContent='…';
  try{await A('lib:install',cur,v.id,NXS.ty);toast(t('vr_done')+' '+v.number);closeM();try{refreshFiles();}catch{}}
  catch(e){btn.disabled=false;btn.textContent=t('vr_inst');fail(e);}
}
// versions button inside the file drawer
(function(){const _d=nxDrawer;nxDrawer=function(html,file){_d.apply(this,arguments);try{
  const a=file&&document.querySelector('#dr .dr-a');
  if(a&&!a.querySelector('.nxvb')&&/\.(jar|zip)(\.disabled)?$/i.test(file)){const b=document.createElement('button');b.className='txt nxvb';b.textContent='⇅ '+t('vr_btn');b.onclick=()=>nxVerFile(file);a.insertBefore(b,a.children[1]||null);}
}catch{}};})();
async function nxVerFile(file){
  try{
    const ty=nxSType(),pj=await A('lib:project',cur,ty,file);
    if(!pj){toast(t('vr_nomr'));return;}
    nxClose();nxVerOpen(pj,ty,false);
  }catch(e){fail(e);}
}
// ---- sync compatibility ----
async function nxSync(target){
  const keep=document.getElementById('nxsy');
  if(!keep)modal('<div class="nxm"><div class="nxh"><h2>⇄ '+esc(t('sy_btn'))+'</h2></div><div class="nxbody" id="nxsy"><div class="nxe">'+esc(t('sy_scan'))+'</div></div><div class="nxft" id="nxsf"></div></div>');
  else{document.getElementById('nxsy').style.opacity='.45';}
  try{
    const r=await A('sync:analyze',cur,target||undefined);NXS.sy=r;
    const Y=document.getElementById('nxsy'),F=document.getElementById('nxsf');if(!Y)return;Y.style.opacity='';
    if(!r.rows.length){Y.innerHTML='<div class="nxe">'+esc(t('sy_empty'))+'</div>';F.innerHTML='<span style="flex:1"></span><button class="txt" onclick="closeM()">'+esc(t('cancel'))+'</button>';return;}
    const c={ok:0,upd:0,none:0,unk:0};r.rows.forEach(x=>c[x.status]++);
    const opts=[...new Set([r.mc,...r.candidates,r.target])].map(g=>'<option'+(g===r.target?' selected':'')+'>'+esc(g)+'</option>').join('');
    const lbl={ok:'sy_ok',upd:'sy_upd',none:'sy_none',unk:'sy_unk'},ord={none:0,upd:1,ok:2,unk:3};
    const rows=[...r.rows].sort((a,b)=>(!!b.warn-!!a.warn)||ord[a.status]-ord[b.status]);
    Y.innerHTML='<div class="nxtop"><div><small class="mut">'+esc(r.candidates.length?t('sy_best'):t('sy_nobest'))+'</small>'+(r.candidates.length?'<b class="nxbest">'+esc(r.candidates[0])+'</b>':'')+'</div><label>'+esc(t('sy_target'))+'<select id="nxtg" onchange="nxSync(this.value)">'+opts+'</select></label></div>'
      +'<div class="nxsum"><span class="ok">'+c.ok+' '+esc(t('sy_ok'))+'</span><span class="up">'+c.upd+' '+esc(t('sy_upd'))+'</span><span class="no">'+c.none+' '+esc(t('sy_none'))+'</span></div>'
      +(r.conflicts.length?'<div class="nxwarn">⚠ '+esc(t('sy_conf'))+'<ul>'+r.conflicts.map(x=>'<li><b>'+esc(x.mod)+'</b> → '+esc(x.dep)+' '+esc(x.need)+' <small>('+esc(x.have)+')</small></li>').join('')+'</ul></div>':'')
      +rows.map(x=>'<div class="nxv"><div class="n"><div><b>'+esc(x.title)+'</b></div><small>'+(x.status==='upd'?esc(x.from+' → '+x.to):esc(x.from||''))+(x.warn?' · <span class="w">'+esc(x.warn)+'</span>':'')+'</small></div><em class="st '+x.status+'">'+esc(t(lbl[x.status]))+'</em></div>').join('');
    F.innerHTML=(r.target!==r.mc?'<label class="nxck"><input type="checkbox" id="nxmc" checked> '+esc(t('sy_setmc'))+' <b>'+esc(r.target)+'</b></label>':'')+'<span style="flex:1"></span><button class="solid" onclick="nxSyncGo()">'+esc(t('sy_apply'))+'</button><button class="txt" onclick="closeM()">'+esc(t('cancel'))+'</button>';
  }catch(e){const l=document.getElementById('nxsy');if(l){l.style.opacity='';l.innerHTML='<div class="nxe">'+esc(t('sr_err'))+'</div>';}}
}
async function nxSyncGo(){
  const r=NXS.sy;if(!r)return;const mc=document.getElementById('nxmc'),sm=mc&&mc.checked;
  const F=document.getElementById('nxsf');if(F)F.innerHTML='<span class="nxe">'+esc(t('sy_work'))+'</span>';
  try{
    const o=await A('sync:apply',cur,r.target,!!sm);closeM();
    toast(t('sy_done')+' '+o.updated.length+(o.fixed.length?' · '+o.fixed.join(', '):'')+(o.unresolved.length?' · ⚠ '+o.unresolved.join(', '):'')+(o.failed.length?' · ✗ '+o.failed.length:''));
    try{await load();}catch{}try{refreshFiles();}catch{}
  }catch(e){closeM();fail(e);}
}
